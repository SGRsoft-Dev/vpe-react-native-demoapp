import React, { useMemo, useState, useRef, useEffect, forwardRef, useImperativeHandle, useCallback } from 'react';
import {
	View,
	StyleSheet,
	Text,
	Image,
	StatusBar,
	Platform,
	Modal,
	TouchableOpacity,
	ActivityIndicator,
	AppState,
} from 'react-native';

import * as ScreenOrientation from 'expo-screen-orientation';
import Video from '@sgrsoft/react-native-video';
import { PlayIcon, TimerIcon } from 'phosphor-react-native';
import * as Network from 'expo-network';

import { getCaptureProtection } from './captureProtection';
import ControlBar from './ControlBar';
import SettingsMenu from './SettingsMenu';
import Watermark from './Watermark';
import BackBtn from './controls/BackBtn';
import { PlayerProvider, type PlayerContextValue } from './PlayerContext';
import { renderIcon } from './layout/iconRenderer';

import t from './locales/i18n';
import { isRunningInExpoGo, formatPremiereCountdown, formatDateTime } from './util';
import { type VpePlayerProps, type VpePlayerEvents, getValidatedOptions } from './options';
import { useKeyAuthentication, useHlsPlaylistParsing, useControlsVisibility, usePayCheck } from './hooks';
import MaManager from './maManager';

// ============================================================================
// 타입 정의
// ============================================================================

export interface PlayerSubscription {
	remove: () => void;
}

export interface PlayerRef {
	play: () => void;
	pause: () => void;
	currentTime: (time: number) => void;
	muted: () => void;
	fullScreen: () => Promise<void>;
	next: () => void;
	prev: () => void;
	controlBarActive: () => void;
	controlBarDeactive: () => void;
	pip: () => Promise<void>;
	tokenChange: (token: string) => void;
	addListener: (eventName: string, listener: (event: any) => void) => PlayerSubscription;
}

// ============================================================================
// 상수 정의
// ============================================================================

const DEBOUNCE_TIME = {
	UI_INIT: 100,
	UI_INIT_ANDROID: 100,
	SEEK_DELAY: 200,
	MA_SYNC_DELAY: 500,
	MA_REPORT_DELAY: 1500,
} as const;

const LIVE_EDGE_EPSILON = 1.0; // 라이브 엣지 근접 허용 오차 (초)

// ============================================================================
// 메인 컴포넌트
// ============================================================================

const VpePlayer = forwardRef<PlayerRef, VpePlayerProps>(
	(
		{
			options,
			events,
			accessKey,
			platform = 'pub',
			stage = 'prod',
			isDev = false,
			devTestAppId = 'com.vpereactnative.example',
			errorOverride,
			override,
			layout,
		},
		ref
	) => {
		// ====================================================================
		// 인증 및 설정
		// ====================================================================

		const { serverOptions, authError, isError, setErrorRun, playerInfo, errorInfo } = useKeyAuthentication(
			accessKey,
			platform,
			stage,
			devTestAppId,
			events,
			isDev
		);

		const appState = useRef(AppState.currentState);
		const [appStateVisible, setAppStateVisible] = useState(appState.current);

		useEffect(() => {
			const subscription = AppState.addEventListener('change', (nextAppState) => {
				if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
					console.log('App has come to the foreground!');
				}

				appState.current = nextAppState;
				setAppStateVisible(appState.current);
				console.log('AppState', appState.current);
			});

			return () => {
				subscription.remove();
			};
		}, []);

		// 시작 시간 추적
		const [startTimeAt, setStartTimeAt] = useState<number | null>(null);
		useEffect(() => {
			setStartTimeAt(new Date().getTime());
		}, []);

		const getElapsedMilliseconds = () => {
			if (!startTimeAt) return 0;
			return new Date().getTime() - startTimeAt;
		};

		// 결제 상태 확인
		const isPaymentValid = usePayCheck(playerInfo);
		useEffect(() => {
			if (isPaymentValid === false) {
				setErrorRun('E0001');
			}
		}, [isPaymentValid]);

		// ====================================================================
		// 옵션 병합 및 검증
		// ====================================================================

		const [cumOptions, setCumOptions] = useState({ controlBtn: {} });

		const validatedOptions = useMemo(() => {
			const baseOptions = getValidatedOptions(serverOptions);
			const finalOptions = { ...baseOptions, ...(options ?? {}) };

			// 중첩 객체 깊은 병합
			if (options?.controlBtn) {
				finalOptions.controlBtn = { ...baseOptions.controlBtn, ...options.controlBtn };
			}
			if (options?.watermarkConfig) {
				finalOptions.watermarkConfig = { ...baseOptions.watermarkConfig, ...options.watermarkConfig };
			}

			// playlist 배열 정규화
			if (finalOptions.playlist && !Array.isArray(finalOptions.playlist)) {
				finalOptions.playlist = [{ file: finalOptions.playlist }];
			}

			// 누적 옵션 병합
			if (cumOptions?.controlBtn) {
				finalOptions.controlBtn = { ...finalOptions.controlBtn, ...cumOptions.controlBtn };
			}

			return finalOptions;
		}, [options, serverOptions, cumOptions]);

		// ====================================================================
		// 커스텀 컴포넌트
		// ====================================================================

		const ErrorOverride = errorOverride;
		const Override = override;

		// ====================================================================
		// 플레이어 상태
		// ====================================================================

		// UI 상태
		const [uiInit, setUiInit] = useState(0);
		const [isDestroyed, setIsDestroyed] = useState(false);
		const [initLoad, setInitLoad] = useState(false);
		const [isPlayerReady, setIsPlayerReady] = useState(false);
		const [isActive, setIsActive] = useState(false);
		const [isSettingMenu, setIsSettingMenu] = useState(false);

		// 재생 상태
		const [isPlaying, setIsPlaying] = useState(false);
		const [isInitPlay, setIsInitPlay] = useState(false);

		useEffect(() => {
			if (Object.keys(validatedOptions).length === 0) {
				return;
			}
			const startTime = validatedOptions.setStartTime;
			if (startTime && startTime instanceof Date && startTime.getTime() > new Date().getTime()) {
				setIsPlaying(false);
			}
			setIsPlaying(validatedOptions.autostart);
		}, [validatedOptions]);

		useEffect(() => {
			if (Object.keys(validatedOptions).length === 0) {
				return;
			}
			setMuted(validatedOptions.muted);
		}, [validatedOptions]);

		const [isEnded, setIsEnded] = useState(false);
		const [isStatus, setIsStatus] = useState('loading');
		const [playbackRate, setPlaybackRate] = useState(1.0);

		// 비디오 정보
		const [isLive, setIsLive] = useState(false);
		const [isDvr, setIsDvr] = useState(false);
		const [duration, setDuration] = useState(0);
		const [currentTime, setCurrentTime] = useState(0);
		const [seekableDuration, setSeekableDuration] = useState(0);
		const [lastDurationTs, setLastDurationTs] = useState(0);
		const [videoSize, setVideoSize] = useState({ width: 0, height: 0 });

		// 화면 상태
		const [isFullScreen, setIsFullScreen] = useState(false);
		const [isPip, setIsPip] = useState(false);
		const [isMuted, setMuted] = useState(false);

		// 플레이리스트 상태
		const [playIdx, setPlayIdx] = useState(validatedOptions.playIndex);
		const [isSourceReady, setIsSourceReady] = useState(false);
		const [isLoadEnd, setLoadEnd] = useState(false);
		const [pUrl, setPUrl] = useState('');

		// 품질 및 자막
		const [qualityLevels, setQualityLevels] = useState<VideoQuality[]>([]);
		const [selectedQualityLevel, setSelectedQualityLevel] = useState<VideoQuality | null>(null);
		const [manifestSubtitles, setManifestSubtitles] = useState<any[]>([]);
		const [availableSubtitles, setAvailableSubtitles] = useState<any[]>([]);
		const [parsedSubtitles, setParsedSubtitles] = useState<Record<string, any[]>>({});
		const [selectedSubtitle, setSelectedSubtitle] = useState<string | null>(null);
		const [currentSubtitleText, setCurrentSubtitleText] = useState<string>('');

		// 프리미어(최초 공개) 상태
		const [isPremiereWaiting, setIsPremiereWaiting] = useState(false);
		const [timeToPremiere, setTimeToPremiere] = useState(0);
		const [startPlay, setStartPlay] = useState(false);

		// 기타 상태
		const [seekInfo] = useState<{ direction: 'forward' | 'rewind'; amount: number } | null>(null);
		const [prog, setProg] = useState({ currentTime: 0, seekableDuration: 0 });
		const [sliderMax, setSliderMax] = useState(0);
		const [networkState, setNetworkState] = useState({ type: null });

		// ====================================================================
		// Refs
		// ====================================================================

		const player = useRef<Video>(null);
		const controlsTimerRef = useRef<NodeJS.Timeout | null>(null);
		const maManagerRef = useRef<MaManager | null>(null);
		const [maInit, setMaInit] = useState(false);
		const [maStartUp, setMaStartUp] = useState(false);
		const [maLastCueTime, setMaLastCueTime] = useState(0);

		// ====================================================================
		// MaManager 초기화
		// ====================================================================

		useEffect(() => {
			if (playerInfo) {
				maManagerRef.current = new MaManager(platform, stage, playerInfo);
			}
		}, [playerInfo, platform, stage]);

		// ====================================================================
		// 플레이리스트 및 소스 관리
		// ====================================================================

		const playUrl = validatedOptions.playlist?.[playIdx]?.file ?? '';
		const drmSource = validatedOptions.playlist?.[playIdx]?.drm ?? '';
		const poster = validatedOptions.playlist?.[playIdx]?.poster || null;
		const description = validatedOptions.playlist?.[playIdx]?.description || {};

		useEffect(() => {
			if (validatedOptions.autostart) {
				setInitLoad(true);
			}
		}, [validatedOptions.autostart]);

		useEffect(() => {
			setIsEnded(false);
			setPUrl(playUrl + validatedOptions?.token);
			setIsSourceReady(true);
		}, [playUrl, validatedOptions?.token]);

		// ====================================================================
		// Media Analytics 동기화
		// ====================================================================

		const playMaSync = (actionType: any, sendtoData: any = {}) => {
			if (!actionType) return;

			const toData = {
				video: {
					type: isLive ? 'LIVE' : 'VOD',
					quality: videoSize.height ? `${videoSize.height}p` : 'auto',
					url: playUrl,
				},
				connection: {
					network: networkState.type,
					downlink: 1,
					rtt: 50,
					save_data: false,
				},
				extra: {
					title: description?.title,
					metaData: description,
					videoWidth: Math.round(videoSize.width),
					videoHeight: Math.round(videoSize.height),
					video_protocols: getVideoProtocol(playUrl),
					duration: Math.floor(duration),
					currentTime: Math.floor(currentTime),
					playedTime: getElapsedMilliseconds(),
					viewingTime: Math.round(getElapsedMilliseconds() / 1000),
					percent: Math.round((currentTime / duration) * 100),
					quality: videoSize.height ? `${videoSize.height}p` : 'auto',
					errorCode: errorInfo?.errorCode,
					errorMessage: errorInfo?.errorMessage,
					...sendtoData,
				},
			};

			maManagerRef.current?.maSync(toData);
			maManagerRef.current?.dispatchEvent({ type: actionType, data: toData });

			// 특정 이벤트는 timeupdateFocus도 전송
			if (!['timeupdate', 'player_start', 'startup', 'timeupdateFocus'].includes(actionType)) {
				maManagerRef.current?.dispatchEvent({
					type: 'timeupdateFocus',
					data: { extra: sendtoData },
				});
			}

			return toData;
		};

		const getVideoProtocol = (url: string): string => {
			if (url.indexOf('m3u8') > -1) return 'hls';
			if (url.indexOf('mpd') > -1) return 'dash';
			return 'mp4';
		};

		// ====================================================================
		// 비디오 이벤트 핸들러
		// ====================================================================

		const handleOnError = (data: any) => {
			playMaSync('error', data.error);
			setErrorRun('E0004');
		};

		const handleOnSeek = (data: any) => {
			// 필요시 구현
		};

		const handleOnEnd = () => {
			if (controlsTimerRef.current) {
				clearTimeout(controlsTimerRef.current);
			}
			if (validatedOptions.repeat) {
				handleOnSeek(0);
			} else {
				setIsPlaying(false);
				setIsEnded(true);
				setIsActive(true);

				events?.ended?.();
				playMaSync('ended');
			}
		};

		const handleOnProgress = async (data: any) => {
			// 라이브 스트림 감지
			const { isLikelyLive } = guessLiveByProgress({
				currentTime: data.currentTime,
				playableDuration: data.playableDuration,
				seekableDuration: data.seekableDuration,
				currentPlaybackTime: data.currentPlaybackTime,
			});

			if (Platform.OS === 'ios') {
				if (data.playableDuration) {
					setIsLive(lastDurationTs > 0 && lastDurationTs > duration);
					setLastDurationTs(Math.floor(data.playableDuration));
				}
			} else {
				setIsLive(isLikelyLive);
				setLastDurationTs(Math.floor(data.playableDuration));
			}

			if (data.currentTime) setCurrentTime(data.currentTime);
			if (data.seekableDuration) setSeekableDuration(data.seekableDuration);

			if (data.currentTime > 0.5) {
				//console.log('111', data.currentTime);
				setIsInitPlay(true);
			}

			setProg({
				currentTime: data.currentTime ?? 0,
				seekableDuration: data.seekableDuration ?? 0,
			});

			const state = await Network.getNetworkStateAsync();
			setNetworkState(state);
		};

		const handleOnBuffer = (data: any) => {
			if (data.isBuffering) {
				setIsPlayerReady(false);
				setIsStatus('loading');
				playMaSync('waiting');
			} else {
				setIsPlayerReady(true);
				setIsStatus('readyToPlay');
				playMaSync('waitingEnd');
			}
		};

		const handleOnPlaybackStateChanged = (data: any) => {
			setIsPlayerReady(true);
			if (data.isPlaying) {
				setIsStatus('playing');
				setIsEnded(false);
			} else {
				setIsStatus('paused');
			}
			if (data.isSeeking) {
				setIsStatus('seeking');
			} else {
				setIsStatus('readyToPlay');
			}
		};

		const handleOnLoadStart = (data: any) => {
			setDuration(0);
			setLastDurationTs(0);
			setIsLive(false);
			setIsDvr(false);
			setStartPlay(false);

			try {
				if (!data.src.isNetwork) {
					setErrorRun('E0008');
				}
			} catch (e) {}
		};

		const handleOnLoad = (data: any) => {
			playMaSync('durationchange');

			// DVR 확인
			if (playUrl.includes('/dvr/video/ls-')) {
				setIsLive(true);
				setIsDvr(true);
			} else {
				setIsDvr(false);
			}

			// 비디오 크기 설정
			if (data.naturalSize) {
				setVideoSize({
					width: data.naturalSize.width,
					height: data.naturalSize.height,
				});
			}

			// 프리미어 시작 시간 처리
			if (data.duration) {
				setDuration(data.duration);
				handlePremiereStartTime(data.duration);
			}

			setLoadEnd(true);
		};

		const handleOnReadyForDisplay = () => {
			const delay = Platform.OS === 'android' ? DEBOUNCE_TIME.UI_INIT_ANDROID : DEBOUNCE_TIME.UI_INIT;
			setTimeout(() => {
				setUiInit((v) => v + 1);
			}, delay);

			events?.ready?.();
		};

		// ====================================================================
		// 라이브 스트림 감지 로직
		// ====================================================================

		let lastSeekable = 0;
		let lastCheckAt = Date.now();

		type LiveGuess = {
			isLikelyLive: boolean;
			reasons: string[];
		};

		function guessLiveByProgress(p: {
			currentTime: number;
			playableDuration: number;
			seekableDuration: number;
			currentPlaybackTime?: number;
		}): LiveGuess {
			const reasons: string[] = [];
			const now = Date.now();

			// 1) PROGRAM-DATE-TIME 확인 (iOS/HLS)
			const hasProgramDateTime =
				typeof p.currentPlaybackTime === 'number' &&
				p.currentPlaybackTime > now - 24 * 3600 * 1000 &&
				p.currentPlaybackTime < now + 24 * 3600 * 1000;

			if (hasProgramDateTime) {
				reasons.push('PROGRAM-DATE-TIME 감지(iOS)');
			}

			// 2) seekableDuration 증가 확인
			const dt = Math.max(0.5, (now - lastCheckAt) / 1000);
			const dSeek = p.seekableDuration - lastSeekable;
			const seekableGrowing = dSeek > 0.2 * dt;

			if (seekableGrowing) {
				reasons.push('seekableDuration 증가(라이브 윈도 이동)');
			}

			// 3) 라이브 엣지 근접 확인
			const edgeLag = p.seekableDuration - p.currentTime;
			const nearEdge = edgeLag >= 0 && edgeLag < 12;

			if (nearEdge) {
				reasons.push(`라이브 엣지 근접(edgeLag≈${edgeLag.toFixed(1)}s)`);
			}

			// 최종 판정
			const isLikelyLive = !!(hasProgramDateTime || (seekableGrowing && nearEdge));

			// 상태 업데이트
			lastSeekable = p.seekableDuration;
			lastCheckAt = now;

			return { isLikelyLive, reasons };
		}

		// ====================================================================
		// 라이브 이동 및 품질 변경
		// ====================================================================

		const jumpToLive = useCallback(() => {
			if (player.current && prog.seekableDuration > 0) {
				handerSeek(Math.max(0, prog.seekableDuration - LIVE_EDGE_EPSILON));
			}
		}, [prog.seekableDuration]);

		const handlePlaybackRateChange = (rate: number) => {
			setPlaybackRate(rate);
		};

		const handleQualityChange = (quality: VideoQuality | null) => {
			playMaSync('durationchange', {
				newQuality: quality?.height,
				oldQuality: selectedQualityLevel?.height,
			});

			const lastPlaying = isPlaying;
			const currentTimeLast = currentTime;

			setIsPlaying(false);

			if (quality?.uri) {
				setPUrl(quality.uri);
				setSelectedQualityLevel(quality);
			} else {
				setPUrl(playUrl);
				setSelectedQualityLevel(null);
			}

			setTimeout(() => {
				player.current?.seek(currentTimeLast + 0.2);
				if (lastPlaying) {
					setIsPlaying(true);
				}
			}, DEBOUNCE_TIME.SEEK_DELAY);
		};

		// ====================================================================
		// MA 스타트업 및 에러 처리
		// ====================================================================

		useEffect(() => {
			if (!maStartUp && videoSize.height > 0) {
				setErrorRun();
				setTimeout(() => {
					playMaSync('player_start', { playerStartTime: getElapsedMilliseconds() });
					setTimeout(() => {
						playMaSync('startup', {
							videoStartTime: getElapsedMilliseconds(),
							totalStartTime: getElapsedMilliseconds(),
						});
					}, DEBOUNCE_TIME.SEEK_DELAY);
				}, DEBOUNCE_TIME.MA_SYNC_DELAY);

				setMaStartUp(true);
			}
		}, [maStartUp, videoSize, duration]);

		useEffect(() => {
			setTimeout(() => {
				if (!errorInfo?.errorCode) return;
				playMaSync('error', {
					code: errorInfo?.errorCode,
					message: errorInfo?.errorMessage,
				});
			}, DEBOUNCE_TIME.MA_REPORT_DELAY);
		}, [errorInfo]);

		// ====================================================================
		// 이벤트 동기화
		// ====================================================================

		useEffect(() => {
			if (isPlaying) {
				events?.play?.();
				playMaSync('play');
			} else {
				events?.pause?.();
				playMaSync('pause');
			}
		}, [isPlaying]);

		useEffect(() => {
			if (isActive) {
				events?.controlbarActive?.();
			} else {
				events?.controlbarDeactive?.();
			}
		}, [isActive]);

		useEffect(() => {
			events?.volumechange?.({ muted: isMuted });
		}, [isMuted]);

		useEffect(() => {
			if (isStatus === 'loading') {
				events?.waiting?.();
				playMaSync('waiting');
			}
			if (isStatus === 'readyToPlay') {
				setTimeout(() => {
					setIsPlayerReady(true);
				}, 500);
				playMaSync('canplay');
			}
		}, [isStatus]);

		// MA timeupdate 및 초기화
		useEffect(() => {
			if (Math.round(currentTime) > maLastCueTime) {
				if (videoSize.width > 0) {
					setMaLastCueTime(Math.round(currentTime));

					if (currentTime >= 3 && !maInit) {
						maManagerRef.current?.maInit({
							video: {
								type: isLive ? 'LIVE' : 'VOD',
								quality: `${videoSize.height}p`,
								url: playUrl,
							},
							extra: {
								title: description?.title,
								metaData: description,
								videoWidth: Math.round(videoSize.width),
								videoHeight: Math.round(videoSize.height),
								video_protocols: getVideoProtocol(playUrl),
							},
						});
						setMaInit(true);
					}

					playMaSync('timeupdate', { playedTime: currentTime });
				}
			}
		}, [isLive, playUrl, currentTime, duration, lastDurationTs, maLastCueTime, videoSize]);

		// ====================================================================
		// 프리미어(최초 공개) 처리
		// ====================================================================

		const handlePremiereStartTime = (videoDuration: number) => {
			const startTime = validatedOptions.setStartTime;
			if (startTime && startTime instanceof Date) {
				const now = new Date().getTime();
				const startTimeMs = startTime.getTime();

				if (now > startTimeMs) {
					setIsPlaying(false);
					setTimeout(() => {
						const offsetInSeconds = (now - startTimeMs) / 1000;
						if (player.current) {
							if (videoDuration > 0 && offsetInSeconds >= videoDuration) {
								player.current.seek(0);
							} else {
								player.current.seek(offsetInSeconds);
							}
							setIsPlaying(true);
						}
					}, DEBOUNCE_TIME.SEEK_DELAY);
				}
			}
		};

		useEffect(() => {
			const startTime = validatedOptions.setStartTime;
			if (!startTime || !(startTime instanceof Date)) {
				setIsPremiereWaiting(false);
				return;
			}

			let intervalId: NodeJS.Timeout;

			const checkPremiereTime = () => {
				const now = new Date().getTime();
				const timeLeft = startTime.getTime() - now;

				if (timeLeft <= 0) {
					const startTimeMs = startTime.getTime();
					const offsetInSeconds = (now - startTimeMs) / 1000;

					if (player.current) {
						player.current.seek(offsetInSeconds);
					} else {
						setTimeout(() => {
							player.current?.seek(offsetInSeconds);
						}, 300);
					}

					setIsPremiereWaiting(false);
					setTimeToPremiere(0);
					setIsPlaying(true);
					setStartPlay(true);

					if (intervalId) clearInterval(intervalId);
				} else {
					setIsPremiereWaiting(true);
					setTimeToPremiere(timeLeft);
					setIsPlaying(false);
					setStartPlay(true);
				}
			};

			checkPremiereTime();
			intervalId = setInterval(checkPremiereTime, 1000);

			return () => clearInterval(intervalId);
		}, [validatedOptions.setStartTime, validatedOptions.autostart]);

		// ====================================================================
		// 자막 처리
		// ====================================================================

		const parseVttTime = (time: string): number => {
			const timeOnly = time.split(' ')[0];
			const parts = timeOnly.split(':').reverse();
			let seconds = 0;
			if (parts[0]) seconds += parseFloat(parts[0]);
			if (parts[1]) seconds += parseInt(parts[1], 10) * 60;
			if (parts[2]) seconds += parseInt(parts[2], 10) * 3600;
			return seconds;
		};

		const parseVttContent = (vttText: string) => {
			const cueBlocks = vttText
				.trim()
				.replace('WEBVTT', '')
				.split(/\n\s*\n/);
			const cues = [];

			for (const block of cueBlocks) {
				if (!block) continue;
				const lines = block.split('\n');
				const timeLineIndex = lines.findIndex((line) => line.includes('-->'));
				if (timeLineIndex === -1) continue;

				const timeLine = lines[timeLineIndex];
				const [start, end] = timeLine.split(' --> ');
				const textLines = lines.slice(timeLineIndex + 1);

				if (start && end) {
					cues.push({
						startTime: parseVttTime(start.trim()),
						endTime: parseVttTime(end.trim()),
						text: textLines.join('\n').trim(),
					});
				}
			}
			return cues;
		};

		// 자막 파싱
		useEffect(() => {
			const vttFromOptions = validatedOptions.playlist?.[playIdx]?.vtt || [];
			const allVttSources = [...vttFromOptions, ...manifestSubtitles];
			const uniqueVttSources = allVttSources.filter((v, i, a) => a.findIndex((t) => t.id === v.id) === i);

			setAvailableSubtitles(uniqueVttSources);

			if (uniqueVttSources.length === 0) {
				setParsedSubtitles({});
				setSelectedSubtitle(null);
				return;
			}

			const parseAllVtts = async () => {
				const allCues = {};
				for (const vttSource of uniqueVttSources) {
					try {
						let vttText: string;

						if (vttSource.file.endsWith('.m3u8')) {
							// HLS 자막 플레이리스트 처리
							const m3u8Response = await fetch(vttSource.file);
							if (!m3u8Response.ok) throw new Error(`HTTP ${m3u8Response.status}`);
							const m3u8Text = await m3u8Response.text();

							const lines = m3u8Text.split('\n');
							const segmentUrls: string[] = [];
							const baseUrl = vttSource.file.substring(0, vttSource.file.lastIndexOf('/') + 1);

							for (const line of lines) {
								if (line.trim() && !line.startsWith('#')) {
									let segmentUrl = line.trim();
									if (!segmentUrl.startsWith('http')) {
										segmentUrl = new URL(segmentUrl, baseUrl).href;
									}
									segmentUrls.push(segmentUrl);
								}
							}

							if (segmentUrls.length > 0) {
								const segmentResponses = await Promise.all(segmentUrls.map((url) => fetch(url)));
								const segmentTexts = await Promise.all(
									segmentResponses.map((res) => {
										if (!res.ok) throw new Error(`HTTP ${res.status}`);
										return res.text();
									})
								);
								vttText = segmentTexts.join('\n\n').replace(/WEBVTT\s*/g, '');
							} else {
								vttText = '';
							}
						} else {
							// 직접 VTT 파일 처리
							const response = await fetch(vttSource.file);
							if (!response.ok) throw new Error(`HTTP ${response.status}`);
							vttText = await response.text();
						}

						if (vttText) {
							allCues[vttSource.id] = parseVttContent(vttText);
						}
					} catch (error) {
						console.error(`자막 로드 실패: ${vttSource.file}`, error);
					}
				}
				setParsedSubtitles(allCues);
				const defaultVtt = uniqueVttSources.find((vtt) => vtt.default) || null;
				setSelectedSubtitle(defaultVtt?.id || null);
			};

			parseAllVtts();
		}, [playIdx, validatedOptions.playlist, manifestSubtitles]);

		// 현재 자막 표시
		useEffect(() => {
			if (!selectedSubtitle || !parsedSubtitles[selectedSubtitle]) {
				setCurrentSubtitleText('');
				return;
			}

			const cues = parsedSubtitles[selectedSubtitle];
			const activeCue = cues.find((cue) => currentTime >= cue.startTime && currentTime <= cue.endTime);

			setCurrentSubtitleText(activeCue ? activeCue.text : '');
		}, [currentTime, selectedSubtitle, parsedSubtitles]);

		const handleSubtitleChange = (langId: string | null) => {
			setSelectedSubtitle(langId);
		};

		// 자막 토글: 켜져있으면 끄고, 꺼져있으면 default(없으면 첫 번째) 자막을 켠다.
		const handleToggleSubtitle = () => {
			if (selectedSubtitle) {
				handleSubtitleChange(null);
				return;
			}
			if (!Array.isArray(availableSubtitles) || availableSubtitles.length === 0) return;
			const defaultSubtitle = availableSubtitles.find((s: any) => s?.default) || availableSubtitles[0];
			if (defaultSubtitle?.id) {
				handleSubtitleChange(defaultSubtitle.id);
			}
		};

		// HLS 플레이리스트 파싱
		useHlsPlaylistParsing(playUrl, setQualityLevels, setManifestSubtitles);

		// ====================================================================
		// 화면 캡처 방지
		// ====================================================================

		useEffect(() => {
			if (!validatedOptions.screenRecordingPrevention) return;

			if (!isRunningInExpoGo()) {
				let CP = null;
				const setupProtection = async () => {
					CP = await getCaptureProtection();
					if (CP) {
						CP.prevent({ screenshot: true, record: true, appSwitcher: false });
					}
				};

				setupProtection();

				return () => {
					if (CP) {
						CP.allow({ screenshot: true, record: true, appSwitcher: true });
					}
				};
			}
		}, [validatedOptions.screenRecordingPrevention]);

		// ====================================================================
		// 컨트롤 가시성 관리
		// ====================================================================

		useControlsVisibility(isActive, setIsActive, isPlaying, validatedOptions.controlActiveTime, controlsTimerRef);

		// ====================================================================
		// 사용자 액션 핸들러
		// ====================================================================

		const handerPlayPause = () => {
			if (isPremiereWaiting) return;

			setInitLoad(true);
			if (isPlaying) {
				setIsPlaying(false);
			} else {
				setIsPlaying(true);
				if (isEnded) {
					player.current?.seek(0);
				}
				setIsActive(false);
			}
		};

		const handerSeek = (time: number[]) => {
			const seekTime = time[0];
			if (seekTime === undefined || seekTime === null) return;

			events?.seeking?.();
			player.current?.seek(seekTime);
			setIsEnded(false);
			setIsPlaying(true);
			events?.seeked?.();

			playMaSync('seeking', { seekedTime: Math.floor(seekTime) });

			setTimeout(() => {
				playMaSync('seeked');
				if (isPlaying) {
					playMaSync('play');
				}
			}, 100);
		};

		const handerMuted = () => {
			setMuted(!isMuted);
		};

		const handerFullScreen = async () => {
			if (Override?.fullscreen) {
				Override.fullscreen();
				return;
			}

			const lastCurrentTime = currentTime;

			if (isFullScreen) {
				await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
				setIsFullScreen(false);
				events?.fullscreen_off?.();
				events?.fullscreen?.({ isFullScreen: false });

				if (validatedOptions.modalFullscreen) {
					setTimeout(() => {
						player.current?.seek(lastCurrentTime);
					}, 300);
				}
			} else {
				await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE_RIGHT);
				setIsFullScreen(true);
				events?.fullscreen_on?.();
				events?.fullscreen?.({ isFullScreen: true });

				if (validatedOptions.modalFullscreen) {
					setTimeout(() => {
						player.current?.seek(lastCurrentTime);
					}, 300);
				}
			}
		};

		// ====================================================================
		// 플레이리스트 네비게이션
		// ====================================================================

		const handleNextVideo = () => {
			if (Override?.nextSource) {
				Override.nextSource();
				return;
			}

			const currentPlaylist = validatedOptions.playlist;
			const currentIdx = playIdx;

			if (currentPlaylist && currentIdx < currentPlaylist.length - 1) {
				const nextIdx = currentIdx + 1;
				const nextVideo = currentPlaylist[nextIdx];
				if (!nextVideo || !nextVideo.file) return;

				setPlayIdx(nextIdx);
				setPUrl(nextVideo.file);
				setCurrentTime(0);
				handerSeek([0]);
				setDuration(0);
				setLastDurationTs(0);
				setSelectedQualityLevel(null);
				setIsActive(false);
				setIsPlaying(true);

				if (events?.nextTrack) {
					const nextDescription = nextVideo.description || {};
					events.nextTrack({
						file: nextVideo.file,
						poster: nextVideo.poster,
						title: nextDescription.title,
						created_at: nextDescription.created_at,
						profile_name: nextDescription.profile_name,
						profile_image: nextDescription.profile_image,
					});
				}

				playMaSync('nextTrack', { currentTime: 0, duration: 0, percent: 0 });
				playMaSync('startup', {
					videoStartTime: getElapsedMilliseconds(),
					totalStartTime: getElapsedMilliseconds(),
				});
			}
		};

		const handlePip = () => {
			if (isPip) {
				player.current?.stopPictureInPicture();
			} else {
				player.current?.startPictureInPicture();
			}
		};

		const handlePrevVideo = () => {
			if (Override?.prevSource) {
				Override.prevSource();
				return;
			}

			const currentPlaylist = validatedOptions.playlist;
			const currentIdx = playIdx;

			if (currentPlaylist && currentIdx > 0) {
				const prevIdx = currentIdx - 1;
				const prevVideo = currentPlaylist[prevIdx];
				if (!prevVideo || !prevVideo.file) return;

				player.current?.seek(0);
				setPlayIdx(prevIdx);
				setPUrl(prevVideo.file);
				setDuration(0);
				setLastDurationTs(0);
				setSelectedQualityLevel(null);
				setIsActive(false);
				setIsPlaying(true);

				playMaSync('prevTrack', { currentTime: 0, duration: 0, percent: 0 });
				playMaSync('startup', {
					videoStartTime: getElapsedMilliseconds(),
					totalStartTime: getElapsedMilliseconds(),
				});

				if (events?.prevTrack) {
					const prevDescription = prevVideo.description || {};
					events.prevTrack({
						file: prevVideo.file,
						poster: prevVideo.poster,
						title: prevDescription.title,
						created_at: prevDescription.created_at,
						profile_name: prevDescription.profile_name,
						profile_image: prevDescription.profile_image,
					});
				}
			}
		};

		useEffect(() => {
			if (appStateVisible === 'background' && validatedOptions.autoPause) {
				setIsActive(true);
				setIsPlaying(false);
			}
		}, [appStateVisible, validatedOptions.autoPause]);

		// ====================================================================
		// Imperative Handle (Ref API)
		// ====================================================================

		useImperativeHandle(ref, () => ({
			play: () => {
				if (isEnded) {
					player.current?.seek(0);
				}
				setIsPlaying(true);
			},
			pause: () => {
				setIsPlaying(false);
			},
			addNextSource: (res: any) => {
				try {
					validatedOptions.playlist.push(res);
				} catch (e) {
					console.error('Ncplayer', 'addNextSource error');
				}
			},
			addPrevSource: (res: any) => {
				try {
					validatedOptions.playlist.unshift(res);
				} catch (e) {
					console.error('Ncplayer', 'addPrevSource error');
				}
			},
			uiHidden: () => {
				validatedOptions.controls = false;
			},
			uiVisible: () => {
				validatedOptions.controls = true;
			},
			currentTime: (time: number) => handerSeek([time]),
			muted: handerMuted,
			fullscreen: handerFullScreen,
			next: handleNextVideo,
			prev: handlePrevVideo,
			controlBarActive: () => setIsActive(true),
			controlBarDeactive: () => setIsActive(false),
			pip: handlePip,
			addListener: (eventName: string, listener: (event: any) => void) => {
				return { remove: () => {} };
			},
			destroy: async () => {
				setIsPlaying(false);

				if (controlsTimerRef.current) {
					clearTimeout(controlsTimerRef.current);
				}

				if (isFullScreen) {
					await ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
					setIsFullScreen(false);
				}

				if (player.current && typeof (player.current as any).destroy === 'function') {
					(player.current as any).destroy();
				}

				setIsDestroyed(true);
			},
			controlBarBtnStateUpdate(btns: any) {
				const tmpOptions: any = {};
				Object.entries(btns).forEach(([key, value]) => {
					tmpOptions[key] = Boolean(value);
				});
				setCumOptions({ controlBtn: tmpOptions });
			},
		}));

		// ====================================================================
		// 플레이어 뷰 렌더링
		// ====================================================================

		const PlayerView = useMemo(() => {
			return (
				<>
					{isSourceReady && (
						<Video
							ref={player}
							source={{
								uri: pUrl,
								metadata: {
									title: description?.title ?? '',
									subtitle: '',
									artist: description?.profile_name,
									description: description?.title ?? '',
									imageUri: poster,
								},
								minLoadRetryCount: 5,
								bufferConfig: {
									minBufferMs: 15000,
									maxBufferMs: 50000,
									bufferForPlaybackMs: 2500,
									bufferForPlaybackAfterRebufferMs: 5000,
									backBufferDurationMs: 120000,
									cacheSizeMB: 0,
									live: { targetOffsetMs: 500 },
								},
							}}
							drm={drmSource}
							subtitleStyle={{ opacity: 0 }}
							resizeMode={validatedOptions.objectFit ?? 'contain'}
							style={{
								width: '100%',
								height: '100%',
								aspectRatio: validatedOptions.aspectRatio ?? 16 / 9,
								opacity: uiInit,
							}}
							controls={false}
							nativeControls={false}
							muted={isMuted}
							rate={playbackRate}
							hideShutterView={true}
							playWhenInactive={true}
							ignoreSilentSwitch={'ignore'}
							playInBackground={!validatedOptions.autoPause ? true : false}
							enterPictureInPictureOnLeave={
								!validatedOptions.autoPause && validatedOptions.allowsPictureInPicture
							}
							paused={!isPlaying}
							repeat={validatedOptions.repeat ?? false}
							onLoad={handleOnLoad}
							onLoadStart={handleOnLoadStart}
							onPlaybackStateChanged={handleOnPlaybackStateChanged}
							onBuffer={handleOnBuffer}
							onEnd={handleOnEnd}
							onError={handleOnError}
							onFullscreenPlayerDidPresent={() => setIsFullScreen(true)}
							onFullscreenPlayerDidDismiss={() => setIsFullScreen(false)}
							onPictureInPictureStatusChanged={(res) => setIsPip(res.isActive)}
							onProgress={handleOnProgress}
							onSeek={handleOnSeek}
							onReadyForDisplay={handleOnReadyForDisplay}
						/>
					)}
				</>
			);
		}, [
			isSourceReady,
			pUrl,
			description,
			poster,
			drmSource,
			validatedOptions.objectFit,
			validatedOptions.aspectRatio,
			validatedOptions.repeat,
			validatedOptions.autoPause,
			validatedOptions.allowsPictureInPicture,
			uiInit,
			isMuted,
			isPlaying,
			playbackRate,
		]);

		// ====================================================================
		// UI 렌더링
		// ====================================================================

		const PlayerUI = (
			<>
				{!isError ? (
					<View style={styles.videoContainer}>
						{PlayerView}

						{/* 워터마크 */}
						{validatedOptions.visibleWatermark && (
							<Watermark
								randPosition={validatedOptions.watermarkConfig?.randPosition}
								randPositionInterVal={validatedOptions.watermarkConfig?.randPositionInterVal}
								x={validatedOptions.watermarkConfig?.x}
								y={validatedOptions.watermarkConfig?.y}
								opacity={validatedOptions.watermarkConfig?.opacity}
								watermarkText={validatedOptions.watermarkText}
							/>
						)}

						{/* 프리미어 대기 오버레이 */}
						{isPremiereWaiting && (
							<View style={styles.premiereOverlay}>
								<View style={styles.backButtonContainer}>
									<BackBtn />
								</View>

								<View style={styles.premiereContainer}>
									<View style={styles.premiereWarp}>
										<TimerIcon color={'#fff'} size={20} />
										<View>
											<Text style={styles.premiereCountdown}>
												{t.alternative?.startPlay?.replace(
													'{timeTxt}',
													formatPremiereCountdown(timeToPremiere)
												)}
											</Text>
											<Text style={[styles.premiereStartTime, { fontSize: 11 }]}>
												{t.alternative?.afterPlay}{' '}
												{formatDateTime(validatedOptions.setStartTime)}
											</Text>
										</View>
									</View>
								</View>
							</View>
						)}

						{/* 자막 영역 */}
						{!isEnded && !seekInfo && (
							<View
								style={[
									styles.subTitleAreaWarp,
									{ bottom: isFullScreen ? 15 : 15, paddingHorizontal: isFullScreen ? 10 : 10 },
								]}
							>
								{currentSubtitleText &&
									(() => {
										const captionStyle = validatedOptions.captionStyle;
										const textShadow =
											captionStyle.edgeStyle === 'dropshadow'
												? styles.textShadowDrop
												: captionStyle.edgeStyle === 'raised'
													? styles.textShadowRaised
													: captionStyle.edgeStyle === 'depressed'
														? styles.textShadowDepressed
														: captionStyle.edgeStyle === 'uniform'
															? styles.textShadowUniform
															: {};

										return (
											<View
												style={[
													styles.subTitleArea,
													{ backgroundColor: captionStyle.backgroundColor },
												]}
											>
												<Text
													style={[
														styles.subTitleText,
														{
															fontSize: isFullScreen
																? captionStyle.fontSize * 1.5
																: captionStyle.fontSize,
															color: captionStyle.color,
														},
														textShadow,
													]}
												>
													{currentSubtitleText}
												</Text>
											</View>
										);
									})()}
							</View>
						)}

						{/* 초기 재생 버튼 (BackBtn은 ControlBar의 디폴트 layout이 처리하므로 별도 표시하지 않음) */}
						{!initLoad && (
							<View style={[styles.loadingWarp, { backgroundColor: 'rgba(0, 0, 0, 0.2)' }]}>
								<TouchableOpacity onPress={handerPlayPause}>
									{renderIcon(
										validatedOptions.icon?.bigPlay,
										<PlayIcon size={40} color={'#ffffff'} weight={'fill'} />,
										{ imageStyle: { width: 40, height: 40 } }
									)}
								</TouchableOpacity>
							</View>
						)}

						{/*
							플레이어 컨트롤: 항상 ControlBar 사용 (layout prop이 없으면 디폴트 layout으로 렌더).
							SettingBtn 동작을 위해 SettingsMenu를 함께 마운트.
						*/}
						{validatedOptions.controls && initLoad && isPlayerReady && !isPremiereWaiting && isInitPlay && (
							<>
								<ControlBar
									layout={layout}
									onToggleVisibility={() => setIsActive((current) => !current)}
									onSetActive={(active) => setIsActive(active)}
								/>
								<SettingsMenu
									isVisible={isSettingMenu}
									isFullScreen={isFullScreen}
									onClose={() => setIsSettingMenu(false)}
									setQualityLevels={setQualityLevels}
									qualityLevels={qualityLevels}
									selectedQualityLevel={selectedQualityLevel}
									onQualityChange={handleQualityChange}
									playbackRate={playbackRate}
									onPlaybackRateChange={handlePlaybackRateChange}
									availableSubtitles={availableSubtitles}
									selectedSubtitle={selectedSubtitle}
									onSubtitleChange={handleSubtitleChange}
									playRateSetting={validatedOptions.playRateSetting}
								/>
							</>
						)}
					</View>
				) : (
					// 에러 화면
					<View style={styles.errorContainer}>
						<View style={styles.backButtonContainer}>
							<BackBtn />
						</View>
						{authError && (
							<>
								{ErrorOverride ? (
									<View style={styles.errorContent}>
										<ErrorOverride error={authError} />
									</View>
								) : (
									<View style={styles.errorContent}>
										<Image source={require('./assets/errorIcon.png')} style={styles.errorIcon} />
										<Text style={styles.errorTitle}>{authError.title}</Text>
										<Text style={styles.errorDesc}>{authError.desc}</Text>
									</View>
								)}
							</>
						)}
					</View>
				)}
			</>
		);

		// ====================================================================
		// PlayerContext value
		// ====================================================================
		//
		// 핸들러 안정화 패턴: VpePlayer 안에 인라인으로 정의된 핸들러들은 매 렌더마다
		// 새 함수가 생성된다. 이를 useCallback으로 감싸려면 6개 핸들러 모두 cascade로
		// 래핑해야 하고 deps 추적이 매우 복잡해진다.
		//
		// 대신 ref pattern을 쓴다: 매 렌더마다 ref만 갱신하고, context에는 ref.current를
		// 호출하는 한 번만 만들어진 안정 wrapper를 전달한다. 이 방식의 장점:
		// 1) 핸들러 정의 자체를 건드리지 않음
		// 2) context value의 액션 함수들이 매 렌더마다 동일한 참조 → consumer 리렌더 최소화
		// 3) deps 배열에 액션을 넣을 필요 없음 → eslint-disable 제거 가능

		const handlerRefs = useRef({
			togglePlay: handerPlayPause,
			seek: handerSeek,
			toggleMute: handerMuted,
			toggleFullScreen: handerFullScreen,
			next: handleNextVideo,
			prev: handlePrevVideo,
			toggleSettings: () => setIsSettingMenu((current) => !current),
			toggleSubtitle: handleToggleSubtitle,
		});

		// 매 렌더마다 ref를 최신 핸들러로 갱신 (commit phase에 즉시 반영해야 하므로 effect 아님)
		handlerRefs.current.togglePlay = handerPlayPause;
		handlerRefs.current.seek = handerSeek;
		handlerRefs.current.toggleMute = handerMuted;
		handlerRefs.current.toggleFullScreen = handerFullScreen;
		handlerRefs.current.next = handleNextVideo;
		handlerRefs.current.prev = handlePrevVideo;
		handlerRefs.current.toggleSubtitle = handleToggleSubtitle;

		// 한 번만 만들어지는 안정 액션 wrapper들 (참조는 항상 동일)
		const stableActions = useMemo(
			() => ({
				togglePlay: () => handlerRefs.current.togglePlay(),
				play: () => handlerRefs.current.togglePlay(),
				pause: () => handlerRefs.current.togglePlay(),
				seek: (s: number) => handlerRefs.current.seek([s]),
				toggleMute: () => handlerRefs.current.toggleMute(),
				toggleFullScreen: () => handlerRefs.current.toggleFullScreen(),
				toggleSettings: () => handlerRefs.current.toggleSettings(),
				toggleSubtitle: () => handlerRefs.current.toggleSubtitle(),
				next: () => handlerRefs.current.next(),
				prev: () => handlerRefs.current.prev(),
			}),
			[]
		);

		// skipForward/skipBack은 currentTime을 캡처해야 하므로 별도 처리
		const playerContextValue = useMemo<PlayerContextValue>(
			() => ({
				// 상태
				isPlaying,
				isFullScreen,
				isMuted,
				isLive,
				isDvr,
				isActive,
				isPremiere: isPremiereWaiting,
				isPip,
				isEnded,
				startPlay,
				currentTime,
				duration,
				playIdx,
				playlistCnt: validatedOptions.playlist?.length || 0,
				hasSubtitle: Array.isArray(availableSubtitles) && availableSubtitles.length > 0,
				selectedSubtitle,

				// 안정 액션
				...stableActions,

				// currentTime 의존 액션
				skipForward: (s = 10) => handlerRefs.current.seek([currentTime + s]),
				skipBack: (s = 10) => handlerRefs.current.seek([Math.max(0, currentTime - s)]),

				// 사용자 콜백/옵션
				events,
				validatedOptions,
			}),
			[
				isPlaying,
				isFullScreen,
				isMuted,
				isLive,
				isDvr,
				isActive,
				isPremiereWaiting,
				isPip,
				isEnded,
				startPlay,
				currentTime,
				duration,
				playIdx,
				validatedOptions,
				events,
				stableActions,
				availableSubtitles,
				selectedSubtitle,
			]
		);

		// ====================================================================
		// 최종 렌더링
		// ====================================================================

		return (
			<PlayerProvider value={playerContextValue}>
				{!isDestroyed && (
					<>
						{isFullScreen && validatedOptions.modalFullscreen ? (
							<Modal
								supportedOrientations={['portrait', 'landscape']}
								hardwareAccelerated
								statusBarTranslucent={true}
								presentationStyle={'fullScreen'}
							>
								<StatusBar hidden />
								<View style={[styles.modalFullscreenWrapper, { position: 'relative' }]}>
									{PlayerUI}
								</View>
							</Modal>
						) : (
							<View
								style={[
									isFullScreen && {
										backgroundColor: '#000000',
										maxHeight: '100%',
										height: '100%',
										justifyContent: 'center',
										alignItems: 'center',
									},
									{ position: 'relative' },
								]}
							>
								<View
									style={[
										styles.inlineWrapper,
										isFullScreen
											? { height: '100%' }
											: { aspectRatio: validatedOptions.aspectRatio },
									]}
								>
									{isFullScreen && <StatusBar hidden={true} />}

									{!uiInit && !isError && (
										<View style={styles.loadingWarp}>
											<View style={{ position: 'relative', width: '100%', height: '100%' }}>
												<View style={styles.loading}>
													<ActivityIndicator size="large" color={'#ffffff'} />
												</View>
											</View>
										</View>
									)}

									{PlayerUI}

									{!isInitPlay && (
										<View
											style={{
												position: 'absolute',
												left: 0,
												top: 0,
												width: '100%',
												height: '100%',

												zIndex: 10,
												backgroundColor: 'rgba(0,0,0,0.1)',
												opacity: uiInit ? 1 : 0,
											}}
										>
											<View
												style={{
													position: 'relative',
													justifyContent: 'center',
													alignItems: 'center',
													width: '100%',
													height: '100%',
												}}
											>
												{isPlaying ? (
													<ActivityIndicator size="large" color={'#ffffff'} />
												) : (
													<TouchableOpacity onPress={() => handerPlayPause()}>
														{renderIcon(
															validatedOptions.icon?.bigPlay,
															<PlayIcon size={40} color={'#ffffff'} weight={'fill'} />,
															{ imageStyle: { width: 40, height: 40 } }
														)}
													</TouchableOpacity>
												)}
											</View>
										</View>
									)}
								</View>
							</View>
						)}
					</>
				)}
			</PlayerProvider>
		);
	}
);

// ============================================================================
// 스타일 정의
// ============================================================================

const styles = StyleSheet.create({
	// 로딩 관련
	loadingWarp: {
		position: 'absolute',
		width: '100%',
		height: '100%',
		justifyContent: 'center',
		alignItems: 'center',
		flex: 1,
		zIndex: 99,
	},
	loading: {
		position: 'absolute',
		width: '100%',
		height: '100%',
		backgroundColor: 'rgba(0,0,0,0.1)',
		zIndex: 100,
		justifyContent: 'center',
		alignItems: 'center',
		flex: 1,
	},

	// 레이아웃
	inlineWrapper: {
		width: '100%',
		backgroundColor: '#000',
		position: 'relative',
		maxHeight: '100%',
		marginHorizontal: 'auto',
	},
	modalFullscreenWrapper: {
		flex: 1,
		backgroundColor: '#000',
	},
	videoContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#000',
	},
	videoView: {
		width: '100%',
		height: '100%',
	},

	// 에러 화면
	errorContainer: {
		alignItems: 'center',
		justifyContent: 'center',
		height: '100%',
		padding: 20,
	},
	errorContent: {
		alignItems: 'center',
	},
	errorIcon: {
		width: 100,
		height: 100,
		marginBottom: 5,
	},
	errorTitle: {
		color: '#ffffff',
		fontSize: 16,
		fontWeight: 'bold',
		textAlign: 'center',
		marginBottom: 8,
	},
	errorDesc: {
		fontSize: 12,
		color: 'rgba(255, 255, 255, 0.8)',
		textAlign: 'center',
	},

	// 프리미어 오버레이
	premiereOverlay: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		zIndex: 10,
		backgroundColor: 'rgba(0, 0, 0, 0.3)',
	},
	premiereContainer: {
		position: 'absolute',
		left: 0,
		bottom: 0,
		justifyContent: 'flex-start',
		alignItems: 'flex-end',
		zIndex: 10,
	},
	premiereWarp: {
		position: 'relative',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
		marginBottom: 20,
		marginLeft: 10,
		padding: 10,
		minWidth: 100,
		borderRadius: 8,
		alignItems: 'center',
		flexDirection: 'row',
		gap: 5,
	},
	premiereTitle: {
		color: '#ffffff',
		fontSize: 16,
		fontWeight: 'bold',
		marginBottom: 3,
	},
	premiereCountdown: {
		color: '#ffffff',
		fontSize: 13,
	},
	premiereStartTime: {
		color: 'rgba(255, 255, 255, 0.7)',
		fontSize: 12,
		marginTop: 2,
	},

	// 자막
	subTitleAreaWarp: {
		position: 'absolute',
		width: '100%',
		paddingHorizontal: 8,
		zIndex: 2,
		alignItems: 'center',
		justifyContent: 'center',
	},
	subTitleArea: {
		alignItems: 'center',
		justifyContent: 'center',
		paddingHorizontal: 15,
		paddingVertical: 2,
		backgroundColor: 'rgba(0, 0, 0, 0.4)',
	},
	subTitleText: {
		textAlign: 'center',
		color: '#ffffff',
		textShadowColor: '#000',
		textShadowOffset: { width: 0, height: 0 },
		textShadowRadius: 2,
		fontSize: 12,
	},
	textShadowDrop: {
		textShadowColor: 'rgba(0, 0, 0, 0.75)',
		textShadowOffset: { width: 1, height: 1 },
		textShadowRadius: 2,
	},
	textShadowRaised: {
		textShadowColor: 'rgba(0, 0, 0, 0.5)',
		textShadowOffset: { width: 1, height: 2 },
		textShadowRadius: 0,
	},
	textShadowDepressed: {
		textShadowColor: 'rgba(255, 255, 255, 0.5)',
		textShadowOffset: { width: -1, height: -2 },
		textShadowRadius: 0,
	},
	textShadowUniform: {
		textShadowColor: 'rgba(0, 0, 0, 1)',
		textShadowOffset: { width: 0, height: 0 },
		textShadowRadius: 3,
	},

	// 버튼
	backButtonContainer: {
		position: 'absolute',
		top: 0,
		left: 0,
		paddingVertical: 10,
		paddingLeft: 5,
	},
	roundedBtnOpa: {
		borderRadius: 100,
		backgroundColor: 'rgba(255,255,255,0)',
		color: '#ffffff',
		padding: 3,
		aspectRatio: 1 / 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
});

export default VpePlayer;
