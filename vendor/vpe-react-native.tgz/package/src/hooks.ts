import { useState, useEffect } from 'react';
import { Platform, Dimensions } from 'react-native';
import * as Application from 'expo-application';
import * as Network from 'expo-network';
import { keyCheck } from './keyCheck';
import { payCheck } from './payCheck';
import { maSyncInit, maSync, maInitConfig, thisSec } from './ma';
import * as $util from './util';
import t from './locales/i18n';

// ============================================================================
// 유틸리티 함수
// ============================================================================

/**
 * UUID v4 형식의 세션 ID를 생성합니다 (하이픈 있음)
 */
function generateUUIDv4(): string {
	const chars = 'abcdefghijklnmopqrstuvwxuz0123456789';
	const sections = [8, 4, 4, 4, 12];
	let uuid = '';

	sections.forEach((len, i) => {
		for (let j = 0; j < len; j++) {
			const randomIndex = Math.floor(Math.random() * chars.length);
			uuid += chars[randomIndex];
		}
		if (i < sections.length - 1) {
			uuid += '-';
		}
	});

	return uuid;
}

/**
 * 단순 세션 ID를 생성합니다 (하이픈 없음)
 */
function generateSessionId(): string {
	const chars = 'abcdefghijklnmopqrstuvwxuz0123456789';
	const sections = [8, 4, 4, 4, 12];
	let uuid = '';

	sections.forEach((len) => {
		for (let j = 0; j < len; j++) {
			const randomIndex = Math.floor(Math.random() * chars.length);
			uuid += chars[randomIndex];
		}
	});

	return uuid;
}

// ============================================================================
// 공개 함수
// ============================================================================

export const maSyncRun = async (playerInfo: any) => {
	await maSync(playerInfo);
};

export const tSec = () => {
	return thisSec();
};

// ============================================================================
// 키 인증 및 서버 옵션 관리 훅
// ============================================================================

/**
 * 키 인증, 서버 옵션 로딩 및 관련 에러 상태를 관리하는 훅
 *
 * @param accessKey - 액세스 키
 * @param platform - 플랫폼 ('pub' | 'gov')
 * @param stage - 환경 ('prod' | 'beta')
 * @param devTestAppId - 개발 모드에서 사용할 테스트 앱 ID
 * @param events - 이벤트 핸들러 객체
 */
export const useKeyAuthentication = (
	accessKey?: string,
	platform: string = 'pub',
	stage: string = 'prod',
	devTestAppId?: string,
	events: any = {},
	isDev: any
) => {
	// ========================================================================
	// 상태 정의
	// ========================================================================

	const [serverOptions, setServerOptions] = useState({});
	const [playerInfo, setPlayerInfo] = useState({});
	const [authError, setAuthError] = useState<{ title: string; desc: string } | null>(null);
	const [errorInfo, setErrorInfo] = useState<{ errorCode: string; errorMessage: string } | null>(null);
	const [isError, setError] = useState(false);

	// ========================================================================
	// 에러 처리 함수
	// ========================================================================

	/**
	 * 에러 상태를 설정하고 에러 로그를 출력합니다.
	 *
	 * @param errorCode - 에러 코드 (선택 항목)
	 */
	const setErrorRun = (errorCode?: string) => {
		if (errorCode) {
			const errorNo = errorCode.slice(-2);
			const errorData = t.error[errorNo] || t.error['01'];

			// 이벤트 핸들러 호출
			if (events?.error) {
				events.error({
					error_code: errorCode,
					error_message: errorData,
				});
			}

			// 에러 상태 업데이트
			setAuthError(errorData);
			setErrorInfo({
				errorCode: errorCode,
				errorMessage: errorData,
			});
			setError(true);
		} else {
			// 에러 상태 초기화
			setError(false);
			setAuthError(null);
		}
	};

	// ========================================================================
	// 키 인증 및 초기화
	// ========================================================================

	useEffect(() => {
		const performKeyCheck = async () => {
			// 앱 ID 가져오기
			let appId = Application.applicationId;
			if (__DEV__ && devTestAppId) {
				appId = devTestAppId;
			}
			//console.log('VPE Dev mode : ', __DEV__);
			console.log('VPE Init Player : ', appId, accessKey);

			// 에러 초기화
			setErrorRun();

			// 키 검증 실행
			if (!accessKey || !appId) {
				console.warn('VPE Player: accessKey 또는 appId가 없어 키 인증을 건너뜁니다.');
				setErrorRun('E0002');
				return;
			}

			try {
				// 키 체크 API 호출
				const config = await keyCheck(accessKey, appId, platform, stage, isDev);

				if (config.code !== 200) {
					setErrorRun('E0001');
					return;
				}

				// 서버 옵션 설정
				setServerOptions(config.result.options);

				// 플레이어 정보 생성
				const [playerName, playerVer] = config.result.name.split('|');
				const state = await Network.getNetworkStateAsync();
				const { width, height } = Dimensions.get('window');

				const playerInfo = {
					cid: config.result.cid,
					player_name: playerName,
					player_version: playerVer,
					pricing: config.result.pricing,
					maUse: config.result.options?.maUse === 'Y' ? 'Y' : 'N',
					browser: {
						lang: 'ko-KR',
						ua: `VPE React Native SDK - ${appId}`,
					},
					screen: { width, height },
					connection: {
						network: state.type,
						downlink: 1,
						rtt: 50,
						save_data: false,
					},
					device: {
						platform: Platform.OS,
						mobile: true,
						memory: 8,
						processor: 10,
					},
					video: {
						url: '',
					},
					extra: {
						vpeKey: accessKey,
						playerType: 'VPE',
						playerVersion: playerVer,
						device: Platform.OS,
						os: Platform.OS,
						osOrigin: Platform.OS,
						osVersion: Platform.Version,
						vpePackageId: appId,
						actionDuration: 0,
						actionType: 'ready',
						browser: 'NativeAPP',
						browserOrigin: Platform.OS,
						browserVersion: Platform.Version,
						protocol: 'https:',
						quality: 'Other',
						qualityOrigin: 'Auto',
						host: `${appId}&${Platform.OS}&${Platform.Version}`,
						location: `${appId}://appView/video/vpe`,
						title: '',
					},
				};

				setPlayerInfo(playerInfo);

				// MA 초기화
				await maSyncInit(platform, stage, playerInfo, appId, accessKey);
				await maInitConfig(accessKey);
			} catch (error) {
				setErrorRun('E0003');
			}
		};

		performKeyCheck();
	}, [accessKey, platform, stage, devTestAppId]);

	// ========================================================================
	// 반환값
	// ========================================================================

	return {
		serverOptions,
		authError,
		isError,
		setErrorRun,
		playerInfo,
		errorInfo,
	};
};

// ============================================================================
// HLS 플레이리스트 파싱 훅
// ============================================================================

/**
 * HLS 플레이리스트를 파싱하여 비디오 품질 수준 데이터와 자막을 설정하는 커스텀 훅
 *
 * @param playUrl - HLS 플레이리스트 URL
 * @param setQualityLevels - 비디오 품질 수준 데이터를 설정하는 상태 업데이트 함수
 * @param setManifestSubtitles - 자막 데이터를 설정하는 상태 업데이트 함수
 */
export const useHlsPlaylistParsing = (
	playUrl: string,
	setQualityLevels: React.Dispatch<React.SetStateAction<VideoQuality[]>>,
	setManifestSubtitles: React.Dispatch<React.SetStateAction<any[]>>
) => {
	useEffect(() => {
		let aborted = false;

		// M3U8 형식이 아니면 초기화하고 종료
		if (!playUrl || !(playUrl.includes('m3u8') || playUrl.includes('M3U8'))) {
			setManifestSubtitles([]);
			return;
		}

		(async () => {
			try {
				// 플레이리스트 가져오기
				const res = await fetch(playUrl);
				if (!res.ok) throw new Error(`HTTP ${res.status}`);

				const text = await res.text();
				if (aborted) return;

				// 자막 트랙 파싱
				const lines = text.split('\n');
				const subtitles = [];
				const baseUrl = playUrl.substring(0, playUrl.lastIndexOf('/') + 1);

				for (const line of lines) {
					if (line.startsWith('#EXT-X-MEDIA') && line.includes('TYPE=SUBTITLES')) {
						const uriMatch = line.match(/URI="([^"]+)"/);
						const langMatch = line.match(/LANGUAGE="([^"]+)"/);
						const nameMatch = line.match(/NAME="([^"]+)"/);
						const defaultMatch = line.match(/DEFAULT=(YES|NO)/);

						if (uriMatch?.[1]) {
							let subtitleUrl = uriMatch[1];

							// 상대 경로 -> 절대 경로 변환
							if (!subtitleUrl.startsWith('http')) {
								subtitleUrl = new URL(subtitleUrl, baseUrl).href;
							}

							subtitles.push({
								id: langMatch?.[1] || `sub_${subtitles.length}`,
								file: subtitleUrl,
								label: nameMatch?.[1] || langMatch?.[1] || 'Subtitle',
								default: defaultMatch ? defaultMatch[1] === 'YES' : false,
							});
						}
					}
				}

				setManifestSubtitles(subtitles);

				// 품질 레벨 파싱
				const parsed = $util.parseMasterPlaylist(text, playUrl);
				parsed.sort((a, b) => (b.bandwidth || 0) - (a.bandwidth || 0)); // 고화질 우선 정렬
				setQualityLevels(parsed);
			} catch (e) {
				console.error('HLS 플레이리스트 파싱에 실패했습니다:', e);
			}
		})();

		return () => {
			aborted = true;
		};
	}, [playUrl, setQualityLevels, setManifestSubtitles]);
};

// ============================================================================
// 라이브 스트림 감지 함수
// ============================================================================

/**
 * 비디오의 duration과 seekableDuration을 기반으로 라이브 스트림 여부를 판단합니다.
 *
 * @param duration - 비디오 전체 길이
 * @param seekableDuration - 탐색 가능한 길이
 * @returns 라이브 스트림 여부
 */
export const decideIsLive = ({
	duration,
	seekableDuration,
}: {
	duration: number | undefined;
	seekableDuration: number | undefined;
}): boolean => {
	let score = 0;

	// duration이 무한대이거나 0 이하인 경우 라이브 가능성 증가
	if (!isFinite(duration as number) || (duration ?? 0) <= 0) {
		score += 2;
	}

	// seekableDuration이 1시간 미만인 경우 라이브 가능성 증가
	if ((seekableDuration ?? 0) > 0 && (seekableDuration as number) < 3600) {
		score += 1;
	}

	return score >= 2;
};

// ============================================================================
// 컨트롤 가시성 관리 훅
// ============================================================================

/**
 * 재생 중에 컨트롤의 가시성을 자동으로 관리하는 훅
 *
 * @param isActive - 컨트롤이 활성 상태인지 여부
 * @param setIsActive - 활성 상태를 업데이트하는 함수
 * @param isPlaying - 현재 재생 중인지 여부
 * @param hideTimeout - 컨트롤 숨기기 전 대기 시간(밀리초)
 * @param controlsTimerRef - 타이머를 관리하는 ref
 */
export const useControlsVisibility = (
	isActive: boolean,
	setIsActive: React.Dispatch<React.SetStateAction<boolean>>,
	isPlaying: boolean,
	hideTimeout: number,
	controlsTimerRef: any
) => {
	useEffect(() => {
		// 기존 타이머 정리
		if (controlsTimerRef.current) {
			clearTimeout(controlsTimerRef.current);
		}

		// 재생 중이고 컨트롤이 활성화되어 있으면 타이머 설정
		if (isActive && isPlaying) {
			controlsTimerRef.current = setTimeout(() => {
				setIsActive(false);
			}, hideTimeout);
		}

		// 클린업
		return () => {
			if (controlsTimerRef.current) {
				clearTimeout(controlsTimerRef.current);
			}
		};
	}, [isActive, isPlaying, hideTimeout, setIsActive]);
};

// ============================================================================
// 결제 상태 확인 훅
// ============================================================================

/**
 * playerInfo를 기반으로 결제 상태를 비동기적으로 확인하는 훅
 *
 * @param playerInfo - 결제 상태를 확인할 플레이어 정보
 * @returns `boolean | null` - `true` (유효), `false` (유효하지 않음), `null` (확인 중)
 */
export const usePayCheck = (playerInfo: any): boolean | null => {
	const [isPaymentValid, setIsPaymentValid] = useState<boolean | null>(null);

	useEffect(() => {
		// playerInfo가 유효하지 않으면 체크를 실행하지 않음
		if (!playerInfo || Object.keys(playerInfo).length === 0) {
			return;
		}

		const performPayCheck = async () => {
			try {
				const isValid = await payCheck(playerInfo);
				setIsPaymentValid(isValid);
			} catch (error) {
				console.error('Payment check failed:', error);
				setIsPaymentValid(false); // 에러 발생 시 유효하지 않음으로 처리
			}
		};

		performPayCheck();
	}, [playerInfo]);

	return isPaymentValid;
};
