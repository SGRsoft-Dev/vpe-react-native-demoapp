import type { ControlBarLayoutInput, IconOverrides } from './layout/types';

export interface VpePlayerOptions {
	playlist?: { file: string }[];
	autostart?: boolean;
	muted?: boolean;
	aspectRatio?: string;
	objectFit?: 'contain' | 'cover' | 'fill' | 'scale-down';
	controls?: boolean;
	allowsPictureInPicture?: boolean;
	staysActiveInBackground?: boolean;
	screenRecordingPrevention?: boolean;
	modalFullscreen?: boolean;

	/**
	 * 아이콘 오버라이드. 각 키마다 ReactNode | string(URL) | number(require) | () => ReactNode 허용.
	 * (기존 props.icon은 폐지되고 이 위치로 이동됨)
	 */
	icon?: IconOverrides;

	keyboardShortcut?: boolean;
	touchGestures?: boolean;
	startMutedInfoNotVisible?: boolean;
	lang?: string;
	ui?: string;
	controlBtn?: {
		play?: boolean;
		fullscreen?: boolean;
		progressBar?: boolean;
		volume?: boolean;
		times?: boolean;
		pictureInPicture?: boolean;
		setting?: boolean;
		subtitle?: boolean;
	};
	progressBarColor?: string;
	controlActiveTime?: number;
	playRateSetting?: number[];
	autoPause?: boolean;
	repeat?: boolean;
	setStartTime?: string | null;
	playIndex?: number;
	lowLatencyMode?: boolean;
	descriptionNotVisible?: boolean;
	visibleWatermark?: boolean;
	watermarkText?: string;
	watermarkConfig?: {
		randPosition?: boolean;
		randPositionInterVal?: number;
		x?: number;
		y?: number;
		opacity?: number;
	};
	devTestAppId?: string;
	token?: string;
	override?: any;
	captionStyle: VpePlayerCaptionStyle;
}

export interface VpePlayerCaptionStyle {
	fontSize?: number;
	color?: string;
	backgroundColor?: string;
	edgeStyle?: 'none' | 'dropshadow' | 'raised' | 'depressed' | 'uniform';
}

export interface VpePlayerEvents {
	ready?: () => void;
	play?: () => void;
	pause?: () => void;
	ended?: () => void;
	seeking?: () => void;
	seeked?: () => void;
	waiting?: () => void;
	controlbarActive?: () => void;
	controlbarDeactive?: () => void;
	fullscreen_on?: () => void;
	fullscreen_off?: () => void;
	volumechange?: (data: any) => void;
	timeupdate?: (data: any) => void;
	prevTrack?: (data: any) => void;
	nextTrack?: (data: any) => void;
	fullscreen?: (data: any) => void;
	error?: (data: any) => void;
	/** 백버튼이 눌렸을 때 호출. 네비게이션 처리를 사용자가 담당. */
	backPress?: () => void;
}

export interface VpePlayerProps {
	options?: VpePlayerOptions;
	events?: VpePlayerEvents;
	accessKey?: string;
	devTestAppId?: string;
	platform?: 'gov' | 'pub';
	stage?: 'prod' | 'beta';
	customButton?: any;
	errorOverride?: any;
	override?: any;
	isDev?: any;
	/**
	 * ControlBar 사용자 정의 레이아웃.
	 * 미지정 시 디폴트(`defaultResponsiveLayout` — pcLayout/mobileLayout/fullscreenLayout) 사용.
	 *
	 * 단일 정의, live/vod variant, pc/mobile/fullscreen responsive 모두 허용.
	 */
	layout?: ControlBarLayoutInput;
}

/**
 * 사용자가 전달한 옵션과 기본 옵션을 병합하여 완전한 옵션 객체를 반환합니다.
 * @param options - 사용자가 VpePlayer에 전달한 옵션 객체
 * @returns 기본값이 채워진 완전한 옵션 객체
 */
export const getValidatedOptions = (options: VpePlayerOptions = {}): VpePlayerOptions => {
	const defaultOptions: VpePlayerOptions = {
		autostart: true,
		muted: false,
		aspectRatio: '16/9',
		objectFit: 'contain',
		controls: true,
		keyboardShortcut: false,
		startMutedInfoNotVisible: false,
		allowsPictureInPicture: false,
		staysActiveInBackground: false,
		screenRecordingPrevention: false,
		modalFullscreen: false,

		lang: 'ko',
		ui: 'all',
		controlBtn: {
			play: true,
			fullscreen: true,
			progressBar: true,
			volume: false,
			times: true,
			pictureInPicture: true,
			setting: true,
			subtitle: true,
		},
		progressBarColor: '#4299f5',
		controlActiveTime: 3000,
		playRateSetting: [0.5, 0.75, 1, 1.5, 2],
		autoPause: false,
		repeat: false,
		setStartTime: null,
		playIndex: 0,
		lowLatencyMode: true,
		touchGestures: true,
		descriptionNotVisible: false,
		devTestAppId: null,
		token: '',
		visibleWatermark: false,
		watermarkText: 'NAVER CLOUD PLATFORM',
		watermarkConfig: {
			randPosition: true,
			randPositionInterVal: 3000,
			x: 10,
			y: 10,
			opacity: 0.5,
		},
		captionStyle: {
			fontSize: 12,
			color: '#ffffff',
			backgroundColor: 'rgba(0, 0, 0, 0.4)',
			edgeStyle: 'dropshadow',
		},
		override: null,
	};

	// 기본 옵션 위에 사용자 옵션을 덮어씁니다. 중첩된 객체는 별도로 병합합니다.

	const validated = { ...defaultOptions, ...options };
	if (options.controlBtn) {
		validated.controlBtn = {
			...defaultOptions.controlBtn,
			...options.controlBtn,
		};
	}
	if (options.watermarkConfig) {
		validated.watermarkConfig = {
			...defaultOptions.watermarkConfig,
			...options.watermarkConfig,
		};
	}
	if (options.captionStyle) {
		validated.captionStyle = {
			...defaultOptions.captionStyle,
			...options.captionStyle,
		};
	}

	if (validated.objectFit == 'fill') {
		validated.objectFit = 'stretch';
	}

	if (validated.controlBtn.progressBar == undefined) {
		validated.controlBtn.progressBar = true;
	}
	return validated;
};
