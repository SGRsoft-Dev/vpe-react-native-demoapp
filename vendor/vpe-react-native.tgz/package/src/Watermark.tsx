import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, LayoutChangeEvent } from 'react-native';

interface WatermarkOption {
	randPosition?: boolean;
	randPositionInterVal?: number;
	x?: number;
	y?: number;
	opacity?: number;
	watermarkText?: string;
}

const Watermark: React.FC<WatermarkOption> = ({
	randPosition = false,
	randPositionInterVal = 3000,
	x = 10,
	y = 10,
	opacity = 0.5,
	watermarkText = 'NAVER CLOUD PLATFORM',
}) => {
	const [xPos, setXpos] = useState(x);
	const [yPos, setYpos] = useState(y);
	const [containerLayout, setContainerLayout] = useState({ width: 0, height: 0 });
	const [textLayout, setTextLayout] = useState({ width: 0, height: 0 });

	useEffect(() => {
		// randPosition이 false이면 원래 위치로 되돌리고, 아무것도 하지 않습니다.
		if (!randPosition) {
			setXpos(x);
			setYpos(y);
			return;
		}

		// 컨테이너의 크기를 아직 모르면(onLayout 전) 인터벌을 시작하지 않습니다.
		if (containerLayout.width === 0 || textLayout.width === 0) {
			return;
		}

		// randPosition이 true일 때만 인터벌을 설정합니다.
		const intervalId = setInterval(() => {
			const { width: containerWidth, height: containerHeight } = containerLayout;
			const { width: textWidth, height: textHeight } = textLayout;

			// 텍스트의 실제 크기를 기반으로 최대 X, Y 좌표의 퍼센티지를 계산합니다.
			const maxXPercent = ((containerWidth - textWidth) / containerWidth) * 100;
			const maxYPercent = ((containerHeight - textHeight) / containerHeight) * 100;

			// 0과 최대 퍼센티지 사이의 랜덤 값을 생성합니다.
			// 컨테이너가 텍스트보다 작을 경우 음수가 될 수 있으므로 0 이상으로 제한합니다.
			const newX = Math.random() * Math.max(0, maxXPercent);
			const newY = Math.random() * Math.max(0, maxYPercent);

			setXpos(newX);
			setYpos(newY);
		}, randPositionInterVal);

		// 컴포넌트 언마운트 또는 의존성 변경 시 인터벌을 정리합니다.
		return () => clearInterval(intervalId);
	}, [randPosition, randPositionInterVal, x, y, containerLayout, textLayout]);

	const onContainerLayout = (event: LayoutChangeEvent) => {
		const { width, height } = event.nativeEvent.layout;
		setContainerLayout({ width, height });
	};

	const onTextLayout = (event: LayoutChangeEvent) => {
		const { width, height } = event.nativeEvent.layout;
		setTextLayout({ width, height });
	};

	return (
		<View style={styles.warp} onLayout={onContainerLayout}>
			<View style={styles.textObjWarp}>
				<Text
					style={[
						styles.textObj,
						{
							opacity: opacity,
							top: yPos <= 50 ? `${yPos}%` : 'auto',
							left: xPos <= 50 ? `${xPos}%` : 'auto',
							right: xPos > 50 ? `${100 - xPos}%` : 'auto',
							bottom: yPos > 50 ? `${100 - yPos}%` : 'auto',
						},
					]}
					onLayout={onTextLayout}
				>
					{watermarkText}
				</Text>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	warp: {
		position: 'absolute',
		width: '100%',
		height: '100%',
		zIndex: 3,
		top: 0,
		left: 0,
	},
	textObjWarp: {
		position: 'relative',
		width: '100%',
		height: '100%',
	},
	textObj: {
		position: 'absolute',
		top: 10,
		left: 10,
		opacity: 0.5,
		color: '#ffffff',
		zIndex: 3,
		fontSize: 12,
	},
});

export default Watermark;
