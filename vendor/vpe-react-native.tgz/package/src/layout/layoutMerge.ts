import type {
	ControlBarLayout,
	ControlBarLayoutGroup,
	ControlBarLayoutInput,
	ControlBarLayoutResponsive,
	ControlBarLayoutVariant,
} from './types';

/**
 * 사용자가 layout prop으로 넘긴 값과 디폴트를 병합한다.
 *
 * 입력은 세 형태 중 하나:
 * 1. ControlBarLayout — 단일 정의 (sections만)
 * 2. ControlBarLayoutVariant — { live, vod }
 * 3. ControlBarLayoutResponsive — { pc, mobile, fullscreen, breakpoint }
 *
 * 병합 규칙: 사용자가 명시한 값으로 디폴트를 덮어쓴다.
 * 섹션/그룹 단위로 replace (deep merge가 아님). 사용자가 한 섹션을 지정하면 통째로 교체.
 */

// ----------------------------------------------------------------------------
// 타입 가드
// ----------------------------------------------------------------------------

function isLayoutDefinition(value: unknown): value is ControlBarLayout {
	if (!value || typeof value !== 'object') return false;
	const v = value as Record<string, unknown>;
	return 'top' in v || 'upper' in v || 'center' in v || 'lower' in v || 'bottom' in v || 'order' in v;
}

function isLayoutVariant(value: unknown): value is ControlBarLayoutVariant {
	if (!value || typeof value !== 'object') return false;
	const v = value as Record<string, unknown>;
	return 'live' in v || 'vod' in v;
}

function isLayoutResponsive(value: unknown): value is ControlBarLayoutResponsive {
	if (!value || typeof value !== 'object') return false;
	const v = value as Record<string, unknown>;
	return 'pc' in v || 'mobile' in v || 'fullscreen' in v || 'breakpoint' in v;
}

// ----------------------------------------------------------------------------
// section/group 병합
// ----------------------------------------------------------------------------

function mergeGroups(
	base: ControlBarLayoutGroup[] | undefined,
	next: ControlBarLayoutGroup[] | undefined
): ControlBarLayoutGroup[] | undefined {
	if (next !== undefined) return next;
	return base;
}

function mergeOrder(base: ControlBarLayout['order'], next: ControlBarLayout['order']): ControlBarLayout['order'] {
	if (next !== undefined) return next;
	return base;
}

function mergeLayoutDefinition(
	base: ControlBarLayout | undefined,
	next: ControlBarLayout | undefined
): ControlBarLayout {
	const b = base ?? {};
	const n = next ?? {};
	return {
		top: mergeGroups(b.top, n.top),
		upper: mergeGroups(b.upper, n.upper),
		center: mergeGroups(b.center, n.center),
		lower: mergeGroups(b.lower, n.lower),
		bottom: mergeGroups(b.bottom, n.bottom),
		order: mergeOrder(b.order, n.order),
		iconSize: n.iconSize ?? b.iconSize,
	};
}

// ----------------------------------------------------------------------------
// variant 병합
// ----------------------------------------------------------------------------

function normalizeVariant(value: ControlBarLayout | ControlBarLayoutVariant | undefined): ControlBarLayoutVariant {
	if (!value) return {};
	if (isLayoutVariant(value)) return value;
	if (isLayoutDefinition(value)) {
		// 단일 정의는 live/vod 둘 다에 동일하게 적용
		return { live: value, vod: value };
	}
	return {};
}

function mergeLayoutVariant(
	base: ControlBarLayoutVariant | undefined,
	next: ControlBarLayoutVariant | undefined
): ControlBarLayoutVariant {
	const b = normalizeVariant(base);
	const n = normalizeVariant(next);
	return {
		live: mergeLayoutDefinition(b.live, n.live),
		vod: mergeLayoutDefinition(b.vod, n.vod),
	};
}

// ----------------------------------------------------------------------------
// responsive 병합
// ----------------------------------------------------------------------------

function toResponsive(value: ControlBarLayoutInput | undefined): ControlBarLayoutResponsive {
	if (!value) return {};
	if (isLayoutResponsive(value)) return value;
	if (isLayoutVariant(value) || isLayoutDefinition(value)) {
		// 단일 정의/variant는 모든 모드에 적용
		return { pc: value, mobile: value, fullscreen: value };
	}
	return {};
}

export function mergeResponsiveLayout(
	base: ControlBarLayoutResponsive | undefined,
	next: ControlBarLayoutResponsive | undefined
): ControlBarLayoutResponsive {
	const b = base ?? {};
	const n = next ?? {};
	return {
		pc: mergeLayoutVariant(normalizeVariant(b.pc), normalizeVariant(n.pc)),
		mobile: mergeLayoutVariant(normalizeVariant(b.mobile), normalizeVariant(n.mobile)),
		fullscreen: mergeLayoutVariant(normalizeVariant(b.fullscreen), normalizeVariant(n.fullscreen)),
		breakpoint: n.breakpoint ?? b.breakpoint,
	};
}

/**
 * 메인 export — 디폴트 + 사용자 입력을 병합한다.
 * 사용자가 layout prop을 안 넘기면 디폴트만 반환.
 */
export function mergeLayouts(
	defaultLayout: ControlBarLayoutResponsive,
	userLayout: ControlBarLayoutInput | undefined
): ControlBarLayoutResponsive {
	if (!userLayout) return defaultLayout;
	return mergeResponsiveLayout(defaultLayout, toResponsive(userLayout));
}
