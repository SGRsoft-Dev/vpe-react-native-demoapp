import React, { isValidElement } from 'react';

import type { ControlBarLayoutItem, ControlBarLayoutItemName } from './types';

import PlayBtn from '../controls/PlayBtn';
import BigPlayBtn from '../controls/BigPlayBtn';
import VolumeBtn from '../controls/VolumeBtn';
import MuteBtn from '../controls/MuteBtn';
import TimeBtn from '../controls/TimeBtn';
import CurrentTimeBtn from '../controls/CurrentTimeBtn';
import DurationBtn from '../controls/DurationBtn';
import SeekBar from '../controls/SeekBar';
import FullscreenBtn from '../controls/FullscreenBtn';
import SubtitleBtn from '../controls/SubtitleBtn';
import SettingBtn from '../controls/SettingBtn';
import PrevBtn from '../controls/PrevBtn';
import NextBtn from '../controls/NextBtn';
import NextPrevBtn from '../controls/NextPrevBtn';
import MetaDesc from '../controls/MetaDesc';
import BackBtn from '../controls/BackBtn';
import ShareBtn from '../controls/ShareBtn';
import SkipForwardBtn from '../controls/SkipForwardBtn';
import SkipBackBtn from '../controls/SkipBackBtn';
import NextVideoInfo from '../controls/NextVideoInfo';

/**
 * 레이아웃 아이템 이름 → 컴포넌트 매핑.
 *
 * 알려진 이름이면 해당 컴포넌트를 렌더하고,
 * 이미 ReactElement인 경우 그대로 반환한다.
 * 알 수 없는 이름이면 null을 반환한다.
 *
 * Blank는 ControlBarSection 쪽에서 wrapper 처리에 흡수되므로 여기선 null.
 */
export function renderControlItem(item: ControlBarLayoutItem, key?: string | number): React.ReactNode {
	if (item === null || item === undefined) return null;

	// 이미 React 요소(직접 JSX 전달)면 그대로
	if (isValidElement(item)) {
		return key !== undefined ? React.cloneElement(item, { key }) : item;
	}

	if (typeof item !== 'string') {
		// ReactNode 배열이나 fragment는 그대로 반환
		return item as React.ReactNode;
	}

	const name = item as ControlBarLayoutItemName;
	switch (name) {
		case 'PlayBtn':
			return <PlayBtn key={key} />;
		case 'BigPlayBtn':
			return <BigPlayBtn key={key} />;
		case 'VolumeBtn':
			return <VolumeBtn key={key} />;
		case 'MuteBtn':
			return <MuteBtn key={key} />;
		case 'TimeBtn':
			return <TimeBtn key={key} />;
		case 'CurrentTimeBtn':
			return <CurrentTimeBtn key={key} />;
		case 'DurationBtn':
			return <DurationBtn key={key} />;
		case 'SeekBar':
			return <SeekBar key={key} />;
		case 'FullscreenBtn':
			return <FullscreenBtn key={key} />;
		case 'SubtitleBtn':
			return <SubtitleBtn key={key} />;
		case 'SettingBtn':
			return <SettingBtn key={key} />;
		case 'PrevBtn':
			return <PrevBtn key={key} />;
		case 'NextBtn':
			return <NextBtn key={key} />;
		case 'NextPrevBtn':
			return <NextPrevBtn key={key} />;
		case 'MetaDesc':
			return <MetaDesc key={key} />;
		case 'BackBtn':
			return <BackBtn key={key} />;
		case 'ShareBtn':
			return <ShareBtn key={key} />;
		case 'SkipForwardBtn':
			return <SkipForwardBtn key={key} />;
		case 'SkipBackBtn':
			return <SkipBackBtn key={key} />;
		case 'NextVideoInfo':
			return <NextVideoInfo key={key} />;
		case 'SettingModal':
			// SettingModal은 ControlBar 외부(VpePlayer)에서 직접 렌더하므로 여기선 null
			return null;
		case 'Blank':
			// Blank는 group wrapper에서 처리되므로 단일 아이템으로는 null
			return null;
		default:
			// 알 수 없는 이름
			return null;
	}
}
