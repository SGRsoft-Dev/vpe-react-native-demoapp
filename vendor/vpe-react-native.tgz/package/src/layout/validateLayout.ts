import { VALID_ALIGNS, VALID_LAYOUT_ITEM_NAMES, VALID_ORDER_KEYS, VALID_SECTION_KEYS, VALID_WRAPPERS } from './types';
import type {
	ControlBarLayout,
	ControlBarLayoutGroup,
	ControlBarLayoutInput,
	ControlBarLayoutResponsive,
	ControlBarLayoutVariant,
} from './types';

/**
 * 사용자가 넘긴 layout 정의를 검증하여 발견된 문제를 문자열 배열로 반환한다.
 *
 * 검증 항목:
 * - 알 수 없는 itemName (오타 등)
 * - 잘못된 wrapper (`Group`/`Blank` 외)
 * - 잘못된 align (`left`/`right`/`center` 외)
 * - 빈 그룹 items (필수는 아니지만 dev 경고)
 * - order 항목이 유효한지 (`top`/`upper`/`center`/`seekbar`/`lower`/`bottom`)
 * - cap 음수
 *
 * 빈 배열을 반환하면 문제 없음.
 */
export function validateLayout(input: ControlBarLayoutInput | undefined): string[] {
	if (!input || typeof input !== 'object') return [];

	const issues: string[] = [];

	const validateGroup = (group: ControlBarLayoutGroup | undefined, ctx: string) => {
		if (!group || typeof group !== 'object') {
			issues.push(`${ctx}: group is not an object`);
			return;
		}
		if (group.wrapper !== undefined && !VALID_WRAPPERS.has(group.wrapper)) {
			issues.push(`${ctx}: unknown wrapper "${group.wrapper}" (expected: Group | Blank)`);
		}
		if (group.align !== undefined && !VALID_ALIGNS.has(group.align)) {
			issues.push(`${ctx}: unknown align "${group.align}" (expected: left | right | center)`);
		}
		if (group.cap !== undefined && (typeof group.cap !== 'number' || group.cap < 0)) {
			issues.push(`${ctx}: cap must be a non-negative number, got ${String(group.cap)}`);
		}
		if (!Array.isArray(group.items)) {
			issues.push(`${ctx}: items must be an array`);
			return;
		}
		group.items.forEach((item, idx) => {
			if (typeof item !== 'string') return; // ReactNode는 검증 스킵
			if (!VALID_LAYOUT_ITEM_NAMES.has(item)) {
				issues.push(`${ctx}.items[${idx}]: unknown itemName "${item}"`);
			}
		});
	};

	const validateDefinition = (def: ControlBarLayout | undefined, ctx: string) => {
		if (!def || typeof def !== 'object') return;

		// 알 수 없는 키 검사 (sections + order + iconSize 외)
		const knownKeys = new Set(['top', 'upper', 'center', 'lower', 'bottom', 'order', 'iconSize']);
		Object.keys(def).forEach((k) => {
			if (!knownKeys.has(k)) {
				issues.push(
					`${ctx}: unknown key "${k}" (expected: top | upper | center | lower | bottom | order | iconSize)`
				);
			}
		});

		// iconSize 검증
		if (def.iconSize !== undefined && (typeof def.iconSize !== 'number' || def.iconSize <= 0)) {
			issues.push(`${ctx}.iconSize: must be a positive number, got ${String(def.iconSize)}`);
		}

		// 각 섹션 검증
		(['top', 'upper', 'center', 'lower', 'bottom'] as const).forEach((sec) => {
			const groups = def[sec];
			if (groups === undefined) return;
			if (!Array.isArray(groups)) {
				issues.push(`${ctx}.${sec}: must be an array of groups`);
				return;
			}
			groups.forEach((g, gi) => validateGroup(g, `${ctx}.${sec}[${gi}]`));
		});

		// order 검증
		if (def.order !== undefined) {
			if (!Array.isArray(def.order)) {
				issues.push(`${ctx}.order: must be an array`);
			} else {
				def.order.forEach((k, idx) => {
					if (!VALID_ORDER_KEYS.has(k as string)) {
						issues.push(
							`${ctx}.order[${idx}]: unknown key "${String(k)}" (expected: ${Array.from(VALID_ORDER_KEYS).join(' | ')})`
						);
					}
				});
			}
		}
	};

	const validateVariant = (variant: ControlBarLayoutVariant | ControlBarLayout | undefined, ctx: string) => {
		if (!variant || typeof variant !== 'object') return;
		const v = variant as Record<string, unknown>;

		// variant({live, vod})인지 단일 정의인지 판단
		const hasVariantKeys = 'live' in v || 'vod' in v;
		const hasDefinitionKeys = ['top', 'upper', 'center', 'lower', 'bottom', 'order'].some((k) => k in v);

		if (hasVariantKeys) {
			validateDefinition(v.live as ControlBarLayout | undefined, `${ctx}.live`);
			validateDefinition(v.vod as ControlBarLayout | undefined, `${ctx}.vod`);
		} else if (hasDefinitionKeys) {
			validateDefinition(v as ControlBarLayout, ctx);
		}
	};

	const i = input as Record<string, unknown>;
	const isResponsive = 'pc' in i || 'mobile' in i || 'fullscreen' in i || 'breakpoint' in i;

	if (isResponsive) {
		const r = input as ControlBarLayoutResponsive;
		if (r.breakpoint !== undefined && (typeof r.breakpoint !== 'number' || r.breakpoint <= 0)) {
			issues.push(`layout.breakpoint: must be a positive number, got ${String(r.breakpoint)}`);
		}
		validateVariant(r.pc, 'layout.pc');
		validateVariant(r.mobile, 'layout.mobile');
		validateVariant(r.fullscreen, 'layout.fullscreen');

		// 알 수 없는 최상위 키
		const knownTop = new Set(['pc', 'mobile', 'fullscreen', 'breakpoint']);
		Object.keys(i).forEach((k) => {
			if (!knownTop.has(k)) {
				// definition/variant 키가 같이 있으면 사용자가 단일 정의로 의도한 것일 수 있으므로
				// VALID_SECTION_KEYS와 'order'/'live'/'vod'는 별도 처리
				if (!VALID_SECTION_KEYS.has(k) && k !== 'order' && k !== 'live' && k !== 'vod') {
					issues.push(`layout: unknown top-level key "${k}"`);
				}
			}
		});
	} else {
		// variant 또는 단일 정의
		validateVariant(input as ControlBarLayoutVariant | ControlBarLayout, 'layout');
	}

	return issues;
}

/**
 * dev 모드에서 layout 검증을 수행하고 문제가 있으면 console.warn으로 출력.
 * production에서는 no-op.
 */
export function warnLayoutIssues(input: ControlBarLayoutInput | undefined): void {
	if (!__DEV__) return;
	const issues = validateLayout(input);
	if (issues.length === 0) return;
	// 한 번에 그룹화해서 출력
	// eslint-disable-next-line no-console
	console.warn(
		`[VpePlayer] layout 정의에 ${issues.length}개의 문제가 발견되었습니다:\n` +
			issues.map((s) => `  • ${s}`).join('\n')
	);
}
