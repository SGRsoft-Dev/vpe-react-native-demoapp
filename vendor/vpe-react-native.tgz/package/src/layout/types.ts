import type { ReactNode } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';

/**
 * IconOverrides 값으로 허용되는 타입.
 * - ReactNode: JSX 요소를 그대로 전달 (e.g. <CaretLeftIcon size={22} />)
 * - string: 원격 이미지 URL (Image source={{uri}}로 렌더)
 * - number: require('./icon.png') 결과 (로컬 에셋)
 * - () => ReactNode: 동적 렌더링용 함수형
 */
export type IconValue = ReactNode | string | number | (() => ReactNode);

/**
 * 모든 컨트롤 버튼 아이콘에 대한 사용자 오버라이드.
 * 웹 SDK의 IconOverrides 키 + RN 추가 키.
 */
export interface IconOverrides {
	// 재생/일시정지/리플레이
	bigPlay?: IconValue;
	play?: IconValue;
	pause?: IconValue;
	replay?: IconValue;

	// 트랙 이동
	prev?: IconValue;
	next?: IconValue;

	// 자막
	subtitle?: IconValue;
	subtitleOff?: IconValue;

	// 전체화면
	fullscreen?: IconValue;
	fullscreenExit?: IconValue;

	// 볼륨
	volumeFull?: IconValue;
	volumeMid?: IconValue;
	volumeMute?: IconValue;

	// 기타
	setting?: IconValue;

	// RN 추가 키
	back?: IconValue;
	share?: IconValue;
	skipForward?: IconValue;
	skipBack?: IconValue;
}

/**
 * 레이아웃 아이템 이름 (문자열로 지정 가능한 컨트롤 컴포넌트들).
 */
export type ControlBarLayoutItemName =
	| 'PlayBtn'
	| 'VolumeBtn'
	| 'TimeBtn'
	| 'SubtitleBtn'
	| 'FullscreenBtn'
	| 'SettingBtn'
	| 'MetaDesc'
	| 'BigPlayBtn'
	| 'SeekBar'
	| 'SettingModal'
	| 'DurationBtn'
	| 'SkipForwardBtn'
	| 'SkipBackBtn'
	| 'CurrentTimeBtn'
	| 'MuteBtn'
	| 'PrevBtn'
	| 'NextBtn'
	| 'NextPrevBtn'
	| 'ShareBtn'
	| 'BackBtn'
	| 'NextVideoInfo'
	| 'Blank';

/**
 * 레이아웃 아이템: 이름 문자열 또는 임의의 ReactNode.
 */
export type ControlBarLayoutItem = ControlBarLayoutItemName | ReactNode;

/**
 * 레이아웃 그룹: 한 줄(섹션) 안에서 묶여 렌더되는 아이템 묶음.
 */
export interface ControlBarLayoutGroup {
	key?: string;
	items: ControlBarLayoutItem[];
	noPadding?: boolean;
	cap?: number;
	wrapper?: 'Blank' | 'Group';
	align?: 'left' | 'right' | 'center';
	style?: StyleProp<ViewStyle>;
}

/**
 * 레이아웃 정의 (단일 모드, 단일 변형).
 * 섹션별로 그룹 배열을 갖는다.
 */
export interface ControlBarLayout {
	top?: ControlBarLayoutGroup[];
	upper?: ControlBarLayoutGroup[];
	center?: ControlBarLayoutGroup[];
	lower?: ControlBarLayoutGroup[];
	bottom?: ControlBarLayoutGroup[];
	order?: Array<'top' | 'upper' | 'center' | 'seekbar' | 'lower' | 'bottom'>;
	/**
	 * 이 layout 안의 아이콘 컨트롤들이 사용할 디폴트 사이즈.
	 * 컨트롤이 자체 size prop을 명시하지 않은 경우만 적용된다.
	 */
	iconSize?: number;
}

/**
 * VOD/Live 변형. 둘 다 없으면 부모 단계가 처리.
 */
export interface ControlBarLayoutVariant {
	live?: ControlBarLayout;
	vod?: ControlBarLayout;
}

/**
 * 반응형 레이아웃: pc / mobile / fullscreen + breakpoint.
 * 각 키는 단일 정의 또는 live/vod 변형을 가질 수 있다.
 */
export interface ControlBarLayoutResponsive {
	pc?: ControlBarLayout | ControlBarLayoutVariant;
	mobile?: ControlBarLayout | ControlBarLayoutVariant;
	fullscreen?: ControlBarLayout | ControlBarLayoutVariant;
	breakpoint?: number;
}

/**
 * 사용자가 layout prop으로 넘길 수 있는 모든 형태.
 */
export type ControlBarLayoutInput = ControlBarLayout | ControlBarLayoutVariant | ControlBarLayoutResponsive;

/**
 * UI 강제 모드.
 */
export type UiMode = 'pc' | 'mobile' | 'fullscreen';

/**
 * 모바일 판단 기본 breakpoint (px).
 */
export const DEFAULT_MOBILE_BREAKPOINT = 768;

/**
 * 유효한 ControlBarLayoutItemName 전체 (검증 헬퍼용).
 */
export const VALID_LAYOUT_ITEM_NAMES: ReadonlySet<string> = new Set<ControlBarLayoutItemName>([
	'PlayBtn',
	'VolumeBtn',
	'TimeBtn',
	'SubtitleBtn',
	'FullscreenBtn',
	'SettingBtn',
	'MetaDesc',
	'BigPlayBtn',
	'SeekBar',
	'SettingModal',
	'DurationBtn',
	'SkipForwardBtn',
	'SkipBackBtn',
	'CurrentTimeBtn',
	'MuteBtn',
	'PrevBtn',
	'NextBtn',
	'NextPrevBtn',
	'ShareBtn',
	'BackBtn',
	'NextVideoInfo',
	'Blank',
]);

/**
 * 유효한 wrapper 값 (검증 헬퍼용).
 */
export const VALID_WRAPPERS: ReadonlySet<string> = new Set(['Group', 'Blank']);

/**
 * 유효한 align 값 (검증 헬퍼용).
 */
export const VALID_ALIGNS: ReadonlySet<string> = new Set(['left', 'right', 'center']);

/**
 * 유효한 섹션 키 (검증 헬퍼용).
 */
export const VALID_SECTION_KEYS: ReadonlySet<string> = new Set(['top', 'upper', 'center', 'lower', 'bottom']);

/**
 * 유효한 order 항목 (섹션 키 + 'seekbar' 슬롯).
 */
export const VALID_ORDER_KEYS: ReadonlySet<string> = new Set(['top', 'upper', 'center', 'seekbar', 'lower', 'bottom']);
