import type { ControlBarLayout, ControlBarLayoutResponsive, ControlBarLayoutVariant } from './types';

/**
 * 디폴트 레이아웃 정의.
 * 웹 SDK의 useLayout.ts 변형 — RN 환경에 맞게 일부 조정.
 *
 * 결정사항:
 * - BackBtn은 pcLayout/mobileLayout의 top 최왼쪽에만 포함
 * - fullscreenLayout에서는 BackBtn 제외 (사용자가 명시 시에만)
 * - SeekBar는 별도 'seekbar' section 또는 lower section에 포함
 */

// ----------------------------------------------------------------------------
// PC (Tablet/Web) Layout
// ----------------------------------------------------------------------------

// 디폴트 아이콘 사이즈 (각 layout이 직접 override 가능)
const PC_ICON_SIZE = 19;
const MOBILE_ICON_SIZE = 19;
const FULLSCREEN_ICON_SIZE = 22;

const pcVod: ControlBarLayout = {
	iconSize: PC_ICON_SIZE,
	top: [
		{ items: ['BackBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['MetaDesc'], wrapper: 'Blank' },
		{ items: ['MuteBtn', 'SettingBtn'], wrapper: 'Group', align: 'right', cap: 2 },
	],
	center: [{ items: ['BigPlayBtn'], wrapper: 'Blank', align: 'center' }],
	lower: [{ items: ['SeekBar'], wrapper: 'Blank' }],
	bottom: [
		{ items: ['PlayBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['NextPrevBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['VolumeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['TimeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['Blank'], wrapper: 'Blank' },
		{
			items: ['SubtitleBtn', 'SettingBtn', 'FullscreenBtn'],
			wrapper: 'Group',
			align: 'right',
			cap: 3,
		},
	],
};

const pcLive: ControlBarLayout = {
	iconSize: PC_ICON_SIZE,
	top: [
		{ items: ['BackBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['MetaDesc'], wrapper: 'Blank' },
		{ items: ['MuteBtn', 'SettingBtn'], wrapper: 'Group', align: 'right', cap: 2 },
	],
	center: [{ items: ['BigPlayBtn'], wrapper: 'Blank', align: 'center' }],
	bottom: [
		{ items: ['PlayBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['VolumeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['TimeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['Blank'], wrapper: 'Blank' },
		{
			items: ['SubtitleBtn', 'SettingBtn', 'FullscreenBtn'],
			wrapper: 'Group',
			align: 'right',
			cap: 3,
		},
	],
};

export const pcLayout: ControlBarLayoutVariant = { vod: pcVod, live: pcLive };

// ----------------------------------------------------------------------------
// Mobile Layout (세로 모드)
// ----------------------------------------------------------------------------

const mobileVod: ControlBarLayout = {
	iconSize: MOBILE_ICON_SIZE,
	order: ['top', 'center', 'bottom', 'seekbar'],
	top: [
		{ items: ['BackBtn'], wrapper: 'Group' },
		{ wrapper: 'Blank', items: [], align: 'left' },
		{
			items: ['MuteBtn', 'SettingBtn'],
			cap: 2,
			wrapper: 'Group',
			style: {
				gap: 10,
				paddingVertical: 3,
				paddingHorizontal: 10,
				alignItems: 'center',
			},
		},
	],
	center: [{ items: ['BigPlayBtn'], align: 'center' }],
	bottom: [
		{ wrapper: 'Group', items: ['TimeBtn'], align: 'left' },
		{
			wrapper: 'Blank',
			items: [],
		},
		{
			wrapper: 'Group',
			items: ['SubtitleBtn', 'FullscreenBtn'],
			align: 'right',
			style: {
				gap: 10,
				paddingVertical: 3,
				paddingHorizontal: 10,

				alignItems: 'center',
			},
		},
	],
};

const mobileLive: ControlBarLayout = {
	iconSize: MOBILE_ICON_SIZE,
	order: ['top', 'center', 'bottom', 'seekbar'],
	top: [
		{
			items: ['BackBtn'],
			wrapper: 'Group',
			style: {
				gap: 10,
				paddingVertical: 3,
				paddingHorizontal: 10,
				alignItems: 'center',
			},
		},
		{ wrapper: 'Blank', items: [], align: 'left' },
		{
			items: ['MuteBtn', 'SettingBtn'],
			cap: 2,
			wrapper: 'Group',
			style: {
				gap: 10,
				paddingVertical: 3,
				paddingHorizontal: 10,
				alignItems: 'center',
			},
		},
	],
	center: [{ items: ['BigPlayBtn'], align: 'center' }],
	bottom: [
		{ wrapper: 'Group', items: ['TimeBtn'], align: 'left' },
		{
			wrapper: 'Blank',
			items: [],
		},
		{
			wrapper: 'Group',
			items: ['SubtitleBtn', 'FullscreenBtn'],
			align: 'right',
			style: {
				gap: 10,
				paddingVertical: 3,
				paddingHorizontal: 10,

				alignItems: 'center',
			},
		},
	],
};

export const mobileLayout: ControlBarLayoutVariant = { vod: mobileVod, live: mobileLive };

// ----------------------------------------------------------------------------
// Fullscreen Layout (BackBtn 없음)
// ----------------------------------------------------------------------------

const fullscreenVod: ControlBarLayout = {
	iconSize: FULLSCREEN_ICON_SIZE,
	order: ['top', 'center', 'lower', 'bottom'],
	iconSize: 26,
	top: [
		{ items: ['MetaDesc'], wrapper: 'Blank', noPadding: false, style: { paddingTop: 8, paddingLeft: 5 } },
		{
			items: ['SettingBtn'],
			wrapper: 'Group',
			align: 'right',
			noPadding: false,
		},
	],
	center: [{ items: ['BigPlayBtn'], wrapper: 'Blank', align: 'center' }],

	bottom: [
		{ items: ['TimeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['Blank'], wrapper: 'Blank' },
		{
			items: ['SubtitleBtn', 'FullscreenBtn'],
			wrapper: 'Group',
			align: 'right',
			style: {
				gap: 10,
				paddingHorizontal: 10,
			},
		},
	],
	lower: [{ items: ['SeekBar'], wrapper: 'Blank' }],
};

const fullscreenLive: ControlBarLayout = {
	iconSize: FULLSCREEN_ICON_SIZE,
	top: [
		{ items: ['MetaDesc'], wrapper: 'Blank', noPadding: false, style: { paddingTop: 10, paddingLeft: 5 } },
		{
			items: ['SettingBtn'],
			wrapper: 'Group',
			align: 'right',
			noPadding: false,
			style: { paddingTop: 10, paddingRight: 5 },
		},
	],
	center: [{ items: ['BigPlayBtn'], wrapper: 'Blank', align: 'center' }],

	bottom: [
		{ items: ['TimeBtn'], wrapper: 'Group', align: 'left' },
		{ items: ['Blank'], wrapper: 'Blank' },
		{
			items: ['SubtitleBtn', 'FullscreenBtn'],
			wrapper: 'Group',
			align: 'right',
			cap: 3,
		},
	],
	lower: [{ items: ['SeekBar'], wrapper: 'Blank' }],
};

export const fullscreenLayout: ControlBarLayoutVariant = { vod: fullscreenVod, live: fullscreenLive };

// ----------------------------------------------------------------------------
// 디폴트 responsive layout
// ----------------------------------------------------------------------------

export const defaultResponsiveLayout: ControlBarLayoutResponsive = {
	pc: pcLayout,
	mobile: mobileLayout,
	fullscreen: fullscreenLayout,
	breakpoint: 768,
};
