import { useEffect, useMemo } from 'react';
import { useWindowDimensions } from 'react-native';

import type {
	ControlBarLayout,
	ControlBarLayoutInput,
	ControlBarLayoutResponsive,
	ControlBarLayoutVariant,
	UiMode,
} from './types';
import { DEFAULT_MOBILE_BREAKPOINT } from './types';
import { defaultResponsiveLayout } from './useLayout';
import { mergeLayouts } from './layoutMerge';
import { warnLayoutIssues } from './validateLayout';

// ----------------------------------------------------------------------------
// 타입 가드
// ----------------------------------------------------------------------------

function isLayoutVariant(value: unknown): value is ControlBarLayoutVariant {
	if (!value || typeof value !== 'object') return false;
	const v = value as Record<string, unknown>;
	return 'live' in v || 'vod' in v;
}

// ----------------------------------------------------------------------------
// variant에서 live/vod 선택
// ----------------------------------------------------------------------------

function pickLayout(
	value: ControlBarLayout | ControlBarLayoutVariant | undefined,
	isLive: boolean
): ControlBarLayout | undefined {
	if (!value) return undefined;
	if (isLayoutVariant(value)) {
		return isLive ? (value.live ?? value.vod) : (value.vod ?? value.live);
	}
	return value;
}

// ----------------------------------------------------------------------------
// 메인 hook
// ----------------------------------------------------------------------------

export interface UseLayoutResolverArgs {
	/** 사용자가 props로 넘긴 layout (없으면 디폴트만 사용) */
	layout?: ControlBarLayoutInput;
	isFullScreen: boolean;
	isLive: boolean;
	/** 강제 모드 (null이면 화면 크기 기반 자동) */
	uiMode?: UiMode | null;
}

export interface UseLayoutResolverResult {
	resolvedLayout: ControlBarLayout;
	isMobileLayout: boolean;
}

/**
 * 사용자 입력 layout과 디폴트를 병합하고, 화면 상태(isFullScreen, isMobile, isLive)에 따라
 * 최종 단일 layout을 결정한다.
 *
 * 우선순위:
 * 1. fullscreen이면 → resolved.fullscreen
 * 2. uiMode가 명시되면 → resolved[uiMode]
 * 3. 아니면 화면 크기로 mobile/pc 자동 판정
 */
export function useLayoutResolver({
	layout,
	isFullScreen,
	isLive,
	uiMode = null,
}: UseLayoutResolverArgs): UseLayoutResolverResult {
	const { width } = useWindowDimensions();

	// dev 모드에서 사용자 layout 정의 검증 — 알 수 없는 itemName/wrapper/align/order 등 console.warn
	useEffect(() => {
		warnLayoutIssues(layout);
	}, [layout]);

	const merged: ControlBarLayoutResponsive = useMemo(() => mergeLayouts(defaultResponsiveLayout, layout), [layout]);

	const breakpoint = merged.breakpoint ?? DEFAULT_MOBILE_BREAKPOINT;
	const isMobile = width < breakpoint;

	const result = useMemo<UseLayoutResolverResult>(() => {
		let modeKey: 'pc' | 'mobile' | 'fullscreen';
		let isMobileLayout = false;

		if (isFullScreen) {
			modeKey = 'fullscreen';
		} else if (uiMode === 'pc' || uiMode === 'mobile' || uiMode === 'fullscreen') {
			modeKey = uiMode;
			isMobileLayout = uiMode === 'mobile';
		} else if (isMobile) {
			modeKey = 'mobile';
			isMobileLayout = true;
		} else {
			modeKey = 'pc';
		}

		const candidate = merged[modeKey];
		const picked = pickLayout(candidate, isLive) ?? {};
		return { resolvedLayout: picked, isMobileLayout };
	}, [merged, isFullScreen, isLive, isMobile, uiMode]);

	return result;
}

/**
 * 임의의 layout 안에 SeekBar 아이템이 포함되어 있는지 검사한다.
 * (별도 'seekbar' 섹션을 자동 추가할지 판단할 때 사용)
 */
export function layoutHasSeekBar(layout: ControlBarLayout): boolean {
	const sectionGroups: Array<ControlBarLayout['top']> = [
		layout.top,
		layout.upper,
		layout.center,
		layout.lower,
		layout.bottom,
	];
	for (const groups of sectionGroups) {
		if (!Array.isArray(groups)) continue;
		for (const group of groups) {
			if (Array.isArray(group?.items) && group.items.includes('SeekBar')) return true;
		}
	}
	return false;
}
