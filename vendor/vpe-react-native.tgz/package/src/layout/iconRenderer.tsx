import { isValidElement } from 'react';
import type { ReactNode } from 'react';
import { Image } from 'react-native';
import type { ImageStyle, StyleProp } from 'react-native';

import type { IconValue } from './types';

export interface RenderIconOptions {
	/** 이미지(string/number)로 전달된 경우 적용할 스타일 */
	imageStyle?: StyleProp<ImageStyle>;
}

/**
 * IconOverrides의 한 항목을 React 노드로 변환한다.
 *
 * 처리 규칙:
 * - undefined/null → fallback 반환
 * - 함수 → 호출 결과
 * - 문자열 → <Image source={{uri}} />
 * - 숫자 → <Image source={number} /> (require 결과)
 * - ReactElement/ReactNode → 그대로
 */
export function renderIcon(
	override: IconValue | undefined,
	fallback: ReactNode,
	opts: RenderIconOptions = {}
): ReactNode {
	if (override === undefined || override === null) {
		return fallback;
	}

	if (typeof override === 'function') {
		const fn = override as () => ReactNode;
		const result = fn();
		return result ?? fallback;
	}

	if (typeof override === 'string') {
		return <Image source={{ uri: override }} style={opts.imageStyle} />;
	}

	if (typeof override === 'number') {
		return <Image source={override} style={opts.imageStyle} />;
	}

	if (isValidElement(override)) {
		return override;
	}

	// ReactNode (배열, fragment 등)
	return override as ReactNode;
}
