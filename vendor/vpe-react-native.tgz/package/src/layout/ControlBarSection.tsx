import React from 'react';
import { View } from 'react-native';

import type { ControlBarLayoutGroup } from './types';
import Group from '../controls/Group';
import Blank from '../controls/Blank';
import { renderControlItem } from './ControlBarItemRenderers';

/**
 * 단일 그룹을 렌더한다.
 *
 * - `wrapper === 'Blank'` → Blank 컨테이너로 감싼다 (자식 없으면 spacer)
 * - `wrapper === 'Group'` → Group 컨테이너로 감싼다 (cap 적용)
 * - 그 외 → 단순 flex row
 */
export function renderGroup(group: ControlBarLayoutGroup, sectionKey: string, groupIndex: number): React.ReactNode {
	const items = Array.isArray(group.items) && group.items.length > 0 ? group.items : ['Blank'];
	const groupKey = group.key ?? `${sectionKey}-${groupIndex}`;

	// items를 ReactNode로 변환 (Blank는 wrapper에서 처리되므로 빈 노드)
	const childNodes = items
		.map((item, idx) => {
			if (item === 'Blank') return null; // 그룹 안의 Blank는 wrapper가 처리
			return renderControlItem(item, `${groupKey}-${idx}`);
		})
		.filter((n): n is React.ReactNode => n !== null && n !== undefined);

	if (group.wrapper === 'Blank') {
		// items가 모두 Blank거나 비어있으면 단순 spacer로 동작
		return (
			<Blank key={groupKey} align={group.align} style={group.style}>
				{childNodes}
			</Blank>
		);
	}

	if (group.wrapper === 'Group') {
		return (
			<Group key={groupKey} cap={group.cap} noPadding={group.noPadding} style={group.style}>
				{childNodes}
			</Group>
		);
	}

	// wrapper 미지정: align 기반 단순 flex row
	let justify: 'flex-start' | 'flex-end' | 'center' = 'flex-start';
	if (group.align === 'right') justify = 'flex-end';
	else if (group.align === 'center') justify = 'center';

	// align이 지정되면 flex:1로 부모 가로를 채워야 justifyContent가 의미를 가짐
	// (그렇지 않으면 자식 크기만 차지해서 align이 무시됨)
	const needsFlex = group.align !== undefined;

	return (
		<View
			key={groupKey}
			style={[
				{
					flex: needsFlex ? 1 : undefined,
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: justify,
					gap: 4,
				},
				group.style,
			]}
		>
			{childNodes}
		</View>
	);
}

/**
 * 한 섹션 (top/upper/center/lower/bottom) 안의 그룹들을 렌더한다.
 *
 * 'bottom' 섹션은 특별 처리:
 * - 중간에 wrapper:'Blank'인 그룹(또는 'Blank' 단일 아이템)이 등장하면 그곳을 좌→우 분기점으로 본다
 * - 좌측 그룹들은 align='left'로, 우측 그룹들은 align='right'로 렌더
 *
 * 다른 섹션은 단순 순회 렌더.
 */
export function renderSection(groups: ControlBarLayoutGroup[] | undefined, sectionKey: string): React.ReactNode {
	if (!groups || groups.length === 0) return null;

	if (sectionKey === 'bottom') {
		// 좌/우 분할
		const leftGroups: ControlBarLayoutGroup[] = [];
		const rightGroups: ControlBarLayoutGroup[] = [];
		let separatorFound = false;

		for (const g of groups) {
			const isSeparator =
				g.wrapper === 'Blank' &&
				(!g.items || g.items.length === 0 || (g.items.length === 1 && g.items[0] === 'Blank'));

			if (isSeparator && !separatorFound) {
				separatorFound = true;
				continue;
			}

			if (separatorFound) {
				rightGroups.push(g);
			} else {
				leftGroups.push(g);
			}
		}

		return (
			<View
				style={{
					flex: 1,
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: 'space-between',
					gap: 4,
				}}
			>
				<View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
					{leftGroups.map((g, i) => renderGroup(g, sectionKey, i))}
				</View>
				{separatorFound && (
					<View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
						{rightGroups.map((g, i) => renderGroup(g, sectionKey, leftGroups.length + i))}
					</View>
				)}
			</View>
		);
	}

	// 일반 섹션 — flex:1로 부모 row 가로 전체 차지 → 안의 Blank wrapper가 spacer로 동작 가능
	return (
		<View
			style={{
				flex: 1,
				flexDirection: 'row',
				alignItems: 'center',
				gap: 4,
			}}
		>
			{groups.map((g, i) => renderGroup(g, sectionKey, i))}
		</View>
	);
}
