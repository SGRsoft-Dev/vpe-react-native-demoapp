/** 유틸 함수들 */
import Constants from 'expo-constants';

export type Segment = { start: number; end?: number; label: string };

export function clamp(n: number, min: number, max: number) {
	'worklet';
	return Math.min(Math.max(n, min), max);
}
export function pxToTime(x: number, width: number, duration: number) {
	if (duration <= 0 || width <= 0) return 0;
	return (x / width) * duration;
}
export function currentSegmentLabel(segments: Segment[], t: number) {
	const seg = segments.find((s) => t >= s.start && t < (s.end ?? Number.POSITIVE_INFINITY));
	return seg?.label;
}
export function formatTime(sec: number) {
	const s = Math.max(0, Math.floor(sec || 0));
	const h = Math.floor(s / 3600);
	const m = Math.floor((s % 3600) / 60);
	const ss = s % 60;
	return h > 0 ? `${h}:${pad(m)}:${pad(ss)}` : `${m}:${pad(ss)}`;
}
export function pad(n: number) {
	return n < 10 ? `0${n}` : `${n}`;
}

export function getProgressPercent(currentTime: number, duration: number): number {
	if (!duration || duration <= 0) return 0;
	const percent = (currentTime / duration) * 100;
	return Math.min(Math.max(percent, 0), 100); // 0~100으로 클램프
}

// --- HLS 마스터 파서 유틸 ---
export const resolveUrl = (base, relative) => {
	try {
		return new URL(relative, base).toString();
	} catch {
		return relative; // 혹시 URL 생성 실패 시 원문 유지
	}
};

// #EXT-X-STREAM-INF 라인의 속성 파싱 (BANDWIDTH, RESOLUTION 등)
export const parseAttrs = (attrLine) => {
	const attrs = {};
	attrLine.split(',').forEach((kv) => {
		const [k, v] = kv.split('=');
		if (!k) return;
		// 따옴표 제거
		const clean = (s) => s?.replace(/^"|"$/g, '');
		attrs[k.trim()] = clean(v?.trim());
	});
	return attrs;
};

// 마스터 m3u8 텍스트 → variant 배열 [{uri, bandwidth, resolution:{w,h}, codecs}]
export const parseMasterPlaylist = (text, baseUrl) => {
	const lines = text
		.split('\n')
		.map((l) => l.trim())
		.filter(Boolean);
	const variants = [];
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i];
		if (line.startsWith('#EXT-X-STREAM-INF:')) {
			const attrLine = line.replace('#EXT-X-STREAM-INF:', '').trim();
			const attrs = parseAttrs(attrLine);
			const next = lines[i + 1]; // 다음 줄이 보통 variant URI
			if (next && !next.startsWith('#')) {
				const uri = resolveUrl(baseUrl, next);
				const bandwidth = Number(attrs.BANDWIDTH) || undefined;
				let resolution;
				if (attrs.RESOLUTION && attrs.RESOLUTION.includes('x')) {
					const [w, h] = attrs.RESOLUTION.split('x').map((n) => parseInt(n, 10));
					resolution = { w, h };
				}
				variants.push({
					uri,
					bandwidth,
					resolution,
					codecs: attrs.CODECS,
				});
			}
		}
	}
	return variants;
};

export const formatBandwidth = (bps) => {
	if (!bps) return '';
	const mbps = bps / 1_000_000;
	if (mbps >= 1) return `${mbps.toFixed(1)} Mbps`;
	return `${(bps / 1_000).toFixed(0)} kbps`;
};

export const formatLabel = (v) => {
	const res = v.resolution ? `${v.resolution.h}p` : 'Unknown';
	const bw = v.bandwidth ? ` • ${formatBandwidth(v.bandwidth)}` : '';
	return `${res}${bw}`;
};

/**
 * 앱이 Expo Go 환경에서 실행 중인지 확인합니다.
 * @returns {boolean} Expo Go에서 실행 중이면 true, 그렇지 않으면 false를 반환합니다.
 */
export function isRunningInExpoGo(): boolean {
	// Constants.appOwnership가 'expo'이면 Expo Go에서 실행 중인 것입니다.
	// 개발 빌드나 독립 실행형 앱에서는 'standalone' 또는 'guest' 값을 가집니다.
	return Constants.appOwnership === 'expo';
}

// 최초 공개 남은 시간을 HH:MM:SS 형식으로 변환하는 헬퍼 함수
export const formatPremiereCountdown = (ms: number) => {
	if (ms <= 0) {
		return '00:00:00';
	}
	const totalSeconds = Math.floor(ms / 1000);
	const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
	const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
	const seconds = String(totalSeconds % 60).padStart(2, '0');
	return `${hours}:${minutes}:${seconds}`;
};

// Date 객체를 'YYYY-MM-DD HH:mm:ss' 형식으로 변환하는 헬퍼 함수
export const formatDateTime = (date: Date | null | undefined): string => {
	if (!date || !(date instanceof Date)) return '';
	// UTC 기준으로 시간을 표시하도록 UTC 메서드를 사용합니다.
	const year = date.getUTCFullYear();
	const month = String(date.getUTCMonth() + 1).padStart(2, '0');
	const day = String(date.getUTCDate()).padStart(2, '0');
	const hours = String(date.getUTCHours()).padStart(2, '0');
	const minutes = String(date.getUTCMinutes()).padStart(2, '0');

	return `${year}.${month}.${day} ${hours}:${minutes}`;
};
