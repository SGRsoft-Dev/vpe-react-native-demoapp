import React from 'react';
import { TouchableOpacity, View, StyleSheet } from 'react-native';
import { PlayIcon, PauseIcon, ArrowClockwiseIcon, CaretLineLeftIcon, CaretLineRightIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';
import NextVideoInfo from './NextVideoInfo';

export interface BigPlayBtnProps {
	size?: number;
	color?: string;
	/** prev/next 사이드 버튼 아이콘 사이즈. 기본 28. */
	sideSize?: number;
	/**
	 * 영상 종료 시 다음 영상 카드(NextVideoInfo)로 자동 전환 여부.
	 * 기본 true. 다음 영상이 있고 `validatedOptions.override?.nextSource`가 없을 때만 동작.
	 */
	autoNextInfo?: boolean;
}

// 이동 불가능할 때의 prev/next 버튼 투명도
const DISABLED_OPACITY = 0.7;

/**
 * 중앙 큰 재생 버튼 (BigPlayBtn).
 *
 * 상태별 아이콘 (가운데):
 * - `isEnded` → replay (오버라이드: `options.icon.replay`)
 * - `isPlaying` → pause (오버라이드: `options.icon.bigPlay` ?? `options.icon.pause`)
 * - 그 외 → play (오버라이드: `options.icon.bigPlay` ?? `options.icon.play`)
 *
 * 양옆:
 * - playlist가 2개 이상이면 PrevBtn / NextBtn을 양 옆에 표시
 * - 이전/다음 영상으로 이동할 수 없는 경우 opacity {@link DISABLED_OPACITY}로 옅게 표시 (클릭 무시)
 * - 아이콘 오버라이드: `options.icon.prev` / `options.icon.next`
 *
 * 영상 종료 시 (`autoNextInfo !== false` & 다음 영상이 있는 경우):
 * - 가운데를 NextVideoInfo 카드로 자동 전환 (썸네일 + 카운트다운)
 * - override.nextSource가 정의되어 있으면 자동 전환하지 않음 (사용자가 직접 처리)
 */
const BigPlayBtn: React.FC<BigPlayBtnProps> = ({ size, color = '#ffffff', sideSize, autoNextInfo = true }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const {
		isPlaying,
		isEnded,
		validatedOptions,
		togglePlay,
		prev,
		next,
		playIdx = 0,
		playlistCnt = 0,
		iconSize,
	} = ctx;
	const icon = validatedOptions?.icon;
	const overrideNextSource = !!(validatedOptions as any)?.override?.nextSource;
	const showNextInfo = autoNextInfo && isEnded && playIdx < playlistCnt - 1 && !overrideNextSource;

	// BigPlay는 디폴트 아이콘 사이즈에 +14, sideSize는 +6 → layout iconSize에 비례
	const baseIconSize = iconSize ?? 19;
	const finalSize = size ?? baseIconSize + 14;
	const finalSideSize = sideSize ?? baseIconSize + 6;

	// 가운데 BigPlay 아이콘 (재생/일시정지/리플레이)
	let centerFallback: React.ReactNode;
	let centerOverride;
	if (isEnded) {
		centerFallback = <ArrowClockwiseIcon weight="bold" color={color} size={finalSize} />;
		centerOverride = icon?.replay;
	} else if (isPlaying) {
		centerFallback = <PauseIcon weight="fill" color={color} size={finalSize} />;
		centerOverride = icon?.bigPlay ?? icon?.pause;
	} else {
		centerFallback = <PlayIcon weight="fill" color={color} size={finalSize} />;
		centerOverride = icon?.bigPlay ?? icon?.play;
	}

	// 양옆 prev/next 표시 여부 및 활성 상태.
	// NextVideoInfo 카드가 표시 중일 때는 prev/next 사이드 버튼을 숨김 (UI 충돌 방지).
	const showSideButtons = playlistCnt > 1 && !showNextInfo;
	const hasPrev = playIdx > 0;
	const hasNext = playIdx < playlistCnt - 1;

	const prevFallback = <CaretLineLeftIcon weight="fill" color={color} size={finalSideSize} />;
	const nextFallback = <CaretLineRightIcon weight="fill" color={color} size={finalSideSize} />;

	return (
		<View style={[controlStyles.bigPlayBtnTouch, styles.row]}>
			{showSideButtons && (
				<TouchableOpacity
					onPress={(e) => {
						e.stopPropagation();
						if (hasPrev) prev?.();
					}}
					// 비활성 상태에서도 hit-test는 가능하지만 onPress에서 무시 (시각적으로만 옅게)
					style={[styles.sideBtn, { opacity: hasPrev ? 1 : DISABLED_OPACITY }]}
				>
					{renderIcon(icon?.prev, prevFallback, {
						imageStyle: { width: finalSideSize, height: finalSideSize },
					})}
				</TouchableOpacity>
			)}

			{showNextInfo ? (
				<View style={styles.centerBtn}>
					<NextVideoInfo />
				</View>
			) : (
				<TouchableOpacity
					onPress={(e) => {
						e.stopPropagation();
						togglePlay?.();
					}}
					style={styles.centerBtn}
				>
					<View style={controlStyles.iconWrap}>
						{renderIcon(centerOverride, centerFallback, {
							imageStyle: { width: finalSize, height: finalSize },
						})}
					</View>
				</TouchableOpacity>
			)}

			{showSideButtons && (
				<TouchableOpacity
					onPress={(e) => {
						e.stopPropagation();
						if (hasNext) next?.();
					}}
					style={[styles.sideBtn, { opacity: hasNext ? 1 : DISABLED_OPACITY }]}
				>
					{renderIcon(icon?.next, nextFallback, {
						imageStyle: { width: finalSideSize, height: finalSideSize },
					})}
				</TouchableOpacity>
			)}
		</View>
	);
};

const styles = StyleSheet.create({
	row: {
		flexDirection: 'row',
		alignItems: 'center',
		gap: 16,
	},
	sideBtn: {
		padding: 8,
		justifyContent: 'center',
		alignItems: 'center',
	},
	centerBtn: {
		padding: 4,
		justifyContent: 'center',
		alignItems: 'center',
	},
});

export default BigPlayBtn;
