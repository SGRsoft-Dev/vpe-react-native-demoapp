import { StyleSheet } from 'react-native';

/**
 * 컨트롤 컴포넌트들이 공통으로 사용하는 스타일.
 * 기존 PlayerControls.tsx의 styles에서 추출.
 */
export const controlStyles = StyleSheet.create({
	roundedBtn: {
		borderRadius: 100,
		backgroundColor: 'rgba(0,0,0,0.4)',
		padding: 10,
	},
	playBtnTouch: {
		padding: 6,
	},
	bigPlayBtnTouch: {
		padding: 6,
		margin: 'auto',
	},
	// 컴팩트한 아이콘 버튼 — Group의 알약/원형 배경과 함께 사용될 때 여백이 최소화되도록
	// 강제 width/aspectRatio 제거. 아이콘 자체 크기만큼만 공간 차지.
	roundedBtnOpa: {
		borderRadius: 100,
		padding: 2,
		justifyContent: 'center',
		alignItems: 'center',
	},
	iconWrap: {
		justifyContent: 'center',
		alignItems: 'center',
	},
	textWhite: {
		color: '#ffffff',
		fontSize: 12,
	},
	timeContainer: {
		flexDirection: 'row',
		gap: 4,
		alignItems: 'center',
		height: 30,
		paddingHorizontal: 10,
	},
	liveContainer: {
		flexDirection: 'row',
		gap: 4,
		alignItems: 'center',
	},
	liveDot: {
		width: 8,
		height: 8,
		borderRadius: 4,
	},
});
