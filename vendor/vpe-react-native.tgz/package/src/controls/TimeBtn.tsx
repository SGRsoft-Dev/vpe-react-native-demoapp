import React from 'react';
import { View, Text } from 'react-native';

import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';
import { formatTime } from '../util';

export interface TimeBtnProps {
	color?: string;
}

/**
 * 현재시간/총시간 표시 ("00:34 / 03:21").
 * 라이브 모드에서는 LIVE 인디케이터를 표시한다.
 *
 * `validatedOptions.controlBtn.times === false` 면 렌더하지 않음.
 */
const TimeBtn: React.FC<TimeBtnProps> = ({ color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { currentTime = 0, duration = 0, isLive, isDvr, startPlay, validatedOptions } = ctx;
	if (validatedOptions?.controlBtn?.times === false) return null;

	// PlayerControls와 동일한 조건: 라이브 영상 + 라이브 진입 대기 상태도 LIVE 인디케이터로 표시
	if (isLive || startPlay) {
		return (
			<View style={controlStyles.liveContainer}>
				<View
					style={[
						controlStyles.liveDot,
						{
							backgroundColor: isDvr ? '#cdcdcd' : '#ff0000',
						},
					]}
				/>
				<Text style={[controlStyles.textWhite, { color }]}>LIVE</Text>
			</View>
		);
	}

	return (
		<View style={controlStyles.timeContainer}>
			<Text style={[controlStyles.textWhite, { color }]}>{formatTime(currentTime)}</Text>
			<Text style={[controlStyles.textWhite, { color }]}>/</Text>
			<Text style={[controlStyles.textWhite, { color }]}>{formatTime(duration)}</Text>
		</View>
	);
};

export default TimeBtn;
