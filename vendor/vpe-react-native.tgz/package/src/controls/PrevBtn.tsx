import React from 'react';
import { TouchableOpacity } from 'react-native';
import { CaretLineLeftIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface PrevBtnProps {
	size?: number;
	color?: string;
}

/**
 * 이전 트랙 버튼. playlist가 2개 이상일 때만 표시.
 *
 * 아이콘 오버라이드: `options.icon.prev`
 */
const PrevBtn: React.FC<PrevBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { playIdx = 0, playlistCnt = 0, validatedOptions, prev, iconSize } = ctx;
	if (playlistCnt < 2) return null;

	const finalSize = size ?? iconSize ?? 23;
	const hasPrev = playIdx > 0;
	const fallback = <CaretLineLeftIcon weight="fill" color={color} size={finalSize} />;
	const overrideValue = validatedOptions?.icon?.prev;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				if (hasPrev) prev?.();
			}}
			style={[controlStyles.roundedBtnOpa, { opacity: hasPrev ? 1 : 0.2 }]}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default PrevBtn;
