import React from 'react';
import { TouchableOpacity } from 'react-native';
import { CaretLeftIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import type { IconValue } from '../layout/types';
import { controlStyles } from './styles';

export interface BackBtnProps {
	/**
	 * 직접 콜백을 지정하면 events.backPress보다 우선한다.
	 * (레이아웃 시스템 외부에서 직접 사용할 때를 위함)
	 */
	onPress?: () => void;
	/** 아이콘 오버라이드. 없으면 options.icon.back → 디폴트 CaretLeftIcon 순으로 fallback. */
	icon?: IconValue;
	size?: number;
	color?: string;
}

/**
 * 기본 백버튼 컴포넌트.
 *
 * 동작:
 * 1. props.onPress가 있으면 그것을 호출
 * 2. 그렇지 않으면 PlayerContext.events.backPress 호출
 * 3. 둘 다 없으면 noop (네비게이션은 사용자가 events.backPress로 처리)
 *
 * 아이콘 우선순위: props.icon → validatedOptions.icon.back → CaretLeftIcon (디폴트)
 */
const BackBtn: React.FC<BackBtnProps> = ({ onPress, icon, size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	const finalSize = size ?? ctx?.iconSize ?? 19;

	const handlePress = () => {
		if (onPress) {
			onPress();
			return;
		}
		ctx?.events?.backPress?.();
	};

	const overrideValue = icon ?? ctx?.validatedOptions?.icon?.back;

	const fallback = <CaretLeftIcon size={finalSize} color={color} />;

	return (
		<TouchableOpacity onPress={handlePress} style={controlStyles.roundedBtnOpa}>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default BackBtn;
