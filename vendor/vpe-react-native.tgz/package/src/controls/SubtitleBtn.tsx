import React from 'react';
import { TouchableOpacity } from 'react-native';
import { ClosedCaptioningIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface SubtitleBtnProps {
	size?: number;
	color?: string;
}

/**
 * 자막 on/off 토글 버튼.
 *
 * 표시 조건:
 * - `validatedOptions.controlBtn.subtitle !== false`
 * - `hasSubtitle === true` (사용 가능한 자막이 1개 이상)
 *
 * 클릭 동작:
 * - 자막 켜짐 → 끔
 * - 자막 꺼짐 → default(없으면 첫 번째) 자막을 켬
 *
 * 아이콘 오버라이드:
 * - 자막 켜짐: `options.icon.subtitle`
 * - 자막 꺼짐: `options.icon.subtitleOff`
 */
const SubtitleBtn: React.FC<SubtitleBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { validatedOptions, hasSubtitle, selectedSubtitle, toggleSubtitle, iconSize } = ctx;
	if (validatedOptions?.controlBtn?.subtitle === false) return null;
	if (!hasSubtitle) return null;

	const finalSize = size ?? iconSize ?? 19;
	const isOn = !!selectedSubtitle;
	const icon = validatedOptions?.icon;
	const fallback = <ClosedCaptioningIcon weight={isOn ? 'fill' : 'light'} color={color} size={finalSize} />;
	const overrideValue = isOn ? icon?.subtitle : icon?.subtitleOff;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				toggleSubtitle?.();
			}}
			style={controlStyles.roundedBtnOpa}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default SubtitleBtn;
