import React from 'react';
import { TouchableOpacity } from 'react-native';
import { GearSixIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface SettingBtnProps {
	size?: number;
	color?: string;
}

/**
 * 설정 메뉴 토글 버튼.
 * `validatedOptions.controlBtn.setting === false` 면 렌더하지 않음.
 *
 * 아이콘 오버라이드: `options.icon.setting`
 */
const SettingBtn: React.FC<SettingBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { validatedOptions, toggleSettings, iconSize } = ctx;
	if (validatedOptions?.controlBtn?.setting === false) return null;

	const finalSize = size ?? iconSize ?? 19;
	const fallback = <GearSixIcon weight="fill" color={color} size={finalSize} />;
	const overrideValue = validatedOptions?.icon?.setting;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				toggleSettings?.();
			}}
			style={controlStyles.roundedBtnOpa}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default SettingBtn;
