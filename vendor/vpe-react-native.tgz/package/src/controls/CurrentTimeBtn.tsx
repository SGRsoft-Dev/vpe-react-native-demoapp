import React from 'react';
import { Text } from 'react-native';

import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';
import { formatTime } from '../util';

export interface CurrentTimeBtnProps {
	color?: string;
}

/**
 * 현재 재생 시간만 표시.
 */
const CurrentTimeBtn: React.FC<CurrentTimeBtnProps> = ({ color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { currentTime = 0, validatedOptions } = ctx;
	if (validatedOptions?.controlBtn?.times === false) return null;

	return <Text style={[controlStyles.textWhite, { color }]}>{formatTime(currentTime)}</Text>;
};

export default CurrentTimeBtn;
