import React from 'react';
import { TouchableOpacity, Share, StyleSheet } from 'react-native';
import { ShareNetworkIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import type { IconValue } from '../layout/types';

export interface ShareBtnProps {
	onPress?: () => void;
	icon?: IconValue;
	size?: number;
	color?: string;
}

/**
 * 공유 버튼.
 *
 * 동작:
 * 1. props.onPress가 있으면 그것을 호출
 * 2. 그렇지 않으면 React Native의 Share.share() 를 직접 호출
 *    (현재 재생 중인 playlist item의 file URL 사용)
 */
const ShareBtn: React.FC<ShareBtnProps> = ({ onPress, icon, size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	const finalSize = size ?? ctx?.iconSize ?? 19;

	const handlePress = async () => {
		if (onPress) {
			onPress();
			return;
		}

		const playlist = ctx?.validatedOptions?.playlist;
		const idx = ctx?.playIdx ?? 0;
		const current = playlist?.[idx];
		const url = current?.file;
		if (!url) return;

		try {
			await Share.share({ message: url, url });
		} catch {
			// no-op
		}
	};

	const overrideValue = icon ?? ctx?.validatedOptions?.icon?.share;
	const fallback = <ShareNetworkIcon size={finalSize} color={color} />;

	return (
		<TouchableOpacity onPress={handlePress} style={styles.touchTarget}>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	touchTarget: {
		padding: 8,
		justifyContent: 'center',
		alignItems: 'center',
	},
});

export default ShareBtn;
