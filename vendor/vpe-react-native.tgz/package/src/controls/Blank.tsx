import React from 'react';
import { View } from 'react-native';
import type { StyleProp, ViewStyle } from 'react-native';

export interface BlankProps {
	children?: React.ReactNode;
	/**
	 * 정렬 방향 (자식이 있을 때).
	 */
	align?: 'left' | 'right' | 'center';
	style?: StyleProp<ViewStyle>;
}

/**
 * 빈 공간 / spacer / align wrapper.
 * 레이아웃 시스템의 `wrapper: 'Blank'` 처리를 담당.
 *
 * 자식이 없으면 단순 spacer (`flex: 1`).
 * 자식이 있으면 align에 따라 정렬한 컨테이너.
 */
const Blank: React.FC<BlankProps> = ({ children, align, style }) => {
	const items = React.Children.toArray(children);

	if (items.length === 0) {
		// spacer로 동작
		return <View style={[{ flex: 1 }, style]} />;
	}

	let justify: 'flex-start' | 'flex-end' | 'center' = 'flex-start';
	if (align === 'right') justify = 'flex-end';
	else if (align === 'center') justify = 'center';

	return (
		<View
			style={[
				{
					flex: 1,
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: justify,
					gap: 4,
				},
				style,
			]}
		>
			{items}
		</View>
	);
};

export default Blank;
