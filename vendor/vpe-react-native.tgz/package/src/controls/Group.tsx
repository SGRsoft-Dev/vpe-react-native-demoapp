import React from 'react';
import { View } from 'react-native';
import type { StyleProp, ViewStyle } from 'react-native';

import TimeBtn from './TimeBtn';

export interface GroupProps {
	/** 자식들 (이미 렌더된 컨트롤 노드 배열). */
	children?: React.ReactNode;
	/**
	 * 표시할 자식 최대 개수. 초과분은 잘라낸다.
	 * (웹 SDK는 ... 메뉴로 합치지만 RN은 일단 단순 슬라이스)
	 */
	cap?: number;
	/**
	 * 알약/원형 배경 + 패딩을 끔. 기본 false (디폴트로 알약 스타일 적용).
	 * 사용자가 layout group에서 `noPadding: true`를 지정하면 배경/패딩 없이 단순 row만 표시된다.
	 */
	noPadding?: boolean;
	style?: StyleProp<ViewStyle>;
}

/**
 * 컨트롤 묶음 컨테이너 (flex row).
 * 레이아웃 시스템의 `wrapper: 'Group'` 처리를 담당.
 *
 * 디폴트 스타일:
 * - **알약 모양** — `borderRadius: 999` + 회색 0.4 배경 + 좌우 패딩
 * - 자식이 1개일 경우 **완전한 원형** — `aspectRatio: 1`로 정사각형 강제
 *
 * `noPadding` prop으로 알약/원형 스타일을 끌 수 있다.
 */
const Group: React.FC<GroupProps> = ({ children, cap, noPadding = false, style }) => {
	const items = React.Children.toArray(children);
	const sliced = typeof cap === 'number' && cap > 0 ? items.slice(0, cap) : items;
	const isSingle = sliced.length === 1;
	// 단일 자식이 TimeBtn인 경우 — 텍스트 기반이라 정사각형 처리하면 잘리거나 어색해짐.
	// aspectRatio:1을 우회해 가로 길이가 자연스럽게 늘어나도록 알약 모양으로 표시.
	const singleIsTimeBtn = isSingle && React.isValidElement(sliced[0]) && sliced[0].type === TimeBtn;
	const useCircle = isSingle && !singleIsTimeBtn;

	if (noPadding) {
		// 배경/패딩 없이 단순 row만
		return (
			<View
				style={[
					{
						flexDirection: 'row',
						alignItems: 'center',
						gap: 4,
					},
					style,
				]}
			>
				{sliced}
			</View>
		);
	}

	return (
		<View
			style={[
				{
					flexDirection: 'row',
					alignItems: 'center',
					justifyContent: 'center',
					gap: 4,
					borderRadius: 999,
					backgroundColor: 'rgba(128, 128, 128, 0.4)',
					paddingHorizontal: useCircle ? 2 : 4,
					paddingVertical: 2,
					// 자식이 1개면 정사각형 → borderRadius 999와 결합해 완전한 원
					// (TimeBtn 단일은 텍스트가 가로로 길어야 하므로 우회)
					aspectRatio: useCircle ? 1 : undefined,
				},
				style,
			]}
		>
			{sliced}
		</View>
	);
};

export default Group;
