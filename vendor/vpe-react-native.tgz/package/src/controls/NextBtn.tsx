import React from 'react';
import { TouchableOpacity } from 'react-native';
import { CaretLineRightIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface NextBtnProps {
	size?: number;
	color?: string;
}

/**
 * 다음 트랙 버튼. playlist가 2개 이상일 때만 표시.
 *
 * 아이콘 오버라이드: `options.icon.next`
 */
const NextBtn: React.FC<NextBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { playIdx = 0, playlistCnt = 0, validatedOptions, next, iconSize } = ctx;
	if (playlistCnt < 2) return null;

	const finalSize = size ?? iconSize ?? 23;
	const hasNext = playIdx < playlistCnt - 1;
	const fallback = <CaretLineRightIcon weight="fill" color={color} size={finalSize} />;
	const overrideValue = validatedOptions?.icon?.next;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				if (hasNext) next?.();
			}}
			style={[controlStyles.roundedBtnOpa, { opacity: hasNext ? 1 : 0.2 }]}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default NextBtn;
