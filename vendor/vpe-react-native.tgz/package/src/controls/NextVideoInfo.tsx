import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

import t from '../locales/i18n';
import { usePlayerContextOptional } from '../PlayerContext';

export interface NextVideoInfoProps {
	/** 카운트다운 시작 값(초). 기본 5초. */
	countdownStart?: number;
}

/**
 * 영상 종료 후 다음 영상 카운트다운 / 썸네일 카드.
 *
 * 표시 조건:
 * - `isEnded === true`
 * - playlist의 다음 영상이 존재
 * - `validatedOptions.override?.nextSource` 가 정의되지 않은 경우 (override가 있으면 자동 재생을 사용자가 처리)
 *
 * 동작:
 * - 5초 카운트다운 후 자동으로 next() 호출
 * - 카드를 탭하면 즉시 next() 호출 (카운트다운 무시)
 */
const NextVideoInfo: React.FC<NextVideoInfoProps> = ({ countdownStart = 5 }) => {
	const ctx = usePlayerContextOptional();
	const [countdown, setCountdown] = useState(countdownStart);

	const isEnded = ctx?.isEnded ?? false;
	const isFullScreen = ctx?.isFullScreen ?? false;
	const playlist = ctx?.validatedOptions?.playlist;
	const playIdx = ctx?.playIdx ?? 0;
	const override = (ctx?.validatedOptions as any)?.override;
	const next = ctx?.next;

	const nextItem: any = playlist?.[playIdx + 1];
	const hasNext = !!nextItem?.file;
	const overrideNextSource = !!override?.nextSource;

	// 종료 상태로 진입할 때마다 카운트다운 리셋
	useEffect(() => {
		if (isEnded) {
			setCountdown(countdownStart);
		}
	}, [isEnded, countdownStart]);

	// 카운트다운 타이머 (활성 조건일 때만)
	useEffect(() => {
		if (!isEnded || !hasNext || overrideNextSource) return;

		if (countdown <= 0) {
			next?.();
			return;
		}

		const timer = setTimeout(() => {
			setCountdown((prev) => prev - 1);
		}, 1000);
		return () => clearTimeout(timer);
	}, [countdown, isEnded, hasNext, overrideNextSource, next]);

	// 표시 조건: 종료 + 다음 영상 존재 + override 없음
	if (!isEnded || !hasNext || overrideNextSource) return null;

	const cardWidth = isFullScreen ? 220 : 120;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				next?.();
			}}
			activeOpacity={0.85}
		>
			<View style={styles.container}>
				{nextItem.poster ? (
					<Image source={{ uri: nextItem.poster }} style={[styles.poster, { width: cardWidth }]} />
				) : (
					<View style={[styles.posterPlaceholder, { width: cardWidth }]} />
				)}
				{nextItem?.description?.title && (
					<Text style={[styles.title, { maxWidth: cardWidth }]} numberOfLines={2} ellipsizeMode="tail">
						{nextItem.description.title}
					</Text>
				)}
				<Text style={styles.countdown}>{t.alternative.nextPlay.replace('{timeTxt}', String(countdown))}</Text>
			</View>
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	container: {
		alignItems: 'center',
		gap: 8,
	},
	poster: {
		aspectRatio: 16 / 9,
		objectFit: 'contain',
		borderRadius: 5,
	},
	posterPlaceholder: {
		aspectRatio: 16 / 9,
		borderRadius: 5,
		backgroundColor: '#232323',
	},
	title: {
		color: 'white',
		fontSize: 11,
		fontWeight: 'bold',
	},
	countdown: {
		color: 'white',
		fontSize: 9,
		fontWeight: 'bold',
		opacity: 0.7,
	},
});

export default NextVideoInfo;
