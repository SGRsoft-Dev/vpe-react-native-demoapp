import React from 'react';
import { TouchableOpacity } from 'react-native';
import { CornersInIcon, CornersOutIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface FullscreenBtnProps {
	size?: number;
	color?: string;
}

/**
 * 전체화면 토글 버튼.
 * `validatedOptions.controlBtn.fullscreen === false` 면 렌더하지 않음.
 *
 * 아이콘 오버라이드: `options.icon.fullscreen` / `options.icon.fullscreenExit`
 */
const FullscreenBtn: React.FC<FullscreenBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { isFullScreen, validatedOptions, toggleFullScreen, iconSize } = ctx;
	if (validatedOptions?.controlBtn?.fullscreen === false) return null;

	const finalSize = size ?? iconSize ?? 19;
	const icon = validatedOptions?.icon;
	const fallback = isFullScreen ? (
		<CornersInIcon color={color} size={finalSize} />
	) : (
		<CornersOutIcon color={color} size={finalSize} />
	);
	const overrideValue = isFullScreen ? icon?.fullscreenExit : icon?.fullscreen;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				toggleFullScreen?.();
			}}
			style={controlStyles.roundedBtnOpa}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default FullscreenBtn;
