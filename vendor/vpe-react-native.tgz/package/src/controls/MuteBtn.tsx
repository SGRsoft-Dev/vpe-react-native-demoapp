import React from 'react';
import { TouchableOpacity } from 'react-native';
import { SpeakerSlashIcon, SpeakerHighIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface MuteBtnProps {
	size?: number;
	color?: string;
}

/**
 * 단순 뮤트 토글 버튼 (mobile top 영역에서 사용).
 * VolumeBtn과 동일하지만 컨트롤바 옵션 체크 없이 항상 렌더.
 */
const MuteBtn: React.FC<MuteBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { isMuted, validatedOptions, toggleMute, iconSize } = ctx;
	const finalSize = size ?? iconSize ?? 19;
	const icon = validatedOptions?.icon;

	const fallback = isMuted ? (
		<SpeakerSlashIcon weight="fill" color={color} size={finalSize} />
	) : (
		<SpeakerHighIcon weight="fill" color={color} size={finalSize} />
	);
	const overrideValue = isMuted ? icon?.volumeMute : icon?.volumeFull;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				toggleMute?.();
			}}
			style={controlStyles.roundedBtnOpa}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default MuteBtn;
