import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { Slider } from '@miblanchard/react-native-slider';

import { usePlayerContextOptional } from '../PlayerContext';

export interface SeekBarProps {
	/**
	 * 슬라이더 컨테이너 높이. 기본 15.
	 */
	height?: number;
	/**
	 * 상하 마진 제거. ControlBar의 bottom 'seekbar' 슬롯에서 풀폭 표시할 때 사용.
	 */
	noMargin?: boolean;
}

/**
 * 진행도/탐색 슬라이더.
 *
 * 표시 조건: `validatedOptions.controlBtn.progressBar !== false`
 *
 * 동작:
 * - 사용자 드래그 중에는 외부 currentTime 동기화를 멈추고 로컬 sliderValue 사용
 * - onSlidingComplete 시 seek
 * - 라이브: liveSliderMax/sliderMax는 PR2c에서 context로 노출 예정. 일단 duration 사용.
 */
const SeekBar: React.FC<SeekBarProps> = ({ height = 15, noMargin = false }) => {
	const ctx = usePlayerContextOptional();
	const [isSeeking, setIsSeeking] = useState(false);
	const [sliderValue, setSliderValue] = useState(0);

	const currentTime = ctx?.currentTime ?? 0;
	const duration = ctx?.duration ?? 0;

	useEffect(() => {
		if (!isSeeking) {
			setSliderValue(currentTime);
		}
	}, [currentTime, isSeeking]);

	if (!ctx) return null;
	const { validatedOptions, isFullScreen, isActive, seek } = ctx;
	if (validatedOptions?.controlBtn?.progressBar === false) return null;

	const trackColor = (validatedOptions as any)?.progressBarColor || '#4299f5';

	// View로 감싸 flex:1 + 가로 폭을 명시 → Slider가 가로 전체로 늘어남
	const marginBottomValue = noMargin ? 0 : isFullScreen ? 10 : -5;
	return (
		<View style={{ flex: 1, width: '100%' }}>
			<Slider
				containerStyle={{
					height,
					width: '100%',
					justifyContent: 'center',
					marginBottom: marginBottomValue,
				}}
				thumbStyle={{
					width: 16,
					height: 16,
					display: isActive ? 'flex' : 'none',
				}}
				trackStyle={{
					borderRadius: 0,
					height: 5,
				}}
				minimumValue={0}
				maximumValue={duration}
				value={sliderValue}
				maximumTrackTintColor="rgba(238,238,238,0.31)"
				minimumTrackTintColor={isActive ? trackColor : 'rgba(238,238,238,0.61)'}
				thumbTintColor={isActive ? trackColor : 'rgba(238,238,238,0.61)'}
				thumbTouchSize={{ width: 40, height: 40 }}
				onSlidingStart={() => setIsSeeking(true)}
				onValueChange={(value: number[] | number) => {
					const v = Array.isArray(value) ? value[0] : value;
					setSliderValue(v ?? 0);
				}}
				onSlidingComplete={(value: number[] | number) => {
					setIsSeeking(false);
					const v = Array.isArray(value) ? value[0] : value;
					if (v !== undefined) seek?.(v);
				}}
			/>
		</View>
	);
};

export default SeekBar;
