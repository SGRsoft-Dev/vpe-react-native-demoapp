import React from 'react';
import { TouchableOpacity, View, Text, StyleSheet } from 'react-native';
import { ArrowCounterClockwiseIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import type { IconValue } from '../layout/types';

export interface SkipBackBtnProps {
	onPress?: () => void;
	icon?: IconValue;
	/** 스킵 단위(초). 기본 10. */
	seconds?: number;
	size?: number;
	color?: string;
}

/**
 * 뒤로 N초 스킵 버튼 (기본 10초).
 *
 * 동작 우선순위:
 * 1. props.onPress
 * 2. PlayerContext.skipBack(seconds)
 */
const SkipBackBtn: React.FC<SkipBackBtnProps> = ({ onPress, icon, seconds = 10, size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	const finalSize = size ?? ctx?.iconSize ?? 19;

	const handlePress = () => {
		if (onPress) {
			onPress();
			return;
		}
		ctx?.skipBack?.(seconds);
	};

	const overrideValue = icon ?? ctx?.validatedOptions?.icon?.skipBack;
	const fallback = (
		<View style={styles.iconWrap}>
			<ArrowCounterClockwiseIcon size={finalSize} color={color} />
			<Text style={[styles.label, { color }]}>{seconds}</Text>
		</View>
	);

	return (
		<TouchableOpacity onPress={handlePress} style={styles.touchTarget}>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

const styles = StyleSheet.create({
	touchTarget: {
		padding: 8,
		justifyContent: 'center',
		alignItems: 'center',
	},
	iconWrap: {
		justifyContent: 'center',
		alignItems: 'center',
	},
	label: {
		position: 'absolute',
		fontSize: 9,
		fontWeight: '700',
		marginTop: 2,
	},
});

export default SkipBackBtn;
