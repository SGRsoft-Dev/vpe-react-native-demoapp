import React from 'react';
import { TouchableOpacity, View } from 'react-native';
import { PlayIcon, PauseIcon, ArrowClockwiseIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface PlayBtnProps {
	size?: number;
	color?: string;
}

/**
 * 재생/일시정지 토글 버튼.
 *
 * - `validatedOptions.controlBtn.play === false` 면 렌더하지 않음
 * - 상태별 아이콘:
 *   - `isEnded` → replay 아이콘 (ArrowClockwiseIcon, 오버라이드 키: `options.icon.replay`)
 *   - `isPlaying` → pause 아이콘 (오버라이드 키: `options.icon.pause`)
 *   - 그 외 → play 아이콘 (오버라이드 키: `options.icon.play`)
 *
 * ended 상태에서 누르면 togglePlay() 호출 → VpePlayer가 자동으로 0초로 seek 후 재생.
 */
const PlayBtn: React.FC<PlayBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { isPlaying, isEnded, validatedOptions, togglePlay, iconSize } = ctx;
	if (validatedOptions?.controlBtn?.play === false) return null;

	const finalSize = size ?? iconSize ?? 25;
	const icon = validatedOptions?.icon;

	let fallback: React.ReactNode;
	let overrideValue;
	if (isEnded) {
		fallback = <ArrowClockwiseIcon weight="bold" color={color} size={finalSize} />;
		overrideValue = icon?.replay;
	} else if (isPlaying) {
		fallback = <PauseIcon weight="fill" color={color} size={finalSize} />;
		overrideValue = icon?.pause;
	} else {
		fallback = <PlayIcon weight="fill" color={color} size={finalSize} />;
		overrideValue = icon?.play;
	}

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				togglePlay?.();
			}}
			style={controlStyles.playBtnTouch}
		>
			<View style={controlStyles.iconWrap}>
				{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
			</View>
		</TouchableOpacity>
	);
};

export default PlayBtn;
