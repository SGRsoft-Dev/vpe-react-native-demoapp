import React from 'react';
import { View } from 'react-native';

import { usePlayerContextOptional } from '../PlayerContext';
import PrevBtn from './PrevBtn';
import NextBtn from './NextBtn';

export interface NextPrevBtnProps {
	size?: number;
	color?: string;
}

/**
 * Prev + Next 묶음 버튼. playlist가 2개 이상일 때만 표시.
 */
const NextPrevBtn: React.FC<NextPrevBtnProps> = ({ size, color }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { playlistCnt = 0 } = ctx;
	if (playlistCnt < 2) return null;

	return (
		<View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
			<PrevBtn size={size} color={color} />
			<NextBtn size={size} color={color} />
		</View>
	);
};

export default NextPrevBtn;
