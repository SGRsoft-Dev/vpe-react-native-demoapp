import React from 'react';
import { View, Image, Text, StyleSheet } from 'react-native';

import { usePlayerContextOptional } from '../PlayerContext';

export interface MetaDescProps {
	color?: string;
}

/**
 * 영상 메타데이터 (제목, 프로필 이미지, 채널명, 등록일).
 *
 * 데이터 소스: `validatedOptions.playlist[playIdx].description`
 * `validatedOptions.descriptionNotVisible === true` 면 렌더하지 않음.
 */
const MetaDesc: React.FC<MetaDescProps> = ({ color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { validatedOptions, playIdx = 0 } = ctx;
	if ((validatedOptions as any)?.descriptionNotVisible) return null;

	const current = validatedOptions?.playlist?.[playIdx] as any;
	const description = current?.description;
	if (!description) return <View style={{ flex: 1 }} />;

	const { profile_image, title, profile_name, created_at } = description;
	if (!profile_image && !title && !profile_name && !created_at) {
		return <View style={{ flex: 1 }} />;
	}

	return (
		<View style={styles.container}>
			{profile_image && <Image source={{ uri: profile_image }} style={styles.profileImage} />}
			<View style={styles.textContainer}>
				{title && (
					<Text style={[styles.title, { color }]} numberOfLines={1}>
						{title}
					</Text>
				)}
				<View style={styles.metaRow}>
					{profile_name && (
						<Text style={[styles.meta, { color }]} numberOfLines={1}>
							{profile_name}
						</Text>
					)}
					{created_at && (
						<Text style={[styles.meta, { color }]} numberOfLines={1}>
							{created_at}
						</Text>
					)}
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		flexDirection: 'row',
		alignItems: 'center',
		gap: 8,
	},
	profileImage: {
		width: 28,
		height: 28,
		borderRadius: 100,
	},
	textContainer: {
		flex: 1,
	},
	title: {
		fontSize: 13,
		fontWeight: '600',
	},
	metaRow: {
		flexDirection: 'row',
		gap: 6,
	},
	meta: {
		fontSize: 11,
		opacity: 0.8,
	},
});

export default MetaDesc;
