import React from 'react';
import { TouchableOpacity } from 'react-native';
import { SpeakerHighIcon, SpeakerSimpleXIcon } from 'phosphor-react-native';

import { renderIcon } from '../layout/iconRenderer';
import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';

export interface VolumeBtnProps {
	size?: number;
	color?: string;
}

/**
 * 볼륨/뮤트 토글 버튼.
 * `validatedOptions.controlBtn.volume === false` 면 렌더하지 않음.
 *
 * 아이콘 오버라이드: `options.icon.volumeFull` / `options.icon.volumeMute`
 */
const VolumeBtn: React.FC<VolumeBtnProps> = ({ size, color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { isMuted, validatedOptions, toggleMute, iconSize } = ctx;
	if (validatedOptions?.controlBtn?.volume === false) return null;

	const finalSize = size ?? iconSize ?? 19;
	const icon = validatedOptions?.icon;
	const fallback = isMuted ? (
		<SpeakerSimpleXIcon weight="fill" color={color} size={finalSize} />
	) : (
		<SpeakerHighIcon weight="fill" color={color} size={finalSize} />
	);
	const overrideValue = isMuted ? icon?.volumeMute : icon?.volumeFull;

	return (
		<TouchableOpacity
			onPress={(e) => {
				e.stopPropagation();
				toggleMute?.();
			}}
			style={[controlStyles.roundedBtnOpa]}
		>
			{renderIcon(overrideValue, fallback, { imageStyle: { width: finalSize, height: finalSize } })}
		</TouchableOpacity>
	);
};

export default VolumeBtn;
