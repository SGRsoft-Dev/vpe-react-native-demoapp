import React from 'react';
import { View, Text, Animated, StyleSheet } from 'react-native';
import { CaretDoubleLeftIcon, CaretDoubleRightIcon } from 'phosphor-react-native';

import t from '../locales/i18n';
import type { SeekInfo } from '../hooks/useTapGestures';

export interface SeekIndicatorProps {
	seekInfo: SeekInfo | null;
	seekAnimation: Animated.Value;
	isFullScreen?: boolean;
}

/**
 * 더블탭 seek 시 화면에 표시되는 시각 피드백.
 *
 * - 좌우 화살표 + 누적 초 텍스트
 * - 방사형 파동 애니메이션 (Animated.View, opacity + scale)
 * - rewind/forward에 따라 좌/우 위치 변경
 *
 * `seekInfo`가 null이면 렌더하지 않음.
 */
const SeekIndicator: React.FC<SeekIndicatorProps> = ({ seekInfo, seekAnimation, isFullScreen = false }) => {
	if (!seekInfo) return null;

	const indicatorSize = isFullScreen ? 600 : 300;
	const isRewind = seekInfo.direction === 'rewind';

	const opacity = seekAnimation.interpolate({
		inputRange: [0, 1],
		outputRange: [0.6, 0],
	});

	const scale = seekAnimation.interpolate({
		inputRange: [0, 1.5],
		outputRange: [0.8, 1.6],
	});

	return (
		<View style={styles.container} pointerEvents="none">
			<View style={[styles.indicator, isRewind ? styles.indicatorLeft : styles.indicatorRight]}>
				<Animated.View
					style={[
						styles.background,
						{
							width: indicatorSize,
							height: indicatorSize,
							borderRadius: indicatorSize,
							opacity,
							transform: [{ scale }],
						},
					]}
				/>
				<View style={styles.content}>
					{isRewind ? (
						<CaretDoubleLeftIcon weight="fill" color="white" size={22} />
					) : (
						<CaretDoubleRightIcon weight="fill" color="white" size={22} />
					)}
					<Text style={styles.text}>
						{seekInfo.amount}
						{t.alternative.second}
					</Text>
				</View>
			</View>
		</View>
	);
};

const styles = StyleSheet.create({
	container: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 120,
		overflow: 'hidden',
	},
	indicator: {
		position: 'absolute',
		top: 0,
		bottom: 0,
		width: '40%',
		alignItems: 'center',
		justifyContent: 'center',
	},
	indicatorLeft: {
		left: -50,
		paddingLeft: 60,
	},
	indicatorRight: {
		right: -50,
		paddingRight: 60,
	},
	background: {
		position: 'absolute',
		backgroundColor: 'rgba(255, 255, 255, 0.4)',
	},
	content: {
		justifyContent: 'center',
		alignItems: 'center',
		gap: 8,
		paddingTop: 10,
	},
	text: {
		color: 'white',
		fontSize: 10,
		fontWeight: 'bold',
	},
});

export default SeekIndicator;
