import React from 'react';
import { Text } from 'react-native';

import { usePlayerContextOptional } from '../PlayerContext';
import { controlStyles } from './styles';
import { formatTime } from '../util';

export interface DurationBtnProps {
	color?: string;
}

/**
 * 총 재생 길이만 표시.
 */
const DurationBtn: React.FC<DurationBtnProps> = ({ color = '#ffffff' }) => {
	const ctx = usePlayerContextOptional();
	if (!ctx) return null;

	const { duration = 0, validatedOptions } = ctx;
	if (validatedOptions?.controlBtn?.times === false) return null;

	return <Text style={[controlStyles.textWhite, { color }]}>{formatTime(duration)}</Text>;
};

export default DurationBtn;
