import { isRunningInExpoGo } from './util';

let CaptureProtection: any = null;

export async function getCaptureProtection() {
	if (isRunningInExpoGo()) return null;
	if (CaptureProtection) return CaptureProtection;

	// 동적 임포트 (Expo Go에선 실행되지 않음)
	const mod = await import('react-native-capture-protection');
	CaptureProtection = mod?.CaptureProtection ?? mod?.default ?? mod;
	return CaptureProtection;
}
