import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, LayoutChangeEvent } from 'react-native';

interface CbtnOption {
	customButton?: any;
	position?: string;
	flow?: string;
}

const Cbtn: React.FC<CbtnOption> = ({ customButton = [], position = 'right-top', flow = 'left' }) => {
	return (
		<>
			{customButton.map((ui: CustomBtnItem, idx: number) => {
				const content = typeof ui.button === 'function' ? ui.button() : ui.button;
				if (!(position === ui.position && flow === ui.flow)) return null;
				return (
					<View key={idx} style={styles.roundedBtnOpa}>
						{content}
					</View>
				);
			})}
		</>
	);
};

const styles = StyleSheet.create({
	roundedBtnOpa: {
		borderRadius: 100,
		backgroundColor: 'rgba(255,255,255,0)',
		color: '#ffffff',
		padding: 3,
		aspectRatio: 1 / 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
});

export default Cbtn;
