import React, { createContext, useContext } from 'react';
import type { ReactNode } from 'react';

import type { VpePlayerEvents, VpePlayerOptions } from './options';

/**
 * 컨트롤 컴포넌트가 prop drilling 없이 플레이어 상태와 액션에 접근하기 위한 컨텍스트.
 *
 * 모든 필드는 옵셔널 — 컨트롤 컴포넌트는 `usePlayerContextOptional()`로 안전하게 사용한다.
 */
export interface PlayerContextValue {
	// 상태
	isPlaying?: boolean;
	isFullScreen?: boolean;
	isMuted?: boolean;
	isLive?: boolean;
	isDvr?: boolean;
	isActive?: boolean;
	isPremiere?: boolean;
	isPip?: boolean;
	isEnded?: boolean;
	/** 영상 시작 전 라이브 진입 대기 상태 (PlayerControls에서 isLive와 함께 LIVE 인디케이터 표시 조건) */
	startPlay?: boolean;
	currentTime?: number;
	duration?: number;
	isMobile?: boolean;
	isPortrait?: boolean;
	hasSubtitle?: boolean;
	/** 현재 선택된 자막 ID. null이면 자막 끄기 상태. */
	selectedSubtitle?: string | null;
	playIdx?: number;
	playlistCnt?: number;
	/**
	 * resolved layout으로부터 전달된 아이콘 디폴트 사이즈.
	 * 컨트롤 컴포넌트는 자체 size prop이 없을 때 이 값을 우선 사용한다.
	 * (ControlBar가 inner PlayerContext.Provider로 주입)
	 */
	iconSize?: number;

	// 액션
	play?: () => void;
	pause?: () => void;
	togglePlay?: () => void;
	seek?: (seconds: number) => void;
	skipForward?: (seconds?: number) => void;
	skipBack?: (seconds?: number) => void;
	toggleMute?: () => void;
	toggleFullScreen?: () => void;
	toggleSettings?: () => void;
	/** 자막 토글 — 켜져있으면 끄고, 꺼져있으면 첫 번째(또는 default) 자막을 켠다. */
	toggleSubtitle?: () => void;
	next?: () => void;
	prev?: () => void;

	// 사용자 콜백/옵션
	events?: VpePlayerEvents | undefined;
	validatedOptions?: VpePlayerOptions;
}

export const PlayerContext = createContext<PlayerContextValue | null>(null);

export interface PlayerProviderProps {
	value: PlayerContextValue;
	children: ReactNode;
}

export const PlayerProvider: React.FC<PlayerProviderProps> = ({ value, children }) => {
	return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
};

/**
 * 컨트롤 컴포넌트 안에서 안전하게 컨텍스트를 가져온다.
 * Provider 밖에서 호출되면 명확한 에러를 던진다.
 */
export function usePlayerContext(): PlayerContextValue {
	const ctx = useContext(PlayerContext);
	if (!ctx) {
		throw new Error('usePlayerContext must be used inside <PlayerProvider> (VpePlayer).');
	}
	return ctx;
}

/**
 * Provider 바깥에서도 안전하게 사용 가능한 옵셔널 버전.
 * 컨텍스트가 없으면 null 반환.
 */
export function usePlayerContextOptional(): PlayerContextValue | null {
	return useContext(PlayerContext);
}
