import { nationCode } from './locales/nationCode';
import { maFetch, generateSessionId, generateUUIDv4, maSyncStart } from './ma';

// ============================================================================
// 타입 정의
// ============================================================================

interface VideoData {
	url?: string;
	type?: string;
	quality?: string;
	data?: any;
}

interface ReportData {
	video: Record<string, any>;
	browser: Record<string, any>;
	device: Record<string, any>;
	connection: Record<string, any>;
	screen: Record<string, any>;
	player_version: string;
	extra: {
		UUID: string | null;
		TID: string | null;
		sessionId: string | null;
		playerType: string;
		playAttempt: boolean;
		[key: string]: any;
	};
	log_type: string;
	privacy: {
		cookie_enabled: boolean;
	};
}

interface StageData {
	platform: string;
	stage: string;
	sync: boolean;
	syncResult: Record<string, any>;
}

interface PlayerState {
	prevAction: string | null;
	isPlaying: boolean;
	isSeeking: boolean;
	initTimeupdate: boolean;
	isBuffering: boolean;
	firstError: boolean;
	isEnded: boolean;
	firstPlay: boolean;
	firstPlaying: boolean;
	startTime: number;
	prevTime: number;
	startUpDuration: number;
	prevUrl: string;
	prevQuality: string;
}

interface EventData {
	type: string;
	data?: any;
}

// ============================================================================
// 상수 정의
// ============================================================================

const DEFAULT_QUALITY = '0p';
const HEARTBEAT_INTERVAL = 59000; // 59초
const MIN_CURRENT_TIME = 1; // 최소 재생 시간 (초)

const ACTION_TYPES = {
	PLAYER_START: 'player_start',
	STARTUP: 'startup',
	PLAY: 'play',
	PAUSE: 'pause',
	PLAYING: 'playing',
	PAUSED: 'paused',
	SEEKING: 'seeking',
	SEEKED: 'seeked',
	WAITING: 'waiting',
	WAITING_END: 'waitingEnd',
	CANPLAY: 'canplay',
	ENDED: 'ended',
	NEXT_TRACK: 'next_track',
	PREV_TRACK: 'prev_track',
	ERROR: 'error',
	QUALITY_CHANGE: 'quality_change',
	REBUFFERING: 'rebuffering',
	TIMEUPDATE: 'timeupdate',
	TIMEUPDATE_FOCUS: 'timeupdateFocus',
} as const;

// ============================================================================
// MaManager 클래스
// ============================================================================

class MaManager {
	// ========================================================================
	// 속성
	// ========================================================================

	private reportData: ReportData;
	private stageData: StageData;
	private state: PlayerState;

	// ========================================================================
	// 생성자
	// ========================================================================

	constructor(platform: string, stage: string, initialData: any) {
		this.stageData = {
			platform,
			stage,
			sync: false,
			syncResult: {},
		};

		this.reportData = {
			video: {},
			browser: {},
			device: {},
			connection: {},
			screen: {},
			player_version: 'latest',
			extra: {
				UUID: null,
				TID: null,
				sessionId: null,
				playerType: 'VPE',
				playAttempt: false,
			},
			log_type: 'vpe',
			privacy: {
				cookie_enabled: true,
			},
		};

		this.state = {
			prevAction: null,
			isPlaying: false,
			isSeeking: false,
			initTimeupdate: false,
			isBuffering: false,
			firstError: false,
			isEnded: false,
			firstPlay: true,
			firstPlaying: true,
			startTime: 0,
			prevTime: 0,
			startUpDuration: 0,
			prevUrl: '',
			prevQuality: DEFAULT_QUALITY,
		};

		this.initializeReportData(initialData);
	}

	// ========================================================================
	// 초기화 메서드
	// ========================================================================

	private initializeReportData(initialData: any): void {
		this.reportData = { ...this.reportData, ...initialData };
		this.reportData.browser.lang = nationCode[this.reportData.extra.nation] || 'ko-KR';
	}

	// ========================================================================
	// 유틸리티 메서드
	// ========================================================================

	/**
	 * 현재 시간 정보를 반환합니다.
	 */
	private getTime(): { logDate: string; logDateUnix: number } {
		const now = new Date();
		const pad = (n: number): string => String(n).padStart(2, '0');

		const logDate = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
		const logDateUnix = Math.floor(now.getTime() / 1000);

		return { logDate, logDateUnix };
	}

	/**
	 * 객체가 순수 객체인지 확인합니다.
	 */
	public isPlainObject(value: any): boolean {
		return typeof value === 'object' && value !== null && !Array.isArray(value);
	}

	// ========================================================================
	// 리포팅 메서드
	// ========================================================================

	/**
	 * MA 리포트를 전송합니다.
	 */
	private async report(action: string, videoData: any): Promise<void> {
		// 에러 발생 후에는 리포팅 중단
		if (this.state.firstError) {
			return;
		}

		const { logDate, logDateUnix } = this.getTime();
		const actionTime = Date.now();
		const actionDuration = this.state.prevTime > 0 ? actionTime - this.state.prevTime : 0;
		const actionDurationTs = actionDuration;

		const sendData = {
			...this.reportData,
			video: this.reportData.video,
			extra: {
				...this.reportData.extra,
				actionType: action,
				actionDuration: actionDurationTs ? actionDurationTs.toFixed(2) : 0,
				logDate,
				logDateUnix,
			},
		};

		this.state.prevTime = actionTime;

		await maFetch(sendData);
	}

	// ========================================================================
	// 공개 메서드 - 초기화 및 동기화
	// ========================================================================

	/**
	 * MA 초기화를 수행합니다.
	 */
	public async maInit(data: any): Promise<void> {
		if (!this.reportData.extra.sessionId) {
			// 세션 ID 생성 로직은 주석 처리되어 있음
		}
		data.extra.sessionId = this.reportData.extra.sessionId;
		await maSyncStart(data);
	}

	/**
	 * MA 데이터를 동기화합니다.
	 */
	public async maSync(inData: any): Promise<void> {
		Object.entries(inData).forEach(([key, value]) => {
			if (this.isPlainObject(inData[key])) {
				Object.entries(inData[key]).forEach(([key2, value2]) => {
					if (value2) {
						this.reportData[key][key2] = value2;
					}
				});
			} else {
				if (value) {
					this.reportData[key] = value;
				}
			}
		});
	}

	// ========================================================================
	// 이벤트 처리 메서드
	// ========================================================================

	/**
	 * 플레이어 이벤트를 처리하고 적절한 리포팅을 수행합니다.
	 */
	public dispatchEvent(event: EventData): void {
		const { type, data } = event;
		const video: VideoData = {
			url: data?.url || this.state.prevUrl,
			type: data?.type,
			quality: data?.quality || this.state.prevQuality,
			data: data,
		};

		switch (type) {
			case ACTION_TYPES.PLAYER_START:
				this.handlePlayerStart(video, data);
				break;

			case ACTION_TYPES.STARTUP:
				this.handleStartup(video, data);
				break;

			case ACTION_TYPES.PLAY:
				this.handlePlay(video, data);
				break;

			case ACTION_TYPES.PAUSE:
				this.handlePause(video, data);
				break;

			case ACTION_TYPES.TIMEUPDATE:
				this.handleTimeUpdate(video, data);
				break;

			case ACTION_TYPES.TIMEUPDATE_FOCUS:
				this.handleTimeUpdateFocus(video, data);
				break;

			case ACTION_TYPES.SEEKING:
				this.handleSeeking(video, data);
				break;

			case ACTION_TYPES.SEEKED:
				this.handleSeeked(video, data);
				break;

			case ACTION_TYPES.WAITING:
				this.handleWaiting(video, data);
				break;

			case ACTION_TYPES.WAITING_END:
				this.handleWaitingEnd(video, data);
				break;

			case ACTION_TYPES.CANPLAY:
				this.handleCanplay(video, data);
				break;

			case ACTION_TYPES.ENDED:
				this.handleEnded(video, data);
				break;

			case 'nextTrack':
			case 'prevTrack':
				this.handleTrackChange(type, video, data);
				break;

			case ACTION_TYPES.ERROR:
				this.handleError(video, data);
				break;

			case ACTION_TYPES.QUALITY_CHANGE:
				this.handleQualityChange(video, data);
				break;
		}
	}

	// ========================================================================
	// 개별 이벤트 핸들러
	// ========================================================================

	/**
	 * player_start 이벤트 처리
	 */
	private handlePlayerStart(video: VideoData, data: any): void {
		if (!this.reportData.extra.sessionId) {
			this.reportData.extra.sessionId = generateSessionId();
			this.reportData.extra.TID = generateUUIDv4();
			this.reportData.extra.UUID = generateUUIDv4();
		}

		this.state.startTime = Date.now();
		this.state.prevTime = this.state.startTime;

		this.report(ACTION_TYPES.PLAYER_START, { ...video, data });
	}

	/**
	 * startup 이벤트 처리
	 */
	private handleStartup(video: VideoData, data: any): void {
		if (this.state.firstPlaying) {
			this.report(ACTION_TYPES.STARTUP, { ...video, data });
			this.state.firstPlaying = false;
		}
	}

	/**
	 * play 이벤트 처리
	 */
	private handlePlay(video: VideoData, data: any): void {
		// 이미 재생 중이면 중복 이벤트 방지
		if (this.state.isPlaying) {
			return;
		}

		this.reportData.extra.playedTime = data?.playedTime;
		this.reportData.extra.percent = data?.percent;
		this.state.isPlaying = true;
		this.reportData.extra.playAttempt = true;

		if (this.state.firstPlay) {
			this.state.firstPlay = false;
		}

		if (this.state.prevAction === ACTION_TYPES.PAUSED) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
		}

		this.state.prevAction = ACTION_TYPES.PLAYING;
	}

	/**
	 * pause 이벤트 처리
	 */
	private handlePause(video: VideoData, data: any): void {
		// seeking/buffering 중이거나 이미 정지 상태이면 무시
		if (this.state.isSeeking || this.state.isBuffering || !this.state.isPlaying) {
			return;
		}

		this.state.isPlaying = false;
		this.report(ACTION_TYPES.PAUSED, { ...video, data });
		this.state.prevAction = ACTION_TYPES.PAUSED;
	}

	/**
	 * timeupdate 이벤트 처리
	 */
	private handleTimeUpdate(video: VideoData, data: any): void {
		this.state.isPlaying = true;
		this.reportData.extra.playAttempt = true;

		if (this.reportData.extra.currentTime < MIN_CURRENT_TIME) {
			return;
		}

		// Heartbeat: 59초마다 playing 리포트 전송
		if (this.state.isPlaying && Date.now() - this.state.prevTime > HEARTBEAT_INTERVAL) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
		}

		this.state.prevUrl = video.url || '';
		this.state.prevQuality = video.quality || DEFAULT_QUALITY;
	}

	/**
	 * timeupdateFocus 이벤트 처리
	 */
	private handleTimeUpdateFocus(video: VideoData, data: any): void {
		if (this.reportData.extra.currentTime > 0) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
			this.state.initTimeupdate = true;
		}
	}

	/**
	 * seeking 이벤트 처리
	 */
	private handleSeeking(video: VideoData, data: any): void {
		if (this.state.isSeeking) {
			return;
		}

		this.state.isSeeking = true;

		if (this.state.isPlaying) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
		} else if (this.state.prevAction === ACTION_TYPES.PAUSED) {
			this.report(ACTION_TYPES.PAUSED, { ...video, data });
		}

		this.state.prevAction = ACTION_TYPES.SEEKING;
	}

	/**
	 * seeked 이벤트 처리
	 */
	private handleSeeked(video: VideoData, data: any): void {
		if (!this.state.isSeeking) {
			return;
		}

		this.state.isSeeking = false;
		this.report(ACTION_TYPES.SEEKING, { ...video, data });
		this.state.prevAction = this.state.isPlaying ? ACTION_TYPES.PLAYING : ACTION_TYPES.PAUSED;
	}

	/**
	 * waiting (buffering start) 이벤트 처리
	 */
	private handleWaiting(video: VideoData, data: any): void {
		if (this.state.isSeeking || this.state.isBuffering) {
			return;
		}

		this.state.isBuffering = true;

		if (this.state.isPlaying) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
		}

		this.state.prevAction = ACTION_TYPES.REBUFFERING;
	}

	/**
	 * waitingEnd (buffering end) 이벤트 처리
	 */
	private handleWaitingEnd(video: VideoData, data: any): void {
		if (this.state.isSeeking || this.state.isBuffering) {
			return;
		}

		this.state.isBuffering = true;

		if (this.state.isPlaying) {
			this.report(ACTION_TYPES.PLAYING, { ...video, data });
		}

		this.state.prevAction = ACTION_TYPES.REBUFFERING;
	}

	/**
	 * canplay (buffering end) 이벤트 처리
	 */
	private handleCanplay(video: VideoData, data: any): void {
		if (!this.state.isBuffering) {
			return;
		}

		this.state.isBuffering = false;
		this.report(ACTION_TYPES.REBUFFERING, { ...video, data });
		this.state.prevAction = this.state.isPlaying ? ACTION_TYPES.PLAYING : ACTION_TYPES.PAUSED;
	}

	/**
	 * ended 이벤트 처리
	 */
	private handleEnded(video: VideoData, data: any): void {
		if (this.state.isEnded) {
			return;
		}

		this.state.isEnded = true;
		this.state.isPlaying = false;

		if (this.state.prevAction !== ACTION_TYPES.PAUSED) {
			this.report(this.state.prevAction || ACTION_TYPES.PLAYING, { ...video, data });
		}

		this.report(ACTION_TYPES.ENDED, { ...video, data });
	}

	/**
	 * nextTrack / prevTrack 이벤트 처리
	 */
	private handleTrackChange(type: string, video: VideoData, data: any): void {
		const actionType = type === 'nextTrack' ? ACTION_TYPES.NEXT_TRACK : ACTION_TYPES.PREV_TRACK;

		this.report(this.state.prevAction || ACTION_TYPES.PLAYING, { ...video, data }).then(() => {
			this.report(actionType, { ...video, data }).then(() => {
				// 다음 트랙을 위한 상태 초기화
				this.resetStateForNewTrack();
			});
		});
	}

	/**
	 * error 이벤트 처리
	 */
	private handleError(video: VideoData, data: any): void {
		// 1. 이전 액션 리포트
		if (this.state.prevAction && !this.state.firstPlaying) {
			this.report(this.state.prevAction, { ...video, data });
		}

		// 2. 에러 정보 파싱
		const errorInfo = {
			errorCode: data?.code || 'E0000',
			errorMessage: data?.message || 'Unknown Error',
		};

		// 3. 에러 리포트
		this.report(ACTION_TYPES.ERROR, { ...video, data: { ...data, ...errorInfo } });

		// 4. 리포팅 중단 플래그 설정
		this.state.firstError = true;
	}

	/**
	 * quality_change 이벤트 처리
	 */
	private handleQualityChange(video: VideoData, data: any): void {
		if (this.state.prevAction && !this.state.isSeeking && !this.state.isBuffering && !this.state.firstPlaying) {
			this.state.isSeeking = true; // 화질 변경을 seeking으로 간주
			this.report(this.state.prevAction, { ...video, data });
			this.state.prevAction = ACTION_TYPES.SEEKING;
		}
	}

	// ========================================================================
	// 상태 초기화 메서드
	// ========================================================================

	/**
	 * 새 트랙 재생을 위해 상태를 초기화합니다.
	 */
	private resetStateForNewTrack(): void {
		this.state.prevAction = null;
		this.state.isPlaying = false;
		this.state.prevTime = 0;
		this.state.firstPlaying = true;
		this.state.initTimeupdate = false;
	}
}

export default MaManager;
