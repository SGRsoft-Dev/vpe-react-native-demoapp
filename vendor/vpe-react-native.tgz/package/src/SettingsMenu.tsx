import React, { useEffect, useRef, useState } from 'react';
import {
	TouchableOpacity,
	StyleSheet,
	Pressable,
	View,
	Text,
	Modal,
	Animated,
	Dimensions,
	ScrollView,
} from 'react-native';
import {
	FadersIcon,
	CaretRightIcon,
	CaretLeftIcon,
	CaretCircleDoubleRightIcon,
	ClosedCaptioningIcon,
	CheckIcon,
} from 'phosphor-react-native';
import t from './locales/i18n';

interface SettingsMenuProps {
	isVisible: boolean;
	isFullScreen: boolean;
	onClose: () => void;
	setQualityLevels: () => void;
	qualityLevels: any;
	selectedQualityLevel: any;
	onQualityChange: (quality: any | null) => void;
	playbackRate: number;
	onPlaybackRateChange: (rate: number) => void;
	availableSubtitles: any[];
	selectedSubtitle: string | null;
	onSubtitleChange: (langId: string | null) => void;
	playRateSetting: number[];
}

const SettingsMenu: React.FC<SettingsMenuProps> = ({
	isVisible,
	isFullScreen,
	onClose,
	qualityLevels,
	selectedQualityLevel,
	onQualityChange,
	playbackRate,
	onPlaybackRateChange,
	availableSubtitles,
	selectedSubtitle,
	onSubtitleChange,
	playRateSetting,
}) => {
	const slideAnim = useRef(new Animated.Value(Dimensions.get('window').height)).current;

	const [menuIdx, setMenuIdx] = useState(0);

	useEffect(() => {
		if (isVisible) {
			Animated.timing(slideAnim, {
				toValue: 0,
				duration: 200,
				useNativeDriver: true,
			}).start();
		}
	}, [isVisible, slideAnim]);

	const handleClose = () => {
		Animated.timing(slideAnim, {
			toValue: Dimensions.get('window').height,
			duration: 200,
			useNativeDriver: true,
		}).start(() => {
			onClose(); // 애니메이션이 끝난 후 모달을 닫습니다.
		});
	};

	useEffect(() => {}, []);

	const renderContent = () => (
		<Pressable style={styles.modalOverlay} onPress={handleClose}>
			<Animated.View
				style={[
					styles.modalContentContainer,
					{ transform: [{ translateY: slideAnim }] },
					{
						paddingHorizontal: isFullScreen ? 160 : 0,
					},
				]}
			>
				<Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
					{menuIdx === 0 && (
						<>
							<View
								style={{
									alignItems: 'center',
									justifyContent: 'center',
									marginBottom: 10,
								}}
							>
								<Pressable
									style={{
										width: 80,
										height: 5,
										backgroundColor: '#a1a1a1',
										borderRadius: 5,
									}}
									onPress={() => {
										handleClose();
									}}
								></Pressable>
							</View>
							{qualityLevels.length > 0 && (
								<TouchableOpacity
									style={styles.modalButton}
									onPress={() => {
										setMenuIdx(1);
									}}
								>
									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'flex-start',
											gap: 5,
										}}
									>
										<FadersIcon color={'#ffffff'} size={20} />
										<Text style={styles.modalButtonText}>{t.settings.quality}</Text>
									</View>
									<View
										style={{
											flexDirection: 'row',
											alignItems: 'center',
											justifyContent: 'flex-start',
											gap: 5,
										}}
									>
										<Text style={[styles.modalButtonText, { opacity: 0.6 }]}>
											{selectedQualityLevel
												? `${selectedQualityLevel?.resolution.h}p`
												: `${t.common.auto}`}
										</Text>
										<CaretRightIcon color={'#ffffff'} size={14} />
									</View>
								</TouchableOpacity>
							)}
							<TouchableOpacity
								style={styles.modalButton}
								onPress={() => {
									setMenuIdx(2);
								}}
							>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
										gap: 5,
									}}
								>
									<CaretCircleDoubleRightIcon color={'#ffffff'} size={20} />
									<Text style={styles.modalButtonText}>{t.settings.playbackRate}</Text>
								</View>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
										gap: 10,
									}}
								>
									<Text style={[styles.modalButtonText, { opacity: 0.6 }]}>{playbackRate}x</Text>
									<CaretRightIcon color={'#ffffff'} size={14} />
								</View>
							</TouchableOpacity>
							<TouchableOpacity
								style={styles.modalButton}
								onPress={() => {
									console.log('자막');
									setMenuIdx(3);
								}}
							>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
										gap: 10,
									}}
								>
									<ClosedCaptioningIcon color={'#ffffff'} size={20} />
									<Text style={styles.modalButtonText}>{t.settings.captions}</Text>
								</View>
								<View
									style={{
										flexDirection: 'row',
										alignItems: 'center',
										justifyContent: 'flex-start',
										gap: 10,
									}}
								>
									<Text style={[styles.modalButtonText, { opacity: 0.6 }]}>
										{selectedSubtitle
											? availableSubtitles.find((s) => s.id === selectedSubtitle)?.label
											: t.common.notUse}
									</Text>
									<CaretRightIcon color={'#ffffff'} size={14} />
								</View>
							</TouchableOpacity>
						</>
					)}

					{menuIdx === 1 && (
						<>
							<View
								style={{
									alignItems: 'center',
									justifyContent: 'center',
									marginBottom: 10,
								}}
							>
								<Pressable
									style={{
										width: 80,
										height: 5,
										backgroundColor: '#a1a1a1',
										borderRadius: 5,
									}}
									onPress={() => {
										handleClose();
									}}
								></Pressable>
							</View>
							<TouchableOpacity
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									justifyContent: 'flex-start',
									gap: 5,
									marginBottom: 20,
								}}
								onPress={() => {
									setMenuIdx(0);
								}}
							>
								<CaretLeftIcon color={'#ffffff'} size={16} />
								<Text style={{ color: '#ffffff', fontSize: 16 }}>{t.settings.quality}</Text>
							</TouchableOpacity>

							<ScrollView>
								<TouchableOpacity
									style={styles.modalButtonCheck}
									onPress={() => {
										onQualityChange(null);
										setMenuIdx(0);
									}}
								>
									<View style={{ width: 20 }}>
										{selectedQualityLevel === null && <CheckIcon color={'#ffffff'} size={14} />}
									</View>

									<Text style={styles.modalButtonText}>{t.common.auto}</Text>
								</TouchableOpacity>

								{qualityLevels?.map((item: any, index: number) => {
									const isSelected = selectedQualityLevel?.uri === item.uri;
									return (
										<TouchableOpacity
											key={item.uri || index}
											style={styles.modalButtonCheck}
											onPress={() => {
												onQualityChange(item);
												setMenuIdx(0);
											}}
										>
											<View style={{ width: 20 }}>
												{isSelected && <CheckIcon color={'#ffffff'} size={14} />}
											</View>

											<Text style={styles.modalButtonText}>{`${item.resolution.h}p`}</Text>
										</TouchableOpacity>
									);
								})}
							</ScrollView>
						</>
					)}

					{menuIdx === 2 && (
						<>
							<View
								style={{
									alignItems: 'center',
									justifyContent: 'center',
									marginBottom: 10,
								}}
							>
								<Pressable
									style={{
										width: 80,
										height: 5,
										backgroundColor: '#a1a1a1',
										borderRadius: 5,
									}}
									onPress={() => {
										handleClose();
									}}
								></Pressable>
							</View>
							<TouchableOpacity
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									justifyContent: 'flex-start',
									gap: 5,
									marginBottom: 20,
								}}
								onPress={() => {
									setMenuIdx(0);
								}}
							>
								<CaretLeftIcon color={'#ffffff'} size={16} />
								<Text style={{ color: '#ffffff', fontSize: 16 }}>{t.settings.playbackRate}</Text>
							</TouchableOpacity>

							<ScrollView>
								{playRateSetting?.map((rate) => (
									<TouchableOpacity
										key={rate}
										style={styles.modalButtonCheck}
										onPress={() => {
											onPlaybackRateChange(rate);
											setMenuIdx(0);
										}}
									>
										<View style={{ width: 20 }}>
											{playbackRate === rate && <CheckIcon color={'#ffffff'} size={14} />}
										</View>

										<Text style={styles.modalButtonText}>{rate}x</Text>
									</TouchableOpacity>
								))}
							</ScrollView>
						</>
					)}

					{menuIdx === 3 && (
						<>
							<View
								style={{
									alignItems: 'center',
									justifyContent: 'center',
									marginBottom: 10,
								}}
							>
								<Pressable
									style={{
										width: 80,
										height: 5,
										backgroundColor: '#a1a1a1',
										borderRadius: 5,
									}}
									onPress={() => {
										handleClose();
									}}
								></Pressable>
							</View>
							<TouchableOpacity
								style={{
									flexDirection: 'row',
									alignItems: 'center',
									justifyContent: 'flex-start',
									gap: 5,
									marginBottom: 20,
								}}
								onPress={() => {
									setMenuIdx(0);
								}}
							>
								<CaretLeftIcon color={'#ffffff'} size={16} />
								<Text style={{ color: '#ffffff', fontSize: 16 }}>{t.settings.captions}</Text>
							</TouchableOpacity>

							<ScrollView>
								<TouchableOpacity
									style={styles.modalButtonCheck}
									onPress={() => {
										onSubtitleChange(null);
										setMenuIdx(0);
									}}
								>
									<View style={{ width: 20 }}>
										{selectedSubtitle === null && <CheckIcon color={'#ffffff'} size={14} />}
									</View>
									<Text style={styles.modalButtonText}>{t.common.notUse}</Text>
								</TouchableOpacity>
								{availableSubtitles.map((item) => (
									<TouchableOpacity
										key={item.id}
										style={styles.modalButtonCheck}
										onPress={() => {
											onSubtitleChange(item.id);
											setMenuIdx(0);
										}}
									>
										<View style={{ width: 20 }}>
											{selectedSubtitle === item.id && <CheckIcon color={'#ffffff'} size={14} />}
										</View>
										<Text style={styles.modalButtonText}>{item.label}</Text>
									</TouchableOpacity>
								))}
							</ScrollView>
						</>
					)}
				</Pressable>
			</Animated.View>
		</Pressable>
	);

	if (!isVisible) {
		return null;
	}

	if (isFullScreen) {
		return <View style={styles.fullScreenModalContainer}>{renderContent()}</View>;
	}

	return (
		<Modal
			animationType="none"
			transparent={true}
			hardwareAccelerated={true}
			visible={isVisible}
			onRequestClose={handleClose}
			presentationStyle={'overFullScreen'}
		>
			{renderContent()}
		</Modal>
	);
};

const styles = StyleSheet.create({
	fullScreenModalContainer: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		zIndex: 10, // Ensure it's on top of other controls
	},
	modalOverlay: {
		flex: 1,
		backgroundColor: 'rgba(0,0,0,0.5)',
		justifyContent: 'flex-end',
	},
	modalContentContainer: {
		// 이 새로운 컨테이너가 애니메이션 대상이 됩니다.
		width: '100%',
	},
	modalContent: {
		backgroundColor: 'rgba(28, 28, 30, 1)', // Dark, slightly transparent background
		paddingTop: 12,
		paddingBottom: 30, // Extra padding for home indicator area
		paddingHorizontal: 20,
		borderTopLeftRadius: 15,
		borderTopRightRadius: 15,
		minHeight: 250,
	},
	modalButton: {
		paddingVertical: 14,
		justifyContent: 'space-between',
		flexDirection: 'row',
	},
	modalButtonCheck: {
		paddingVertical: 14,
		justifyContent: 'flex-start',
		flexDirection: 'row',
		gap: 10,
	},
	modalButtonText: {
		color: '#ffffff',
		fontSize: 14,
		textAlign: 'center',
	},
});

export default SettingsMenu;
