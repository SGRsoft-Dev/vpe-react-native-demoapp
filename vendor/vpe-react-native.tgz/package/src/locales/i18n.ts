import * as Localization from 'expo-localization';

import en from './en';
import ko from './ko';
import ja from './ja';

// 언어팩 맵
const translations = {
	en,
	ko,
	ja,
};

// 디바이스의 언어 코드 가져오기 (e.g., 'en', 'ko')
const getLanguageCode = () => {
	const locales = Localization.getLocales();
	if (locales && locales.length > 0) {
		return locales[0].languageCode;
	}
	return 'en'; // 기본값
};

const langCode = getLanguageCode();

// 지원하는 언어인지 확인하고, 아니면 영어(en)로 대체
const t = translations[langCode] || translations.en;

export default t;
