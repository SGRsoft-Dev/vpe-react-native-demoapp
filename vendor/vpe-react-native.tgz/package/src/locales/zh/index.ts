export default {

    "common": {
        "cancel": "取消",
        "auto": "自动",
        "normal": "一般",
        "notUse": "不使用",
        "prev": "上一个视频",
        "next": "下一个视频",
        "delayText": "{0}秒后自动播放",
        "license": "许可",
        "play": "播放",
        "pause": "暂停",
        "replay": "重新观看",
        "fullOn": "全屏",
        "fullOff": "解除全屏",
        "muteOn": "静音",
        "muteOff": "解除静音",
        "captionOff": "关闭字幕",
        "captionOn": "开启字幕",
        "setting": "设定",
        "live": "LIVE",
        "miniPlayer":"迷你播放器",
        "isMute":"当前处于静音状态。",
    },

    "settings": {
        "autoplay": "自动播放",
        "playbackRate": "播放速度",
        "captions": "字幕",
        "quality": "分辨率",

    },
    "error": {
        "01": {
            "title": "无法播放视频",
                "desc": "错误的访问。"
        },
        "02": {
            "title": "无法播放视频",
                "desc": "因权限问题，无法播放视频。"
        },
        "03": {
            "title": "认证失败",
                "desc": "网络连接不稳定。"
        },
        "04": {
            "title": "无法播放视频",
                "desc": "无法播放视频。"
        },
        "05": {
            "title": "无法播放视频",
                "desc": "该许可无效。"
        },
        "06": {
            "title": "无法播放视频",
            "desc": "已超过每月基本提供的调用次数。请转换为付费版本后使用。"
        }
    },

    "alternative": {
        "hour": "小时",
        "minute": "分钟",
        "second": "秒",
        "after":"请稍后",
        "afterMin":"分钟后",
        "afterHour":"小时后",
        "afterDay":"天后",
        "startPlay":"{timeTxt}之后开始播放视频。",
        "nextPlay":"{timeTxt}秒后，将播放下一个视频。",
        "afterPlay":"预计",
    }


}
