export default {
	common: {
		cancel: '취소',
		auto: '자동',
		normal: '보통',
		notUse: '사용안함',
		prev: '이전 동영상',
		next: '다음 동영상',
		delayText: '초 뒤 자동재생',
		license: '라이선스',
		play: '재생',
		pause: '일시정지',
		replay: '다시보기',
		fullOn: '전체화면',
		fullOff: '전체화면 해제',
		muteOn: '음소거',
		muteOff: '음소거 해제',
		captionOff: '자막끄기',
		captionOn: '자막켜기',
		setting: '설정',
		live: '실시간',
		miniPlayer: '미니플레이어',
		isMute: '음소거 상태입니다.',
		subtitle: '자막',
		subtitleNot: '자막 사용 불가',
	},
	settings: {
		autoplay: '자동재생',
		playbackRate: '재생 속도',
		captions: '자막',
		quality: '해상도',
	},
	error: {
		'01': {
			title: '동영상을 재생할 수 없음',
			desc: '잘못된 접근입니다. access_key를 확인해주세요.',
		},
		'02': {
			title: '동영상을 재생할 수 없음',
			desc: '동영상을 재생할 권한이 없습니다.',
		},
		'03': {
			title: '인증 실패',
			desc: '네트워크 연결이 원활하지 않습니다.',
		},
		'04': {
			title: '동영상을 재생할 수 없음',
			desc: '동영상을 재생할 수 없습니다.',
		},
		'05': {
			title: '동영상을 재생할 수 없음',
			desc: '라이선스가 유효하지 않습니다.',
		},
		'06': {
			title: '동영상을 재생할 수 없음',
			desc: '월 기본 제공 호출 건수를 초과하였습니다. 유료 버전으로 전환 후 사용 부탁 드립니다.',
		},
		'07': {
			title: '동영상을 재생할 수 없음',
			desc: '지원하지 않는 형식입니다.',
		},
		'08': {
			title: '동영상을 재생할 수 없음',
			desc: 'URL 형식이 잘못되었습니다.',
		},
		'09': {
			title: '동영상을 재생할 수 없음',
			desc: '라이브스트림이 OFFLINE 입니다.',
		},
		'10': {
			title: '동영상을 재생할 수 없음',
			desc: 'iOS에서 Dash 비디오를 재생할 수 없습니다.',
		},
		'11': {
			title: '동영상을 재생할 수 없음',
			desc: 'DRM 토큰이 잘못되었습니다.',
		},
		'12': {
			title: '동영상을 재생할 수 없음',
			desc: 'DRM 라이선스 서버와 통신에 실패하였습니다.',
		},
		'13': {
			title: '동영상을 재생할 수 없음',
			desc: 'FairPlay 인증서 검증에 실패하였습니다.',
		},
		'14': {
			title: '동영상을 재생할 수 없음',
			desc: '화면 캡쳐 / 화면 녹화가 감지되었습니다.',
		},
	},

	alternative: {
		hour: '시',
		minute: '분',
		second: '초',
		after: '잠시 ',
		afterMin: '분 ',
		afterHour: '시간 ',
		afterDay: '일 ',
		startPlay: '{timeTxt} 후 영상이 시작됩니다.',
		nextPlay: '{timeTxt}초 후 다음 영상이 재생됩니다.',
		afterPlay: '예정',
	},
};
