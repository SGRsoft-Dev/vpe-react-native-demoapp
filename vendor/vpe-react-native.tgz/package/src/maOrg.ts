import config from './config.js';
import { v4 as uuidv4 } from 'uuid';
import ua from 'ua-parser-js';
import dayjs from 'dayjs';
import timezone from 'dayjs/plugin/timezone.js'; // import plugin
import utc from 'dayjs/plugin/utc.js';
import { nationCode } from '../public/nationCode';
dayjs.extend(timezone); // use plugin
dayjs.extend(utc); // use plugin

let allowBrowser = [
	'Chrome',
	'Edge',
	'Firefox',
	'Samsung Browser',
	'Safari',
	'Mobile Safari',
	'Android',
	'Opera',
	'UCBrowser',
	'IE',
	'Whale',
	'Kakao webview',
	'Naver webview',
];

let allowOs = ['iOS', 'Windows', 'Android', 'Chromium OS', 'Mac OS'];

let allowQuality = ['240p', '360p', '480p', '720p', '1080p', '1440p', '2160p'];

let isVpe = false;
let playerStartTime;
let videoStartTime;
let totalStartTime;
let metadataReadyTime;
let seekedTime;
let bufferedTime;
let playedTime;
let errorTime = null;
let licenseErrorTime = null;

let autoStart = null;

let isSeeking = null;

let isBuffering = null;

let isPause = false;
let isPlay = false;
let isPlaying = false;

let isQuailtyChange = false;

let isEnded = false;

let actionTime = null;
let prevAction = null;
let actionDuration = null;

let prevQuality = '0p';
let prevDuration = null;
let prevCurrentTime = null;
let prevUrl = null;
let prevType = null;
let prevMetaData = null;

let playAttempt = null;

let playerStartData = null;

let video = {
	type: '',
	url: '',
	quality: '',
};

let metaData = { title: 'Untitle' };

let isLifeCycle = '';
let UUID = '';
let TID = uuidv4();

let isError = {};
let vpeInfo = {};

let firstPlay = true;
let firstPlaying = true;
let firstError = false;

let sync = false;
let maSyncCheck = true;

let sessionQueue = [];

let geoLocation = {
	nation: null,
	isp: null,
	address: null,
	lat: 0,
	long: 0,
};

let content_type = 'application/json';

let report_url = null;

let startUpDuration = 0;

let clientIp = 'Unknown';

/**
 * 표준 콘솔로그
 * @param msg
 */
const consoleLog = (msg) => {
	if (!msg) msg = '';
	// console.log(`%c NAVER CLOUD PLATFORM %c Media Analytics `,"background-color:#2ac848;color:#000000;padding:3px;border-radius:3px 0 0 3px","background-color:#ee196e;color:white;padding:3px;;border-radius:0px 3px 3px 0px",msg)
};

/**
 * 초기화
 * @returns {Promise<void>}
 */
const init = async () => {
	resetData();

	UUID = uuidv4();
	startTime = Date.now();

	if (window.vpe?.player_name && window.vpe?.options?.maUse === 'Y') {
		isVpe = true;
		report_url = window.vpe.reportUrl ? window.vpe.reportUrl : config.reportUrl;

		let maSyncCheckUrl = 'https://papi.beta-vpe.naverncp.com/player/maSync';
		// maSyncCheckUrl = 'http://192.168.1.162:3000/api/v1/player/maSync';
		if (window.vpe.env == 'beta') {
			consoleLog('VPE ' + window.vpe.env + ' is loaded');
		} else if (window.vpe.env == 'prod') {
			maSyncCheckUrl = 'https://papi.vpe.naverncp.com/player/maSync';
		}

		let res = await fetch(maSyncCheckUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({
				access_key: window.vpe?.access_key,
			}),
		}).then((res) => {
			return res.text();
		});
		res = JSON.parse(res);
		if (res.result?.sync) {
			console.log('MA Sync Success');

			sync = res?.result?.sync;

			clientIp = res.result.ip;

			if (res.result.geoLocation) {
				let address = [];
				let result = res.result;
				if (nationCode[result.geoLocation?.country]) {
					geoLocation.nation = nationCode[result.geoLocation?.country] || result.geoLocation?.country;
				}
				geoLocation.isp = result.geoLocation.net;
				geoLocation.lat = result.geoLocation.lat;
				geoLocation.long = result.geoLocation.long;

				if (result.geoLocation.r1) address.push(result.geoLocation.r1);
				if (result.geoLocation.r2) address.push(result.geoLocation.r2);
				if (result.geoLocation.r3) address.push(result.geoLocation.r3);

				geoLocation.address = address.join(' ');
			}

			for (let session of sessionQueue) {
				session.extra.nation = geoLocation.nation || 'Unknown';
				session.extra.isp = geoLocation.isp || 'Unknown';
				session.extra.address = geoLocation.address || 'Unknown';
				session.extra.ip = clientIp || 'Unknown';
				let report_data = JSON.stringify(session);
				if (window.vpe.env == 'beta') {
					if (navigator.sendBeacon) {
						if (playerStartData) {
							let data = JSON.parse(playerStartData);
							playerStartData = null;

							data.extra.quality = allowQuality.includes(prevQuality)
								? prevQuality
								: prevQuality === '0p'
									? 'Unknown'
									: 'Other';
							data.extra.type = prevType?.toUpperCase() || 'Unknown';
							data.extra.nation = geoLocation.nation || 'Unknown';
							data.extra.isp = geoLocation.isp || 'Unknown';
							data.extra.address = geoLocation.address || 'Unknown';
							data.extra.ip = clientIp || 'Unknown';

							let data2 = JSON.stringify(data);
							let blob_data2 = new Blob([data2], { type: content_type });

							navigator.sendBeacon(report_url, blob_data2);

							try {
								data.extra.actionDuration =
									Math.round((data.extra.actionDuration / 1000) * 1000) / 1000;
								sessionTable(data.extra);
							} catch (e) {}
						}

						let blob_data = new Blob([report_data], { type: content_type });
						navigator.sendBeacon(report_url, blob_data);
					} else {
						if (playerStartData) {
							let data = JSON.parse(playerStartData);

							playerStartData = null;

							data.extra.quality = allowQuality.includes(prevQuality)
								? prevQuality
								: prevQuality === '0p'
									? 'Unknown'
									: 'Other';
							data.extra.type = prevType?.toUpperCase() || 'Unknown';
							data.extra.nation = geoLocation.nation || 'Unknown';
							data.extra.isp = geoLocation.isp || 'Unknown';
							data.extra.address = geoLocation.address || 'Unknown';
							data.extra.ip = clientIp || 'Unknown';

							let data2 = JSON.stringify(data);

							fetch(report_url, {
								method: 'POST',
								headers: { 'Content-Type': content_type },
								body: data2,
							});

							try {
								data.extra.actionDuration =
									Math.round((data.extra.actionDuration / 1000) * 1000) / 1000;
								sessionTable(data.extra);
							} catch (e) {}
						}

						fetch(report_url, {
							method: 'POST',
							headers: { 'Content-Type': content_type },
							body: report_data,
						});
					}
					try {
						session.extra.actionDuration = Math.round((session.extra.actionDuration / 1000) * 1000) / 1000;
						sessionTable(session.extra);
					} catch (e) {}
				}
			}
			sessionQueue = [];
		} else {
			console.log('MA Sync Fail');
			maSyncCheck = false;
		}
	} else {
		maSyncCheck = false;
	}
};

/**
 * 현재 시간
 * @returns {number}
 */

let startTime = null;
let prevTime = null;

let sendDataValue = {};
const sendDataSet = () => {
	report_url = window.vpe.reportUrl ? window.vpe.reportUrl : config.reportUrl;
	if (window.vpe.env == 'beta') {
		config.mode = 'beta';
	} else {
		config.mode = 'prod';
	}

	sendDataValue = {
		player_name: window.vpe.player_name,
		cid: window.vpe.pecid ? window.vpe.pecid : '',
		created_at: 0,

		video: {
			type: '',
			url: '',
			quality: '',
		},
		browser: {
			ua: '',
			lang: '',
			platform: '',
		},
		device: {
			platform: '',
			processor: 0,
			memory: 0,
			mobile: false,
		},
		connection: {
			downlink: 0,
			network: '',
			rtt: 0,
			save_data: false,
		},
		screen: {},
	};

	try {
		if (sendDataValue.player_name.indexOf('|')) {
			let player_name = sendDataValue.player_name.split('|')[0];
			let player_version = sendDataValue.player_name.split('|')[1];
			sendDataValue.player_name = player_name;
			sendDataValue.player_version = player_version;

			vpeInfo.player_name = player_name;
			vpeInfo.player_version = player_version;
		}
	} catch (e) {}

	if (window.screen) {
		sendDataValue.screen = {
			width: screen.width,
			height: screen.height,
		};
	}

	if (navigator.platform) {
		sendDataValue.device.platform = navigator.platform;
	}

	if (navigator.cookieEnabled === false) {
		sendDataValue.privacy.cookie_enabled = false;
	}

	if (navigator.deviceMemory) {
		sendDataValue.device.memory = navigator.deviceMemory;
	}

	if (navigator.hardwareConcurrency) {
		sendDataValue.device.processor = navigator.hardwareConcurrency;
	}

	if (navigator.userAgent) {
		sendDataValue.browser.ua = navigator.userAgent;
	}

	if (navigator.userAgentData) {
		sendDataValue.browser.mobile = navigator.userAgent.mobile;
		sendDataValue.browser.platform = navigator.userAgent.platform;
	}

	if (navigator.userAgent.toLowerCase().indexOf('iphone') > -1) {
		sendDataValue.browser.mobile = true;
		if (!sendDataValue.device) sendDataValue.device = {};
		sendDataValue.device.mobile = true;
	}

	if (navigator.userAgent.toLowerCase().indexOf('android') > -1) {
		sendDataValue.browser.mobile = true;
		if (!sendDataValue.device) sendDataValue.device = {};
		sendDataValue.device.mobile = true;
	}

	if (navigator.language) {
		sendDataValue.browser.lang = navigator.language;
	}

	let connection = navigator.connection || navigator.mozConnection || navigator.webkitConnection;

	if (connection) {
		sendDataValue.connection.downlink = connection.downlink;
		sendDataValue.connection.network = connection.effectiveType;
		sendDataValue.connection.rtt = connection.rtt;
		sendDataValue.connection.save_data = connection.saveData;
	}

	sendDataValue.video = video;
	sendDataValue.created_at = new Date().getTime();

	return sendDataValue;
};

/**
 * MA Report
 * @param datas
 * @returns {Promise<void>}
 */
const reportMa = async (datas) => {
	if (!maSyncCheck) return;
	// console.log(datas.type)
	metaData.title = datas?.statusData?.metaData?.title;
	// console.log(dayjs().format('YYYY-MM-DD hh:mm:ss'),datas.type,datas.statusData?.metaData?.title,datas.statusData.player_type,datas.statusData.video_url,datas.data.duration,datas.statusData.video_quality);
	sendDataSet();

	// if(errorTime) return ;
	if (!isVpe) return;
	video.type = datas.statusData.player_type;
	video.url = datas.statusData.video_url;
	video.quality = datas.statusData.video_quality;
	video.data = datas.data;

	if (video.quality === ('0p' || null)) {
		video.quality = prevQuality || '0p';
	}

	if (datas.type === 'timeupdate') {
		prevDuration = video.data.duration;
		prevQuality = video.quality;
		prevCurrentTime = video.data.currentTime;

		if (!isPlaying) return;

		if (Date.now() - prevTime > 59000) {
			actionTime = Date.now();
			actionDuration = actionTime - prevTime;
			report('playing', video);
			prevAction = 'playing';
			prevTime = actionTime;
		}

		return;
	}

	if (datas.type == 'start') {
		firstPlay = true;
		firstPlaying = true;
		startTime = Date.now();
		return;
	}

	if (datas.type == 'ready') {
		// getSetDuration()
		actionTime = Date.now();
		actionDuration = actionTime - startTime;
		prevTime = actionTime;
		// video.type = null;
		report('player_start', video);
		return;
	}

	// if(datas.type === 'loadstart') {
	//     if(!isMetaDataReady) return;
	//     actionDuration = 0;
	//     report('quality_change',video);
	//     prevAction = 'rebuffering';
	//     isQuailtyChange = true;
	// }

	if (datas.type === 'quality_change') {
		// if(!prevAction) return;

		// console.log(prevAction,isSeeking,isBuffering,firstPlaying)
		if (prevAction && !isSeeking && !isBuffering && !firstPlaying) {
			isQuailtyChange = true;
			isSeeking = true;
			actionTime = Date.now();
			actionDuration = actionTime - prevTime;

			report(prevAction, video);
			prevTime = actionTime;
		}
		//
		// // if(isSeeking || isBuffering || firstPlaying) {
		//     actionDuration = 0;
		//     report('quality_change',video);
		//     // isQuailtyChange = false;
		// // }
		//
		return;
	}

	// if(datas.type =='loadedmetadata') {
	//     prevUrl = video.url;
	//     if(firstPlay) autoStart = true;
	//     actionTime = Date.now();
	//     actionDuration = actionTime - prevTime;
	//     prevTime = actionTime;
	//
	//     if(firstPlaying) {
	//         report('metadata_ready',video);
	//         isMetaDataReady = true;
	//     }else {
	//         // prevAction = 'quality_chagne';
	//         // report('quality_chagne',video);
	//     }
	//
	//     return;
	// }

	if (datas.type == 'canplay') {
		if (firstPlaying) return;
		if (!isBuffering) return;
		if (isQuailtyChange) return;

		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		prevTime = actionTime;
		report('rebuffering', video);

		isBuffering = null;
		isSeeking = null;
	}

	if (datas.type == 'durationchange') {
		prevMetaData = datas?.statusData?.metaData || null;
		prevUrl = video.url;
		prevType = video.type;
		prevQuality = video.quality;
	}

	if (datas.type == 'play') {
		isPause = false;
		if (!firstPlay) return;
		playAttempt = true;
		prevTime = Date.now();
		firstPlay = false;
		video.url = prevUrl;
		return;
	}

	if (datas.type == 'playing') {
		isPlaying = true;
		isPause = false;
		isError = {};
		prevType = video.type;

		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		// console.log('222',isQuailtyChange,isSeeking)
		if (isQuailtyChange && isSeeking) {
			isQuailtyChange = false;
			isSeeking = false;
			report('seeking', video);
		} else if (prevAction === 'paused' && !isSeeking) {
			actionTime = Date.now();
			if (actionDuration > 50) {
				report('paused', video);
				prevTime = actionTime;
			}
		} else if (firstPlaying) {
			startUpDuration ? (actionDuration = startUpDuration) : (actionDuration = actionDuration);
			report('startup', video);
			firstPlaying = false;
		} else if (prevAction !== 'playing' && !isEnded && isPlay && actionDuration > 50) {
			report(prevAction, video);
		}

		isPlay = false;
		isEnded = false;
		isBuffering = null;
		prevAction = 'playing';
		prevTime = actionTime;

		return;
	}

	if (datas.type == 'pause') {
		if (prevAction === 'paused') return;
		if (firstPlaying) {
			isPause = true;
			return;
		}
		isPlaying = false;
		isPause = true;
		// if(isQuailtyChange) {
		//     isSeeking = true;
		//     return;
		// }
		if (isSeeking) return;
		if (isBuffering) return;
		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		if (!firstPlaying && !isQuailtyChange) {
			report(prevAction, video);
			prevTime = actionTime;
		} else {
			startUpDuration = actionDuration;
		}

		prevAction = 'paused';

		return;
	}

	if (datas.type == 'seeking') {
		if (isSeeking) return;
		if (firstPlaying) return;

		if (prevAction === 'rebuffering') {
			// 라이브 중에 리버퍼링중 시킹이 발생하면 리버퍼링으로 처리
			if (prevType === 'live') {
				return;
			}

			actionTime = Date.now();
			actionDuration = actionTime - prevTime;

			isSeeking = true;

			if (isQuailtyChange) return;
			isSeeking = true;
			report('rebuffering', video);
			isBuffering = null;
			prevTime = actionTime;
			return;
		}

		actionTime = Date.now();
		actionDuration = actionTime - prevTime;

		isSeeking = true;

		if (isPause) {
			video.data.currentTime = prevCurrentTime;
			report('paused', video);
			prevTime = actionTime;
			return;
		}

		if (isPlaying) {
			video.data.currentTime = prevCurrentTime;
			report('playing', video);
			prevTime = actionTime;
			return;
		}

		return;
	}

	if (datas.type == 'seeked') {
		if (!isSeeking) return;
		if (firstPlaying) return;

		isSeeking = null;
		isBuffering = null;

		actionTime = Date.now();
		actionDuration = actionTime - prevTime;

		if (prevAction === 'rebuffering') {
			if (actionDuration < 50) {
				return;
			}

			if (video.type === 'live') {
				return;
			}
		}

		report('seeking', video);

		if (isPause) {
			prevAction = 'paused';
		}

		if (isPlaying) {
			prevAction = 'playing';
		}

		prevTime = actionTime;

		return;
	}

	if (datas.type == 'waiting') {
		if (isSeeking) return;
		if (isBuffering) return;
		if (firstPlaying) return;
		if (prevAction === 'rebuffering') return;

		if (isQuailtyChange) {
			prevAction = 'rebuffering';
			return;
		}

		actionTime = Date.now();
		actionDuration = actionTime - prevTime;

		// if(actionDuration < 10) {
		//     return;
		// }

		if (isPlaying) {
			if (Date.now() - prevTime < 100) {
				prevAction = 'rebuffering';
				return;
			}
		}

		report(prevAction, video);

		prevAction = 'rebuffering';

		if (isSeeking) {
			prevAction = 'seeking';
		}

		isBuffering = true;
		prevTime = Date.now();
		return;
	}

	if (datas.type == 'ended') {
		//라이브일때 ended 안찍음
		if (video.type === 'live') return;

		isPlaying = false;
		isEnded = true;
		actionTime = Date.now();
		actionDuration = actionTime - prevTime;

		if (prevAction !== 'paused') {
			report(prevAction, video);
		}

		actionDuration = 0;
		report('ended', video);

		prevTime = actionTime;

		return;
	}

	if (datas.type == 'nextTrack') {
		isPlaying = false;
		// isMetaDataReady = false;
		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		video.quality = prevQuality;
		video.type = prevType?.toUpperCase();
		video.url = prevUrl;
		metaData.title = prevMetaData?.title || 'Untitle';
		if (isSeeking) prevAction = 'seeking';
		if (isBuffering) prevAction = 'rebuffering';
		report(prevAction, video).then(() => {
			actionDuration = 0;

			report('next_track', video).then(() => {
				TID = uuidv4();
				prevQuality = '0p';
				prevDuration = null;
				prevCurrentTime = null;
				prevAction = null;
				prevUrl = datas.statusData.video_url;
				isSeeking = null;
				isBuffering = null;
			});
		});

		prevTime = actionTime;

		return;
	}

	if (datas.type == 'prevTrack') {
		isPlaying = false;
		// isMetaDataReady = false;
		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		video.url = prevUrl;
		video.quality = prevQuality;
		video.type = prevType?.toUpperCase();
		metaData.title = prevMetaData?.title || 'Untitle';
		if (isSeeking) prevAction = 'seeking';
		if (isBuffering) prevAction = 'rebuffering';
		report(prevAction, video).then(() => {
			actionDuration = 0;

			report('prev_track', video).then(() => {
				TID = uuidv4();
				prevQuality = '0p';
				prevDuration = null;
				prevCurrentTime = null;
				prevAction = null;
				prevUrl = datas.statusData.video_url;
				isSeeking = null;
				isBuffering = null;
			});
		});

		prevTime = actionTime;

		return;
	}

	if (datas.type == 'error') {
		actionTime = Date.now();
		actionDuration = actionTime - prevTime;
		if (prevAction && !firstPlaying) {
			if (isSeeking) prevAction = 'seeking';
			report(prevAction, video);
		}

		MAsendError(datas);
		return;
	}

	if (video.quality !== '0p') {
		prevQuality = video.quality;
	}
};

/**
 * MA Error Report
 * @param val
 * @returns {Promise<void>}
 * @constructor
 */
const MAsendError = async (val) => {
	// actionTime = Date.now();
	// errorTime = +((actionTime - startTime) / 1000).toFixed(3);
	actionDuration = 0;

	if (typeof val.data === 'object') {
		if (val.data.code == 'E0005') {
			licenseErrorTime = errorTime;
			// console.log("MA Error Report",val.data.code,val.data.message);
		}

		isError = {
			code: val.data.code ? val.data.code : 'E0000',
			message: val.data.message,
		};
	} else {
		isError = {
			code: 'E0000',
			message: val.data,
		};
	}

	await report('error', val);
};

const report = async (action_type, extra_data = null) => {
	if (action_type === null) return;
	if (firstError) return;

	let playAttempt2 = null;
	if (playAttempt && (action_type === 'startup' || action_type === 'error')) {
		playAttempt = null;
		playAttempt2 = true;
	}

	isLifeCycle = action_type;

	// actionDuration = +(actionDuration / 1000).toFixed(3);

	if (actionDuration > 9999 * 1000) {
		actionDuration = 9999 * 1000;
	}

	if (!extra_data.data.duration) {
		extra_data.data.duration = prevDuration;
	}
	if (!extra_data.data.currentTime && action_type !== 'seeking') {
		extra_data.data.currentTime = prevCurrentTime;
	}

	if (video.type === 'live') {
		extra_data.data.duration = 0;
		extra_data.data.percent = 0;
	} else {
		extra_data.data.percent = +((extra_data.data.currentTime / extra_data.data.duration) * 100).toFixed(2);
	}

	if (action_type === 'playing') {
		playedTime = actionDuration;
	} else if (action_type === 'player_start') {
		playerStartTime = actionDuration;
	} else if (action_type === 'startup') {
		videoStartTime = actionDuration;
	} else if (action_type === 'seeking') {
		seekedTime = actionDuration;
	} else if (action_type === 'rebuffering') {
		bufferedTime = actionDuration;
	} else if (action_type === 'error') {
		firstError = true;
	}

	let parser = ua(window.navigator.userAgent);
	if (window.navigator.userAgent.toLowerCase().includes('whale')) {
		parser.browser.name = 'Whale';
	} else if (window.navigator.userAgent.toLowerCase().includes('kakaotalk')) {
		parser.browser.name = 'Kakao webview';
	} else if (window.navigator.userAgent.toLowerCase().includes('naver')) {
		parser.browser.name = 'Naver webview';
	} else if (window.navigator.userAgent.toLowerCase().includes('kakao')) {
		parser.browser.name = 'Kakao webview';
	} else if (window.navigator.userAgent.toLowerCase().includes('naver')) {
		parser.browser.name = 'Naver webview';
	}
	try {
		window.navigator.userAgentData.getHighEntropyValues(['platformVersion']).then((ua) => {
			if (navigator.userAgentData.platform === 'Windows') {
				const majorPlatformVersion = parseInt(ua.platformVersion.split('.')[0]);
				// console.log(majorPlatformVersion)
				if (majorPlatformVersion >= 13) {
					// console.log("Windows 11 or later");
					parser.os.version = '11';
				} else if (majorPlatformVersion > 0) {
					// console.log("Windows 10");
				} else {
					// console.log("Before Windows 10");
				}
			} else {
				// console.log("Not running on Windows");
			}
		});
	} catch (e) {}

	let packageId = '';

	if (window.navigator.userAgent.indexOf('VPE_PACKAGE_ID=') > 0) {
		packageId = window.navigator.userAgent.split('VPE_PACKAGE_ID=')[1].split('&|')[0];
	}

	if (extra_data.data.videoProtocol === 'http') {
		extra_data.data.videoProtocol = video.url.split('://')[0];
	}

	sendDataValue.extra = {
		actionType: action_type,
		UUID: UUID,
		TID: TID,
		logDate: dayjs().tz('Asia/Seoul').format('YYYY-MM-DD HH:mm:ss'),
		logDateUnix: actionTime,
		playAttempt: playAttempt2,
		actionDuration,
		playerStartTime,
		videoStartTime,
		totalStartTime,
		seekedTime,
		bufferedTime,
		playedTime,
		vpeKey: window.vpe.access_key,
		playerType: 'VPE',
		playerVersion: vpeInfo.player_version || 'Unknown',
		url: video.url,
		type: prevType?.toUpperCase() || 'Unknown',
		quality: allowQuality.includes(video.quality) ? video.quality : video.quality === '0p' ? 'Unknown' : 'Other',
		qualityOrigin: video.quality !== '0p' ? (video.quality === null ? 'Unknown' : video.quality) : video.quality,
		errorCode: isError ? isError.code : '',
		errorMessage: isError ? isError.message : '',
		os: allowOs.includes(parser.os.name) ? `${parser.os.name} / ${parser.os.version}` || 'Unknown' : 'Other',
		osOrigin: parser.os.name || 'Unknown',
		osVersion: parser.os.version,
		browser: allowBrowser.includes(parser.browser.name) ? parser.browser.name || 'Unknown' : 'Other',
		browserOrigin: parser.browser.name || 'Unknown',
		browserVersion: parser.browser.version || 'Unknown',
		device: parser.device.vendor + ' ' + parser.device.model,
		location: window.location.href,
		host: window.location.host,
		port: window.location.port,
		protocol: window.location.protocol,
		vpePackageId: packageId,
		nation: geoLocation.nation || 'Unknown',
		isp: geoLocation.isp || 'Unknown',
		address: geoLocation.address || 'Unknown',
		title: metaData?.title || 'Untitle',
		ip: clientIp || 'Unknown',
		...extra_data.data,
	};

	if (parser.os.name === 'Mac OS' && parser.os.version === '10.15.7') {
		sendDataValue.extra.os = 'Mac OS / 10.15.7 ↑';
		sendDataValue.extra.osVersion = '10.15.7 ↑';
	}

	isError = {};

	if (action_type !== 'buffering') {
		delete sendDataValue.extra.isBuffering;
	}
	if (action_type !== 'seeking') {
		delete sendDataValue.extra.isSeeking;
	}
	if (action_type === 'exit' || action_type === 'error' || action_type === 'ended') {
		sendDataValue.extra.logDateUnix++;
	}
	if (
		action_type === 'next_track' ||
		action_type === 'prev_track' ||
		action_type === 'playing' ||
		action_type === 'paused'
	) {
		// console.log(sendDataValue.extra.title,prevMetaData?.title)
		// sendDataValue.extra.url = prevUrl;
		// sendDataValue.extra.type = prevType?.toUpperCase();
		sendDataValue.extra.title = prevMetaData?.title || 'Untitle';
	}

	if (!['player_start', 'startup', 'error'].includes(action_type)) {
		sendDataValue.extra.playerStartTime = null;
		sendDataValue.extra.videoStartTime = null;
		sendDataValue.extra.totalStartTime = null;
	}

	sendDataValue.log_type = 'MA';

	let report_data = JSON.stringify(sendDataValue);

	if (window.vpe.env == 'beta') {
		config.mode = 'beta';
	} else {
		config.mode = 'prod';
	}

	try {
		if (action_type === 'player_start') {
			playerStartData = report_data;
			return;
		}
		if (!sync) {
			sessionQueue.push(sendDataValue);
			return;
		}

		if (navigator.sendBeacon) {
			if (playerStartData) {
				let data = JSON.parse(playerStartData);
				playerStartData = null;
				data.extra.quality = allowQuality.includes(prevQuality)
					? prevQuality
					: prevQuality === '0p'
						? 'Unknown'
						: 'Other';
				data.extra.type = prevType?.toUpperCase() || 'Unknown';
				data.extra.nation = geoLocation.nation || 'Unknown';
				data.extra.isp = geoLocation.isp || 'Unknown';
				data.extra.address = geoLocation.address || 'Unknown';
				data.extra.ip = clientIp || 'Unknown';

				let data2 = JSON.stringify(data);
				let blob_data2 = new Blob([data2], { type: content_type });
				navigator.sendBeacon(report_url, blob_data2);

				try {
					data.extra.actionDuration = Math.round((data.extra.actionDuration / 1000) * 1000) / 1000;
					sessionTable(data.extra);
				} catch (e) {}
			}
			var blob_data = new Blob([report_data], { type: content_type });
			navigator.sendBeacon(report_url, blob_data);
		} else {
			if (playerStartData) {
				let data = JSON.parse(playerStartData);
				playerStartData = null;
				data.extra.quality = allowQuality.includes(prevQuality)
					? prevQuality
					: prevQuality === '0p'
						? 'Unknown'
						: 'Other';
				data.extra.type = prevType?.toUpperCase() || 'Unknown';
				data.extra.nation = geoLocation.nation || 'Unknown';
				data.extra.isp = geoLocation.isp || 'Unknown';
				data.extra.address = geoLocation.address || 'Unknown';
				data.extra.ip = clientIp || 'Unknown';

				let data2 = JSON.stringify(data);

				fetch(report_url, {
					method: 'POST',
					headers: { 'Content-Type': content_type },
					body: data2,
				});

				try {
					data.extra.actionDuration = Math.round((data.extra.actionDuration / 1000) * 1000) / 1000;
					sessionTable(data.extra);
				} catch (e) {}
			}
			fetch(report_url, {
				method: 'POST',
				headers: { 'Content-Type': content_type },
				body: report_data,
			});
		}

		try {
			sendDataValue.extra.actionDuration = Math.round((sendDataValue.extra.actionDuration / 1000) * 1000) / 1000;
			sessionTable(sendDataValue.extra);
		} catch (e) {}
	} catch (err) {}
	playedTime = null;
	seekedTime = null;
	bufferedTime = null;
};

function resetData() {
	isVpe = false;
	playerStartTime = null;
	videoStartTime = null;
	totalStartTime = null;
	metadataReadyTime = null;
	seekedTime = null;
	bufferedTime = null;
	playedTime = null;
	errorTime = null;
	licenseErrorTime = null;

	autoStart = null;

	isSeeking = null;

	isBuffering = null;

	isPause = false;
	isPlay = false;
	isPlaying = false;

	isQuailtyChange = false;

	isEnded = false;

	actionTime = null;
	prevAction = null;
	actionDuration = null;

	prevQuality = '0p';
	prevDuration = null;
	prevCurrentTime = null;
	prevUrl = null;
	prevType = null;
	prevMetaData = null;

	playAttempt = null;

	playerStartData = null;

	video = {
		type: '',
		url: '',
		quality: '',
	};

	metaData = { title: 'Untitle' };

	isLifeCycle = '';
	UUID = '';
	TID = uuidv4();

	isError = {};
	vpeInfo = {};

	firstPlay = true;
	firstPlaying = true;
	firstError = false;

	sync = null;
	maSyncCheck = true;

	sessionQueue = [];

	geoLocation = {
		nation: null,
		isp: null,
		address: null,
		lat: 0,
		long: 0,
	};

	content_type = 'application/json';

	startUpDuration = 0;
}

/**
 * MA 상태 Report
 * @returns {Promise<void>}
 * @constructor
 */
// let MAstate = async () => {
//     let logTxt = {
//
//         playerStartTime,
//         metadataReadyTime,
//         videoStartTime,
//         totalStartTime,
//         licenseErrorTime,
//         errorTime,
//         errorCode : isError ? isError.code:'',
//         errorMessage : isError ? isError.message:'',
//         video:video.url,
//         type:video.type,
//         quality:video.quality,
//         lastLifeCycle:isLifeCycle,
//     }
//     consoleLog('State Report');
//     console.table(logTxt);
//     console.log(sendDataValue);
//
//
// }

window.maInit = init;
window.reportMa = reportMa;
