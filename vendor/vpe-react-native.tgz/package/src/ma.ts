// ============================================================================
// 타입 정의
// ============================================================================

interface ReportData {
	video: Record<string, any>;
	browser: Record<string, any>;
	device: Record<string, any>;
	connection: Record<string, any>;
	screen: Record<string, any>;
	player_version: string;
	extra: {
		sessionId: string | null;
		playerType: string;
		logDate?: string;
		logDateUnix?: number;
		address?: string;
		isp?: string;
		ip?: string;
		nation?: string;
		actionDuration?: number | string;
		actionType?: string;
		playerStartTime?: number;
		videoStartTime?: number;
		totalStartTime?: number;
		seekedTime?: number;
		playedTime?: number;
		type?: string;
		url?: string;
		videoFormat?: string;
		UUID?: string;
		TID?: string;
		currentTime?: number;
		percent?: number;
		[key: string]: any;
	};
	log_type: string;
	privacy: {
		cookie_enabled: boolean;
	};
}

interface StageData {
	platform: string;
	stage: string;
	sync: boolean;
	syncResult: {
		geoLocation?: {
			r1?: string;
			r2?: string;
			r3?: string;
			net?: string;
			country?: string;
		};
		ip?: string;
		[key: string]: any;
	};
}

interface TimeInfo {
	logDate: string;
	logDateUnix: number;
	thisSec: number;
}

// ============================================================================
// 상수 정의
// ============================================================================

// prettier-ignore
import { nationCode } from './locales/nationCode';

const ENCODED_API_PATH = {
	gov: {
		prod: {
			log: 'https://papi.vpe.gov-ntruss.com/player/maSync',
			report: 'https://log.vpe.gov-ntruss.com/stats',
		},
		beta: {
			log: 'https://papi.beta-vpe.gov-ntruss.com/player/maSync',
			report: 'https://log.beta-vpe.gov-ntruss.com/stats',
		},
	},
	pub: {
		prod: {
			log: 'https://papi.vpe.naverncp.com/player/maSync',
			report: 'https://log.vpe.naverncp.com/stats',
		},
		beta: {
			log: 'https://papi.beta-vpe.naverncp.com/player/maSync',
			report: 'https://log.beta-vpe.naverncp.com/stats',
		},
	},
};

const UUID_CHARS = 'abcdefghijklmnopqrstuvwxyz0123456789';
const UUID_PATTERN = [8, 4, 4, 4, 12];
const SESSION_ID_PATTERN = [8, 4, 4, 4, 12];

// ============================================================================
// 전역 상태
// ============================================================================

let reportData: ReportData = {
	video: {},
	browser: {},
	device: {},
	connection: {},
	screen: {},
	player_version: 'latest',
	extra: {
		sessionId: null,
		playerType: 'VPE React Native',
	},
	log_type: 'vpe',
	privacy: {
		cookie_enabled: true,
	},
};

let stageData: StageData = {
	platform: 'pub',
	stage: 'prod',
	sync: false,
	syncResult: {},
};

const startTimeAt = new Date().getTime();

// ============================================================================
// 유틸리티 함수
// ============================================================================

/**
 * Base64 디코딩 (현재는 사용되지 않지만 유지)
 */
const detcosde = (str: string): string => {
	// prettier-ignore
	return str;
};

/**
 * UUID v4 형식의 세션 ID를 생성합니다 (하이픈 포함)
 */
export function generateUUIDv4(): string {
	const sections = UUID_PATTERN;
	const uuid: string[] = [];

	sections.forEach((len, i) => {
		for (let j = 0; j < len; j++) {
			const randomIndex = Math.floor(Math.random() * UUID_CHARS.length);
			uuid.push(UUID_CHARS[randomIndex]);
		}
		if (i < sections.length - 1) {
			uuid.push('-');
		}
	});

	return uuid.join('');
}

/**
 * 단순 세션 ID를 생성합니다 (하이픈 없음)
 */
export function generateSessionId(): string {
	const sections = SESSION_ID_PATTERN;
	const uuid: string[] = [];

	sections.forEach((len) => {
		for (let j = 0; j < len; j++) {
			const randomIndex = Math.floor(Math.random() * UUID_CHARS.length);
			uuid.push(UUID_CHARS[randomIndex]);
		}
	});

	return uuid.join('');
}

/**
 * 현재 시간 정보를 반환합니다
 */
export const thisTime = (): TimeInfo => {
	const now = new Date();
	const pad = (n: number): string => String(n).padStart(2, '0');

	const logDate = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
	const logDateUnix = Math.floor(now.getTime() / 1000);
	const thisSec = new Date().getTime() - startTimeAt;

	return {
		logDate,
		logDateUnix,
		thisSec,
	};
};

/**
 * 경과 시간(초)를 반환합니다
 */
export const thisSec = (): number => {
	return Math.floor((new Date().getTime() - startTimeAt) / 1000);
};

/**
 * 값이 순수 객체인지 확인합니다
 */
function isPlainObject(value: any): boolean {
	return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * 객체를 깊이 병합합니다
 */
function deepMerge(target: any, source: any): void {
	Object.entries(source).forEach(([key, value]) => {
		if (isPlainObject(value)) {
			if (!target[key]) {
				target[key] = {};
			}
			Object.entries(value).forEach(([subKey, subValue]) => {
				if (subValue !== undefined && subValue !== null) {
					target[key][subKey] = subValue;
				}
			});
		} else {
			if (value !== undefined && value !== null) {
				target[key] = value;
			}
		}
	});
}

/**
 * 비디오 포맷을 URL에서 추론합니다
 */
function inferVideoFormat(url: string): string {
	if (url.indexOf('m3u8') > -1) return 'hls';
	if (url.indexOf('mpd') > -1) return 'dash';
	return 'mp4';
}

/**
 * 지리 정보를 문자열로 포맷합니다
 */
function formatGeoAddress(geoLocation: any): string {
	const parts: string[] = [];
	if (geoLocation?.r1) parts.push(geoLocation.r1);
	if (geoLocation?.r2) parts.push(geoLocation.r2);
	if (geoLocation?.r3) parts.push(geoLocation.r3);
	return parts.join(' ');
}

/**
 * extra 필드의 기본값을 설정합니다
 */
function normalizeExtraFields(extra: any): void {
	// actionDuration 정규화
	if (extra.actionDuration === '1.0') {
		extra.actionDuration = 0;
	}
	if (extra.actionDuration === undefined) {
		extra.actionDuration = 0;
	}

	// 시간 관련 필드 기본값 설정
	const timeFields = ['playerStartTime', 'videoStartTime', 'totalStartTime', 'seekedTime'];
	timeFields.forEach((field) => {
		if (extra[field] === undefined) {
			extra[field] = 0;
		}
	});

	// 비디오 타입 및 포맷 설정
	if (extra.type === undefined && reportData.video?.type) {
		extra.type = reportData.video.type;
	}

	if (extra.url === undefined && reportData.video?.url) {
		extra.url = reportData.video.url;
		extra.videoFormat = inferVideoFormat(extra.url);
	}
}

/**
 * 지리 정보를 extra 필드에 추가합니다
 */
/**
 * 전송에 필요한 필수 데이터가 있는지 검증합니다
 */
function hasRequiredData(extra: any): boolean {
	return Boolean(extra.UUID && extra.TID && extra.host);
}

/**
 * 지리 정보를 extra 필드에 추가합니다
 */
function addGeoInfoToExtra(extra: any): void {
	try {
		const geoLocation = stageData.syncResult?.geoLocation;
		if (geoLocation) {
			extra.address = formatGeoAddress(geoLocation);
			extra.isp = geoLocation.net || '';
			extra.ip = stageData.syncResult?.ip || '';
			extra.nation = geoLocation.country || '';
		}
	} catch (e) {
		// 에러 발생 시 무시
	}
}

/**
 * 디버그 로그를 출력합니다
 */
function logDebugInfo(data: any): void {
	return;
	if (data.extra?.actionType) {
		console.log('MA report actionType ->', data.extra.actionType);
		console.log('ㄴ', 'UUID', data.extra.UUID);
		//console.log('ㄴ', 'UUID1', `https://ma.vpe.naverncp.com/api/v1/session/${data.extra.UUID}/detail`);
		/*console.log(
			'ㄴ',
			'UUID2',
			`https://ma.vpe.naverncp.com/4npTigdb1Q/console/audience/latest_sessions/${data.extra.UUID}/detail`
		);*/
		console.log('ㄴ', 'TID', data.extra.TID);
		//console.log('ㄴ', 'isp', data.extra.isp);
		console.log('ㄴ', 'host', data.extra.host);
		console.log('------------------------------------------------');
	}
}

// ============================================================================
// API 함수
// ============================================================================

/**
 * MA 동기화 설정을 초기화합니다
 */
export const maInitConfig = async (accessKey: string): Promise<any> => {
	if (!accessKey) return;

	const { platform, stage } = stageData;
	const API_URL = ENCODED_API_PATH[platform][stage].log;

	try {
		const response = await fetch(API_URL, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify({
				access_key: accessKey,
			}),
		});

		const data = await response.json();
		stageData.sync = data.result?.sync || false;
		stageData.syncResult = data.result || {};

		// 시간 정보 업데이트
		const { logDate, logDateUnix } = thisTime();
		reportData.extra.logDate = logDate;
		reportData.extra.logDateUnix = logDateUnix;

		// 지리 정보 업데이트
		if (stageData.syncResult?.geoLocation) {
			addGeoInfoToExtra(reportData.extra);
		}

		return data;
	} catch (error) {
		console.error('MA config initialization failed:', error);
		return null;
	}
};

/**
 * 초기 MA 리포트를 전송합니다
 */
export const maInitFetch = async (sendData: any): Promise<void> => {
	const { platform, stage } = stageData;
	const API_URL = detcosde(ENCODED_API_PATH[platform][stage].report);

	const tosendDataMg = { ...sendData };
	tosendDataMg.log_type = 'vpe';

	// 지리 정보 추가
	addGeoInfoToExtra(tosendDataMg.extra);

	try {
		await fetch(API_URL, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(tosendDataMg),
		});
	} catch (error) {
		console.error('MA init report failed:', error);
	}
};

/**
 * MA 리포트를 전송합니다
 */
export const maFetch = async (sendData: any): Promise<void> => {
	const { platform, stage } = stageData;
	const API_URL = detcosde(ENCODED_API_PATH[platform][stage].report);

	// 데이터 병합
	const tosendDataMg = JSON.parse(JSON.stringify(reportData));
	deepMerge(tosendDataMg, sendData);

	tosendDataMg.log_type = 'MA';

	// 지리 정보 추가
	addGeoInfoToExtra(tosendDataMg.extra);

	// extra 필드 정규화
	normalizeExtraFields(tosendDataMg.extra);

	// 필수 데이터 검증
	if (!hasRequiredData(tosendDataMg.extra)) {
		//console.log('[warn]', 'MA report skipped: Missing required data (UUID, TID, or host)');
		return;
	}

	try {
		await fetch(API_URL, {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
			},
			body: JSON.stringify(tosendDataMg),
		});

		// 디버그 로그
		logDebugInfo(tosendDataMg);
	} catch (error) {
		console.log('MA report failed:', error);
	}
};

/**
 * MA 동기화를 초기화합니다
 */
export async function maSyncInit(
	platform: string,
	stage: string,
	inData: any,
	appId: string,
	accessKey: string
): Promise<void> {
	stageData.platform = platform;
	stageData.stage = stage;

	// 데이터 병합
	deepMerge(reportData, inData);

	// 언어 코드 설정
	reportData.browser.lang = nationCode[reportData.extra.nation] || 'ko-KR';

	// 시간 정보 설정
	const { logDate, logDateUnix } = thisTime();
	reportData.extra.logDate = logDate;
	reportData.extra.logDateUnix = logDateUnix;
	reportData.extra.created_at = logDateUnix;
}

/**
 * MA 시작 리포트를 전송합니다
 */
export async function maSyncStart(inData: any): Promise<void> {
	// 전역 객체를 직접 수정하지 않도록 깊은 복사 사용
	const sendReportData = JSON.parse(JSON.stringify(reportData));

	// extra 객체를 덮어쓰지 않고 병합하여 IP 등 기존 정보를 보존
	if (inData.extra) {
		Object.assign(sendReportData.extra, inData.extra);
	}

	sendReportData.video = inData.video;

	await maInitFetch(sendReportData);
	console.log('MA vpe init');
}

/**
 * MA 동기화를 수행합니다
 */
export async function maSync(inData: any, newSessionId: boolean = false): Promise<void> {
	// 데이터 병합
	deepMerge(reportData, inData);

	// 새 세션 ID 생성
	if (newSessionId) {
		reportData.extra.sessionId = generateSessionId();
	}

	// 시간 정보 업데이트
	const { logDate, logDateUnix, thisSec } = thisTime();
	reportData.extra.logDate = logDate;
	reportData.extra.logDateUnix = logDateUnix;
	reportData.extra.actionDuration = thisSec;

	await maFetch(reportData);
}
