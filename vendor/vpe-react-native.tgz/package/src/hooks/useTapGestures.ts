import { useEffect, useRef, useState } from 'react';
import { Animated } from 'react-native';
import type { GestureResponderEvent, LayoutChangeEvent } from 'react-native';

// ----------------------------------------------------------------------------
// 상수 (PlayerControls.tsx와 동일)
// ----------------------------------------------------------------------------

export const DOUBLE_TAP_DELAY = 300; // 더블 탭 인식 시간 간격 (ms)
export const SEEK_EXECUTION_DELAY = 500; // 탐색 실행 대기 시간 (ms)
export const SEEK_ANIMATION_DURATION = 400; // 탐색 애니메이션 지속 시간 (ms)
export const SEEK_AMOUNT_INCREMENT = 10; // 탭당 탐색 시간 (초)

export interface SeekInfo {
	direction: 'forward' | 'rewind';
	amount: number;
}

export interface UseTapGesturesArgs {
	/** 단일 탭(중앙) 시 호출 — 컨트롤 가시성 토글 */
	onToggleVisibility?: () => void;
	/** 더블탭 seek 시 호출 — 누적된 시간으로 한 번에 seek */
	onSeek?: (seconds: number) => void;
	/** 현재 재생 시간 (seek 베이스라인) */
	currentTime: number;
	/** false이면 더블탭 seek 비활성화 (단일탭 토글만 동작) */
	touchGestures?: boolean;
	/** 더블탭 seek 사이클 동안 컨트롤을 강제 활성 상태로 유지 (선택) */
	setActive?: (active: boolean) => void;
}

export interface UseTapGesturesResult {
	onLayout: (event: LayoutChangeEvent) => void;
	onPress: (event: GestureResponderEvent) => void;
	seekInfo: SeekInfo | null;
	seekAnimation: Animated.Value;
}

/**
 * 비디오 영역의 탭 제스처를 처리하는 훅.
 *
 * 동작:
 * - 단일 탭 (중앙 1/3): 컨트롤 가시성 토글
 * - 단일 탭 (좌/우 1/3): 컨트롤 가시성 토글 + 더블탭 대기
 * - 더블 탭 좌측: 10초 뒤로 (누적 가능)
 * - 더블 탭 우측: 10초 앞으로 (누적 가능)
 * - 누적: 더블탭 후 SEEK_EXECUTION_DELAY(500ms) 안에 다시 더블탭하면 SEEK_AMOUNT_INCREMENT(10초)씩 누적
 * - 누적이 끝나면 setTimeout으로 한 번에 seek 실행
 *
 * `touchGestures: false` 면 더블탭 seek은 비활성화되고 단일탭 토글만 동작.
 */
export function useTapGestures({
	onToggleVisibility,
	onSeek,
	currentTime,
	touchGestures = true,
	setActive,
}: UseTapGesturesArgs): UseTapGesturesResult {
	const [width, setWidth] = useState(0);
	const [seekInfo, setSeekInfo] = useState<SeekInfo | null>(null);

	const seekAnimation = useRef(new Animated.Value(0)).current;
	const seekTimerRef = useRef<NodeJS.Timeout | null>(null);
	// 좌/우 영역 단일탭의 컨트롤 토글을 지연시키기 위한 타이머.
	// DOUBLE_TAP_DELAY 안에 두 번째 탭이 들어오면 이 타이머가 취소되어 컨트롤이 깜빡이지 않음.
	const firstTapTimerRef = useRef<NodeJS.Timeout | null>(null);
	const lastTapRef = useRef<{ time: number; side: 'left' | 'right' | 'middle' | null }>({
		time: 0,
		side: null,
	});
	const seekAmountRef = useRef(0);

	// 항상 최신 currentTime을 보기 위한 ref (setTimeout 안에서 사용)
	const currentTimeRef = useRef(currentTime);
	currentTimeRef.current = currentTime;

	// seek indicator 등장 시 방사형 애니메이션 시작
	useEffect(() => {
		if (seekInfo) {
			seekAnimation.setValue(0);
			Animated.timing(seekAnimation, {
				toValue: 1,
				duration: SEEK_ANIMATION_DURATION,
				useNativeDriver: true,
			}).start();
		}
	}, [seekInfo, seekAnimation]);

	// 언마운트 시 타이머 정리
	useEffect(() => {
		return () => {
			if (seekTimerRef.current) {
				clearTimeout(seekTimerRef.current);
				seekTimerRef.current = null;
			}
			if (firstTapTimerRef.current) {
				clearTimeout(firstTapTimerRef.current);
				firstTapTimerRef.current = null;
			}
		};
	}, []);

	const clearFirstTapTimer = () => {
		if (firstTapTimerRef.current) {
			clearTimeout(firstTapTimerRef.current);
			firstTapTimerRef.current = null;
		}
	};

	const clearSeekSequence = () => {
		if (seekTimerRef.current) {
			clearTimeout(seekTimerRef.current);
			seekTimerRef.current = null;
		}
		setSeekInfo(null);
		seekAmountRef.current = 0;
		lastTapRef.current = { time: 0, side: null };
	};

	const executeSeek = (side: 'left' | 'right') => {
		const base = currentTimeRef.current;
		const target = base + (side === 'right' ? seekAmountRef.current : -seekAmountRef.current);
		onSeek?.(Math.max(0, target));

		setSeekInfo(null);
		seekAmountRef.current = 0;
		lastTapRef.current = { time: 0, side: null };
		setActive?.(false);
	};

	const getTapSide = (locationX: number): 'left' | 'middle' | 'right' => {
		if (width <= 0) return 'middle';
		const sideThird = width / 3;
		if (locationX < sideThird) return 'left';
		if (locationX > width - sideThird) return 'right';
		return 'middle';
	};

	const isContinuousTap = (side: 'left' | 'right', now: number): boolean => {
		return lastTapRef.current.side === side && now - lastTapRef.current.time < DOUBLE_TAP_DELAY;
	};

	const handleFirstTap = (side: 'left' | 'right', now: number) => {
		// 컨트롤 토글을 DOUBLE_TAP_DELAY만큼 지연 — 그동안 두 번째 탭이 들어오면 토글 취소.
		// 이 덕분에 더블탭 시 컨트롤이 깜빡이지 않고 곧바로 indicator만 표시된다.
		clearFirstTapTimer();
		firstTapTimerRef.current = setTimeout(() => {
			onToggleVisibility?.();
			firstTapTimerRef.current = null;
		}, DOUBLE_TAP_DELAY);
		lastTapRef.current = { time: now, side };
		seekAmountRef.current = 0;
	};

	const handleDoubleTap = (side: 'left' | 'right', now: number) => {
		if (!touchGestures) return;

		// 첫 탭의 토글 타이머 취소 → 컨트롤이 보이지 않은 채 indicator만 표시됨
		clearFirstTapTimer();

		setActive?.(true);
		lastTapRef.current = { time: now, side };

		// 탐색 시간 누적
		seekAmountRef.current += SEEK_AMOUNT_INCREMENT;
		setSeekInfo({
			direction: side === 'left' ? 'rewind' : 'forward',
			amount: seekAmountRef.current,
		});

		// 탐색 실행 타이머 (이전 타이머는 클리어)
		if (seekTimerRef.current) {
			clearTimeout(seekTimerRef.current);
		}
		seekTimerRef.current = setTimeout(() => {
			executeSeek(side);
		}, SEEK_EXECUTION_DELAY);
	};

	const onLayout = (event: LayoutChangeEvent) => {
		setWidth(event.nativeEvent.layout.width);
	};

	const onPress = (event: GestureResponderEvent) => {
		const { locationX } = event.nativeEvent;
		const side = getTapSide(locationX);
		const now = Date.now();

		// 중앙 탭: 즉시 컨트롤 토글, 좌/우 단일탭 지연 타이머도 취소, seek 시퀀스 클리어
		if (side === 'middle') {
			clearFirstTapTimer();
			onToggleVisibility?.();
			clearSeekSequence();
			return;
		}

		// 좌우 영역: 단일 탭 또는 더블 탭
		if (isContinuousTap(side, now)) {
			handleDoubleTap(side, now);
		} else {
			handleFirstTap(side, now);
		}
	};

	return {
		onLayout,
		onPress,
		seekInfo,
		seekAnimation,
	};
}
