import { NativeModules, Platform } from 'react-native';
import VpePlayer from './VpePlayer';

const LINKING_ERROR = `The package 'vpe-react-native' doesn't seem to be linked. Make sure: \n\n` + Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) + '- You rebuilt the app after installing the package\n' + '- You are not using Expo Go\n';

const VpeReactNative = NativeModules.VpeReactNative ? NativeModules.VpeReactNative : new Proxy(
    {},
    {
      get() {
        throw new Error(LINKING_ERROR);
      },
    }
  );

export function multiply(a: number, b: number): Promise<number> {
  return VpeReactNative.multiply(a, b);
}

export { VpePlayer };
