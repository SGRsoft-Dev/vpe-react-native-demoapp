import React, { useEffect, useMemo, useRef } from 'react';
import { View, Pressable, StyleSheet, Animated, TouchableOpacity } from 'react-native';
import { SpeakerSimpleSlashIcon } from 'phosphor-react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import type { ControlBarLayoutInput } from './layout/types';
import { useLayoutResolver, layoutHasSeekBar } from './layout/useLayoutResolver';
import { renderSection } from './layout/ControlBarSection';
import { PlayerContext, usePlayerContextOptional } from './PlayerContext';
import { useTapGestures } from './hooks/useTapGestures';
import SeekIndicator from './controls/SeekIndicator';
import SeekBar from './controls/SeekBar';

// 컨트롤 UI fade-in/out 지속시간 (ms)
const CONTROL_FADE_DURATION = 300;

export interface ControlBarProps {
	/** 사용자 정의 layout. 미지정 시 디폴트 사용 */
	layout?: ControlBarLayoutInput;
	/** 사용자 강제 UI 모드 (개발/디버그용) */
	uiMode?: 'pc' | 'mobile' | 'fullscreen' | null;
	/** 단일 탭 시 호출 — 컨트롤 가시성 토글 */
	onToggleVisibility?: () => void;
	/** 더블탭 seek 사이클 동안 컨트롤을 강제 활성화 (선택) */
	onSetActive?: (active: boolean) => void;
}

const DEFAULT_ORDER: Array<'top' | 'upper' | 'center' | 'seekbar' | 'lower' | 'bottom'> = [
	'top',
	'upper',
	'center',
	'seekbar',
	'lower',
	'bottom',
];

/**
 * 새 컨트롤바 — 레이아웃 시스템 기반 렌더러.
 *
 * - `useLayoutResolver`로 현재 화면 상태에 맞는 단일 layout 결정
 * - layout.order(또는 디폴트)에 따라 섹션을 순회 렌더
 * - 각 섹션은 `renderSection`(layout/ControlBarSection.tsx)으로 위임
 * - `useTapGestures` 훅으로 단일/더블탭 제스처 처리 (좌/중/우 영역 분할)
 * - `<SeekIndicator>`로 더블탭 seek 시각 피드백
 *
 * 이 컴포넌트는 PlayerProvider 안에서 사용해야 한다 (VpePlayer가 자동으로 처리).
 */
const ControlBar: React.FC<ControlBarProps> = ({ layout, uiMode = null, onToggleVisibility, onSetActive }) => {
	const ctx = usePlayerContextOptional();
	const insets = useSafeAreaInsets();
	const isFullScreen = ctx?.isFullScreen ?? false;
	const isLive = ctx?.isLive ?? false;
	const isActive = ctx?.isActive ?? true;
	const isMuted = ctx?.isMuted ?? false;
	const currentTime = ctx?.currentTime ?? 0;
	const touchGestures = (ctx?.validatedOptions as any)?.touchGestures !== false;
	const startMutedInfoNotVisible = (ctx?.validatedOptions as any)?.startMutedInfoNotVisible === true;

	const { resolvedLayout } = useLayoutResolver({
		layout,
		isFullScreen,
		isLive,
		uiMode,
	});

	const { onLayout, onPress, seekInfo, seekAnimation } = useTapGestures({
		onToggleVisibility,
		onSeek: ctx?.seek,
		currentTime,
		touchGestures,
		setActive: onSetActive,
	});

	const order = resolvedLayout.order ?? DEFAULT_ORDER;
	// `order`에 'seekbar' 슬롯이 포함되어 있어도, layout의 어떤 섹션에 이미 SeekBar 아이템이
	// 선언되어 있다면 중복 방지를 위해 슬롯을 표시하지 않는다.
	const hasBottomSeekBar = order.includes('seekbar') && !layoutHasSeekBar(resolvedLayout);

	// resolved layout의 iconSize를 PlayerContext에 주입 → 컨트롤들이 자체 디폴트 대신 사용
	const layoutIconSize = resolvedLayout.iconSize;
	const enrichedCtx = useMemo(() => {
		if (!ctx) return null;
		if (layoutIconSize === undefined) return ctx;
		return { ...ctx, iconSize: layoutIconSize };
	}, [ctx, layoutIconSize]);

	// 컨트롤 UI 표시 조건. seek 진행 중에는 indicator만 보이고 컨트롤은 숨김.
	const visible = isActive && !seekInfo;

	// fade-in/out 애니메이션
	const fadeAnim = useRef(new Animated.Value(visible ? 1 : 0)).current;
	useEffect(() => {
		Animated.timing(fadeAnim, {
			toValue: visible ? 1 : 0,
			duration: CONTROL_FADE_DURATION,
			useNativeDriver: true,
		}).start();
	}, [visible, fadeAnim]);

	// 컨트롤바 비활성 + 음소거 + 안내 비활성 옵션이 아닐 때 좌측 상단에 mute 인디케이터 표시
	const showMuteIndicator = !visible && isMuted && !startMutedInfoNotVisible && !seekInfo;

	const content = (
		<Pressable style={visible ? styles.surface : styles.surfaceDec} onPress={onPress} onLayout={onLayout}>
			{/* 더블탭 seek indicator (seek 진행 중일 때만 표시) */}
			<SeekIndicator seekInfo={seekInfo} seekAnimation={seekAnimation} isFullScreen={isFullScreen} />

			{/*
				컨트롤바 비활성 상태에서 음소거 안내 인디케이터.
				사용자가 옵션 startMutedInfoNotVisible: true로 끄지 않은 경우에만 표시.
				탭하면 즉시 음소거 해제.
			*/}
			{showMuteIndicator && (
				<View
					style={[
						styles.muteIndicatorWrap,
						isFullScreen && {
							top: insets.top + 12,
							left: insets.left + 12,
						},
					]}
					pointerEvents="box-none"
				>
					<TouchableOpacity
						onPress={(e) => {
							e.stopPropagation();
							ctx?.toggleMute?.();
						}}
						style={styles.muteIndicatorBtn}
					>
						<SpeakerSimpleSlashIcon weight="fill" color="#ffffff" size={18} />
					</TouchableOpacity>
				</View>
			)}

			{/*
				컨트롤 UI는 항상 마운트하고 opacity로 fade.
				`visible === false`일 때는 pointerEvents='none'으로 터치를 통과시켜
				하부 Pressable의 onPress(탭 제스처)가 정상 동작하게 한다.
			*/}
			<Animated.View
				style={[styles.fadeContainer, { opacity: fadeAnim }]}
				pointerEvents={visible ? 'auto' : 'none'}
			>
				<View style={styles.backdrop} pointerEvents="none" />
				<View
					style={[
						styles.uiArea,
						{
							paddingTop: isFullScreen ? insets.top : 0,
							paddingBottom: isFullScreen ? Math.max(insets.bottom, 20) - 3 : 5,
							paddingLeft: isFullScreen ? insets.left + 15 : 15,
							paddingRight: isFullScreen ? insets.right + 15 : 15,
						},
					]}
				>
					{order.map((section) => {
						switch (section) {
							case 'top':
								return (
									<View key="layout-top" style={styles.row}>
										{renderSection(resolvedLayout.top, 'top')}
									</View>
								);
							case 'upper':
								return (
									<View key="layout-upper" style={styles.row}>
										{renderSection(resolvedLayout.upper, 'upper')}
									</View>
								);
							case 'center':
								return (
									<View key="layout-center" style={styles.center}>
										{renderSection(resolvedLayout.center, 'center')}
									</View>
								);
							case 'seekbar':
								// 'seekbar' section은 별도 SeekBar 슬롯. 사용자가 layout 어딘가에
								// SeekBar 아이템을 명시했다면 자동으로 렌더되므로 여기선 추가 처리 없음.
								return null;
							case 'lower':
								return (
									<View key="layout-lower" style={styles.row}>
										{renderSection(resolvedLayout.lower, 'lower')}
									</View>
								);
							case 'bottom':
								return (
									<View key="layout-bottom" style={styles.row}>
										{renderSection(resolvedLayout.bottom, 'bottom')}
									</View>
								);
							default:
								return null;
						}
					})}
				</View>
			</Animated.View>

			{/*
				layout.order에 'seekbar'가 포함되면 화면 하단에 풀폭 SeekBar를 별도 슬롯으로 렌더한다.
				uiArea의 paddingHorizontal/paddingBottom 영향을 받지 않도록 absolute로 박아서
				플레이어 가로 끝에서 끝까지, 화면 하단에 가득 차게 표시.
			*/}
			{hasBottomSeekBar && (
				<View
					style={[
						styles.bottomSeekBarSlot,
						isFullScreen && {
							left: insets.left,
							right: insets.right,
							bottom: insets.bottom,
						},
					]}
					pointerEvents="box-none"
				>
					<SeekBar noMargin height={5} />
				</View>
			)}
		</Pressable>
	);

	// resolved layout의 iconSize를 자식 컨트롤들이 사용할 수 있도록 inner Provider로 wrap
	if (enrichedCtx && enrichedCtx !== ctx) {
		return <PlayerContext.Provider value={enrichedCtx}>{content}</PlayerContext.Provider>;
	}
	return content;
};

const styles = StyleSheet.create({
	surface: {
		position: 'absolute',
		width: '100%',
		height: '100%',
		zIndex: 5,
	},
	surfaceDec: {
		position: 'absolute',
		width: '100%',
		height: '100%',
		zIndex: 3,
	},
	fadeContainer: {
		position: 'absolute',
		left: 0,
		right: 0,
		top: 0,
		bottom: 0,
	},
	backdrop: {
		position: 'absolute',
		left: 0,
		right: 0,
		top: 0,
		bottom: 0,
		backgroundColor: 'rgba(0,0,0,0.4)',
	},
	uiArea: {
		flex: 1,
		flexDirection: 'column',
		justifyContent: 'space-between',
	},
	row: {
		flexDirection: 'row',
		alignItems: 'center',
		// 컬럼 안에서 가로 전체 차지 → 자식 Blank wrapper의 flex:1이 실제로 동작
		alignSelf: 'stretch',
		// 각 섹션(top/upper/lower/bottom) 사이에 기본 상하 여백
		marginVertical: 10,
	},
	center: {
		flex: 1,
		flexDirection: 'row',
		alignItems: 'center',
		justifyContent: 'center',
		marginVertical: 10,
	},
	bottomSeekBarSlot: {
		position: 'absolute',
		left: 0,
		right: 0,
		bottom: 0,
		// 컨트롤 UI 위에 표시
		zIndex: 10,
		// SeekBar 위쪽에 여백 (absolute 컨테이너이므로 paddingTop으로 자식을 아래로 밀어냄)
		paddingTop: 10,
	},
	muteIndicatorWrap: {
		position: 'absolute',
		top: 12,
		left: 12,
		zIndex: 6,
	},
	muteIndicatorBtn: {
		width: 32,
		height: 32,
		borderRadius: 999,
		backgroundColor: 'rgba(0,0,0,0.55)',
		justifyContent: 'center',
		alignItems: 'center',
	},
});

export default ControlBar;
